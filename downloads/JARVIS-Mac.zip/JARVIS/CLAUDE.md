# Jarvis

This folder is JARVIS, a voice assistant for macOS. `jarvis.py` runs the mic, wake word, Whisper, a long-lived
`claude -p` brain (that may be *you*), the voices, the on-screen display (`hud.html`) and the phone bridge.
Edits to `jarvis.py`, `guard.py` or `.env` make the running Jarvis restart itself between turns; `hud.html`
and `phone.html` just reload. Any edit must compile: `python3 -m py_compile jarvis.py`, and for hud.html
`node -e "const s=require('fs').readFileSync('hud.html','utf8');for(const m of s.matchAll(/<script>([\s\S]*?)<\/script>/g)) new Function(m[1])"`.

## Memory (what makes Jarvis remember from one conversation to the next)

- Long-term index: the auto-memory `MEMORY.md` is injected at the start of every session (you are reading it too).
  Topic files live next to it (same directory as MEMORY.md), including `running_jokes.md`.
- Day-to-day log: `case_files/daily/YYYY/MM/YYYY-MM-DD.md`, one file per day. `jarvis.py` creates today's file
  and writes every exchange to `YYYY-MM-DD.transcript.md` beside it; **you add the curated bullets** to the `.md`:
  decisions, things the user asked you to remember, open asks, callbacks that landed or missed. Before a
  conversation is reset (idle, "start over", shutdown) the brain is asked to append a where-we-left-off note.
- Restarts keep the conversation: `jarvis.py` saves the brain's session id in `.brain_session` and resumes it after
  a hot reload. Typed `/exit`, `/mute`, `/unmute`, `/reset`, `/status`, `/help` work in the Jarvis terminal.
- Before saying "I don't remember", "nothing on record" or "nothing is running": read today's and yesterday's
  case file, `running_jokes.md`, and run `.venv/bin/python worker.py list`. The brain gets the last two case
  files and `running_jokes.md` handed to it at the start of each conversation; mid-conversation, re-read when
  the user refers to earlier work.
- Saving instantly, with no tool call: put `[[remember: one line]]` on its own line in a reply and jarvis.py
  appends it to today's case file; `[[joke: one line]]` appends to `running_jokes.md`. Use them the moment the
  user says "remember this", sets up a bit, or states a fact about himself. They are stripped before speech.

## Helpers (all under this folder; call with `.venv/bin/python <helper>`)

- `cal.py today|tomorrow|week|next|YYYY-MM-DD|search "words"|add "Title" <date> <start> <end>` - Calendar.app, under a second.
- `rem.py due [today|week|overdue|all]|add "text" <when> [--list Name]|done "words"` - Reminders, under a second.
- `timer.py set 20m "label"|list|cancel <id>` - timers that survive restarts; Jarvis speaks when they go off.
- `sheet_tab.py "<downloaded xlsx>" "<tab>"` - a tab of the school planner sheet.
- `worker.py start "<label>" "<task>"|list|status <id>|followup <id> "<more>"|cancel <id>` - "Edwin", the
  background job runner; jobs survive restarts and are announced out loud when done.
- `voice_check.py [--play|--voices]` - is the ElevenLabs key good, credits left, reset date.
- `music_play.py` - play/notate melodies and chords; `hud.py panel|note|task|clear` - push to the display.

## Safety

`guard.py` runs before every tool: sends, posts, buys and deletes need the user's spoken "yes" first (it answers
"Shall I send it?"); `rm` is only allowed under /tmp; `sudo`, `killall`, `launchctl load/unload` are blocked.
Never write or edit `guard.py`, `.claude/settings*.json` or `.env` from a Jarvis turn. Never write and submit
graded schoolwork as the user or disguise authorship; outline, quiz, and edit his draft instead.
