#!/bin/bash
# Double-click to start JARVIS. Keep this window open; close it (or say "Jarvis, shut down") to stop.
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then
  echo "Run setup first:  bash setup.sh"
  read -r -p "Press Return to close."
  exit 1
fi
export PATH="$HOME/.local/bin:/opt/homebrew/bin:$PATH"
exec .venv/bin/python jarvis.py
