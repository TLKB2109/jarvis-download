# JARVIS for your Mac

An always-listening assistant. Say **"Hey Jarvis"**, then your command.

## Setup (once, about 5 minutes)
1. Unzip this folder somewhere permanent, e.g. your home folder.
2. Open **Terminal**, type `bash ` (with a space), drag `setup.sh` into the window, press Return.
3. If Claude Code opens, log in with your claude.ai account, then type `/exit`.

## Run it
Double-click **Jarvis.command**. The first time, macOS asks to let Terminal use the microphone: click **Allow**.
You'll hear "Jarvis online." Leave the window open (you can minimize it).

To start it automatically: System Settings > General > Login Items > **+** > pick `Jarvis.command`.

## Talking to it
- "Hey Jarvis" -> *tink* -> say your command. He starts answering in a second or two.
- After he answers, just keep talking for about 7 seconds; no wake word needed.
- Say "Hey Jarvis" while he's talking to cut him off and ask something else.
- He remembers the conversation, so follow-ups like "and what about Day 4?" work.
- "Never mind" / "that's all" ends the conversation. "Start over" begins a fresh one (he writes a where-we-left-off note first). "Jarvis, shut down" quits.
- You can also just type in the Jarvis window and press Return. `/exit`, `/mute`, `/unmute`, `/reset`, `/status` and `/help` are local commands; anything else is said to him.
- Only one Jarvis runs at a time: launching a second one says so and quits.

Try:
- "Good morning" or "Brief me." (calendar, inbox, weather and classes, spoken, with details on screen)
- "Email Mr. Jacobs that I'll be ten minutes late to jazz band." (he reads it back; say "yes" to send)
- "Text Mom I'm on my way." (same: he asks first)
- "Google who played guitar on Kind of Blue."
- "Open my Gmail and read me the newest email."
- "Set a timer for 20 minutes."
- "What classes do I have on Day 3?"
- "What are my jazz priorities?"
- "Play some Wes Montgomery on Spotify." (Spotify app must be open)
- "What's on my calendar tomorrow?"
- "Remind me to practice Autumn Leaves at 7."
- "Open Logic Pro."

## Memory
Jarvis keeps a daily log in `case_files/daily/YYYY/MM/YYYY-MM-DD.md` (his own notes) and `YYYY-MM-DD.transcript.md` (every line you both said). Every new conversation starts with the last two days' notes, the running-jokes list and any background jobs handed to him, so he picks up where you left off. Say "remember this" or set up a bit and he files it instantly. Restarts after a code change resume the same conversation; a long idle gap starts a fresh one after he writes a hand-off note.

## Helpers he uses (all in this folder)
- `cal.py today|tomorrow|week|next|search "words"|add ...` - Calendar.app, under a second
- `rem.py due|add|done` - Reminders, under a second (the first run asks for Reminders access: click Allow)
- `timer.py set 20m "stretch"|list|cancel` - timers that survive restarts; he chimes and tells you when they're up, with a countdown on screen
- `worker.py` - "Edwin", the background job runner for long tasks; jobs survive restarts and are announced when done
- `sheet_tab.py`, `music_play.py`, `hud.py` - planner tabs, music playback, pushing panels to the display

## The display
When Jarvis starts, a holographic window opens in Chrome. The ring glows when he hears you, spins blue while he works, and pulses while he talks. Lists, schedules and email drafts show up there as panels while he says the short version. To turn it off, add `export JARVIS_HUD=0` to Jarvis.command.

## ElevenLabs voice (optional, the voice from the video)
1. Make a free account at elevenlabs.io, then go to your profile > **API Keys** > **Create**, and copy the key.
2. In Terminal, run (paste your key in place of YOUR_KEY):
   `echo "ELEVENLABS_API_KEY=YOUR_KEY" >> ~/Downloads/Jarvis/.env`
3. Jarvis restarts himself with the new voice ("George", British). For a different voice, also add `ELEVENLABS_VOICE=Name` (any voice in your ElevenLabs library) to that file.
Run `.venv/bin/python voice_check.py` any time to see whether the key works, how many credits are left and when they reset (that needs a key with the *User: read* permission; tick it when you create the key). The free plan is 10,000 credits a month, about 20 minutes of speech, which Jarvis gets through in a couple of days; Starter ($5) is 30,000, Creator ($22) is 100,000. When credits run out he tells you once and switches to the Kokoro voice until they reset. Short lines he says all day are cached, so they cost credits once. `JARVIS_ELEVEN_FOR=jarvis` in `.env` keeps ElevenLabs for Jarvis only and puts Mavis and the others on Kokoro, if you want the credits to last longer.

## Briefings
Say "good morning", "brief me" or "what's my day look like". Jarvis checks Google Calendar, your Gmail from the last day, the weather in your city (`JARVIS_USER_CITY`), Reminders and your class rotation. The first time you talk to him each morning, he offers one.


## Your phone
Jarvis is reachable from your phone's browser, as a mic button (or a text box) that talks to this same Jarvis (same memory, same connectors). Your Mac still does all the thinking and the Mac-only things (iMessage, Calendar.app); the phone is a remote mic, keyboard and speaker.

**From anywhere (Tailscale, set up once):** install Tailscale on the Mac (tailscale.com/download/mac) and on the phone (App Store), sign both in with the same account, turn on MagicDNS and HTTPS Certificates at login.tailscale.com > DNS, then on the Mac run once:

    /Applications/Tailscale.app/Contents/MacOS/Tailscale serve --bg --https=443 https+insecure://127.0.0.1:8771

With Tailscale connected on the phone, open `https://<your-mac-name>.<your-tailnet>.ts.net` (the Mac's name is shown by `Tailscale status`), enter the PIN from `PHONE_PIN` in `.env` once, and Share > Add to Home Screen. No certificate warnings, works on cellular and at school, and nobody outside your Tailscale account can reach it. `Tailscale serve reset` turns it off.

**Same Wi-Fi only (no Tailscale):** go to `https://<this Mac's IP>:8771` (Jarvis logs the address when he starts), tap through the certificate warning (it's self-signed), enter the PIN.

Tap the mic circle, talk, tap again to send, or type in the box. He answers in text, panels and voice; Mavis and the others get their own voices. Cancel stops a long answer. The phone and the Mac share one Jarvis, so if you talk to both at once, one waits for the other.

## Updates
When `jarvis.py` or `.env` changes, Jarvis restarts himself at the next quiet moment and resumes the same conversation; `hud.html` and `phone.html` changes just reload the page. `guard.py` changes apply immediately.

## Your details (.env)
Personal details (name, school, city, email addresses, planner sheet ID) live in `.env`, which is never uploaded to GitHub. Copy `.env.example` to `.env` and fill it in. API keys (`ELEVENLABS_API_KEY`) and `PHONE_PIN` go there too.

## Settings
Everything is set in `.env` next to `jarvis.py` (see `.env.example` for the full list with defaults). The ones people change:
- `JARVIS_VOICE` - `bm_george` (default), `bm_fable`, `bm_lewis`, `bm_daniel` (British men), or `bf_emma`, `bf_isabella` (British women)
- `JARVIS_SPEED` - speaking speed, default `1.2`
- `JARVIS_MODEL` - `sonnet` (default), `haiku` (fastest), or `opus` (smartest, slowest, uses your limit fastest)
- `JARVIS_PAUSE` - how long a pause before he checks whether you are done, default `1.0` seconds. If you trail off ("and...", "um..."), he waits about 2 seconds longer. Raise to 1.4 if he still cuts you off; lower to 0.8 for snappier replies
- `JARVIS_WHISPER` - `small` (default, English and Mandarin) or `small.en` (English only, a touch faster)
- `JARVIS_WAKE_THRESHOLD` - `0.45` default; raise to 0.6 if it wakes up by accident, lower to 0.4 if it misses you. `jarvis.log` records every near miss with its score, so you can see which way to go.

## Sending things safely
Emails, texts, posts, purchases and deletes need your spoken "yes" first. Jarvis reads back who it's going to and what it says, and asks "Shall I send it?". A separate safety program (`guard.py`) blocks Mail and Messages from sending until you've said yes; each yes allows one send. In Chrome, Jarvis is told to ask first too, but guard.py can't always tell which button is being clicked there, so listen for the question. Jarvis can't run sudo, delete files, or shut down your Mac.

## Audio
- Jarvis plays through whatever output you have selected (menu bar > Sound), and switches when you do.
- He listens with your Mac's built-in mic even when AirPods are connected, so your AirPods stay in high-quality mode (their mic makes audio crackly). To use a different mic, add `export JARVIS_MIC="name"` to Jarvis.command.

## Troubleshooting
- **Email** goes through your Gmail connector (connected in claude.ai Settings > Connectors). Sending, replying, forwarding and trashing all wait for your spoken "yes".
- **First text message**: macOS asks "Terminal wants to control Messages / Contacts". Click OK.
- **Chrome control**: needs the Claude in Chrome extension (you have it). If Chrome asks to connect to Claude Code, allow it. To turn Chrome control off, add `export JARVIS_CHROME=0` to Jarvis.command.
- **"Connectors allowed: none found"**: run `claude mcp list` in Terminal. Your claude.ai connectors (Google Drive, Spotify) should appear. If they say they need auth, run `claude`, type `/mcp`, and connect them.
- **Jarvis says it can't use a tool**: add the tool name to a file called `extra_allowed_tools.txt` (one per line) in this folder.
- **Calendar or Reminders asks for permission**: click OK; that's macOS letting Jarvis read them.
- Everything said is logged in `jarvis.log`.

## Privacy
Listening for "Hey Jarvis" and turning your voice into text both happen on your Mac. Only the text of a command goes to Claude. Everything Jarvis is allowed to use is listed in `.claude/settings.local.json`, which he rewrites each time he starts.
