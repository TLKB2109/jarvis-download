#!/usr/bin/env python3
"""Fast calendar lookup straight from your Mac's calendar data (every account in Calendar.app).

  cal.py today | tomorrow | week | 2026-10-07
  cal.py next                          the next thing on the calendar (what's happening now, or what's up next)
  cal.py search "peer tutoring"        (looks 2 weeks back to 2 months ahead)
  cal.py add "Guitar lesson" 2026-10-12 16:00 17:00 [--cal Personal] [--where "Room 12"]

Much faster than asking Calendar.app through AppleScript.
"""
import datetime as dt
import sys
import time

try:
    from EventKit import EKEntityTypeEvent, EKEvent, EKEventStore, EKSpanThisEvent
    from Foundation import NSDate, NSRunLoop
except ImportError:
    print("Calendar helper not installed yet (pyobjc-framework-EventKit). Use Calendar.app via osascript for now.")
    sys.exit(3)

AUTHORIZED = (3, 4)   # EKAuthorizationStatus: 3 = full access (or 'authorized' before macOS 14), 4 = write-only


def access(store) -> bool:
    status = EKEventStore.authorizationStatusForEntityType_(EKEntityTypeEvent)
    if status in AUTHORIZED:
        return True
    if status in (1, 2):   # restricted / denied: don't wait 30 s on a dialog nobody can click
        return False
    got = {"ok": None}

    def cb(granted, err):
        got["ok"] = bool(granted)

    if hasattr(store, "requestFullAccessToEventsWithCompletion_"):
        store.requestFullAccessToEventsWithCompletion_(cb)
    else:
        store.requestAccessToEntityType_completion_(EKEntityTypeEvent, cb)
    end = time.time() + 15
    while got["ok"] is None and time.time() < end:
        NSRunLoop.currentRunLoop().runUntilDate_(NSDate.dateWithTimeIntervalSinceNow_(0.05))
    return bool(got["ok"])


def ns(d: dt.datetime):
    return NSDate.dateWithTimeIntervalSince1970_(d.timestamp())


def fmt_time(d: dt.datetime) -> str:
    return d.strftime("%-I:%M %p").replace(":00 ", " ")


def events_between(store, start, end, query=None):
    pred = store.predicateForEventsWithStartDate_endDate_calendars_(ns(start), ns(end), None)
    events = []
    for e in store.eventsMatchingPredicate_(pred) or []:
        title = str(e.title() or "(no title)")
        loc = str(e.location() or "")
        if query and query not in title.lower() and query not in loc.lower():
            continue
        s = dt.datetime.fromtimestamp(e.startDate().timeIntervalSince1970())
        f = dt.datetime.fromtimestamp(e.endDate().timeIntervalSince1970())
        events.append((s, f, bool(e.isAllDay()), title, loc, str(e.calendar().title() or "")))
    events.sort(key=lambda x: x[0])
    return events


def print_events(events):
    if not events:
        print("No events found.")
        return
    for s, f, allday, title, loc, cal in events[:60]:
        when = s.strftime("%a %b %-d") + (" all day" if allday else f" {fmt_time(s)}-{fmt_time(f)}")
        print(" | ".join(x for x in (when, title, loc, f"[{cal}]") if x))


def main():
    args = sys.argv[1:] or ["today"]
    now = dt.datetime.now()
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
    store = EKEventStore.alloc().init()
    if not access(store):
        print("No calendar access. In System Settings > Privacy & Security > Calendars, turn on Python "
              "(or the app you launched Jarvis from), then try again.")
        sys.exit(2)

    if args[0] == "add" and len(args) >= 4:
        title = args[1]
        rest = args[2:]
        cal_name = where = None
        for flag in ("--cal", "--where"):
            if flag in rest:
                i = rest.index(flag)
                val = rest[i + 1] if i + 1 < len(rest) else None
                rest = rest[:i] + rest[i + 2:]
                if flag == "--cal":
                    cal_name = val
                else:
                    where = val
        try:
            day = dt.datetime.strptime(rest[0], "%Y-%m-%d")
            s = dt.datetime.combine(day.date(), dt.datetime.strptime(rest[1], "%H:%M").time())
            f = dt.datetime.combine(day.date(), dt.datetime.strptime(rest[2], "%H:%M").time()) if len(rest) > 2 else s + dt.timedelta(hours=1)
        except (ValueError, IndexError):
            sys.exit('Usage: cal.py add "Title" YYYY-MM-DD HH:MM [HH:MM] [--cal Name] [--where "Place"]')
        ev = EKEvent.eventWithEventStore_(store)
        ev.setTitle_(title)
        ev.setStartDate_(ns(s))
        ev.setEndDate_(ns(f))
        if where:
            ev.setLocation_(where)
        cal = store.defaultCalendarForNewEvents()
        if cal_name:
            for c in store.calendarsForEntityType_(EKEntityTypeEvent) or []:
                if cal_name.lower() in str(c.title() or "").lower() and c.allowsContentModifications():
                    cal = c
                    break
        ev.setCalendar_(cal)
        ok, err = store.saveEvent_span_error_(ev, EKSpanThisEvent, None)
        if not ok:
            print(f"Couldn't save the event: {err}")
            sys.exit(1)
        print(f"Added: {s.strftime('%a %b %-d')} {fmt_time(s)}-{fmt_time(f)} | {title}" + (f" | {where}" if where else "") + f" [{cal.title()}]")
        return

    if args[0] == "next":
        upcoming = [e for e in events_between(store, now - dt.timedelta(hours=12), midnight + dt.timedelta(days=8))
                    if e[1] > now and not e[2]]
        if not upcoming:
            print("Nothing on the calendar in the next week.")
            return
        s, f, _, title, loc, cal = upcoming[0]
        if s <= now:
            lead = f"NOW until {fmt_time(f)}"
        else:
            mins = int((s - now).total_seconds() // 60)
            lead = ("in " + (f"{mins} min" if mins < 120 else f"{mins // 60} h")) if s.date() == now.date() else s.strftime("%a %b %-d")
            lead += f" at {fmt_time(s)}"
        print(" | ".join(x for x in (lead, title, loc, f"[{cal}]") if x))
        for s, f, _, title, loc, cal in upcoming[1:3]:
            print("then | " + " | ".join(x for x in (s.strftime("%a %b %-d") + f" {fmt_time(s)}", title, loc, f"[{cal}]") if x))
        return

    query = None
    if args[0] == "today":
        start, end = midnight, midnight + dt.timedelta(days=1)
    elif args[0] == "tomorrow":
        start, end = midnight + dt.timedelta(days=1), midnight + dt.timedelta(days=2)
    elif args[0] == "week":
        start, end = midnight, midnight + dt.timedelta(days=7)
    elif args[0] == "search" and len(args) > 1:
        query = " ".join(args[1:]).lower()
        start, end = midnight - dt.timedelta(days=14), midnight + dt.timedelta(days=60)
    else:
        try:
            day = dt.datetime.strptime(args[0], "%Y-%m-%d")
        except ValueError:
            sys.exit(__doc__)
        start, end = day, day + dt.timedelta(days=1)
    print_events(events_between(store, start, end, query))


if __name__ == "__main__":
    main()
