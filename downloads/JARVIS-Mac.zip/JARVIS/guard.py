#!/usr/bin/env python3
"""Safety gate Claude Code runs before every tool Jarvis uses.

Anything that sends, posts, buys or deletes is blocked unless the user said "yes"
out loud in the last 90 seconds (Jarvis drops a `.confirmed` file when he does).
The yes is used up by one action, so each send needs its own yes.
"""
import json
import os
import re
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
FLAG = os.path.join(HERE, ".confirmed")
WINDOW = 90

try:
    event = json.load(sys.stdin)
except ValueError:
    sys.exit(0)

tool = event.get("tool_name", "")
inp = event.get("tool_input", {}) or {}
blob = json.dumps(inp).lower()

risky = False
why = ""

if tool == "Bash":
    cmd = str(inp.get("command", ""))
    low = cmd.lower()
    if re.search(r"(^|[;&|\s])(sudo|rmdir|shred|dd|diskutil|mkfs|shutdown|reboot|halt|killall)\b", low):
        print("Blocked: Jarvis isn't allowed to run that kind of command. Ask the user to do it.", file=sys.stderr)
        sys.exit(2)
    # rm is allowed only for scratch files confined to /tmp - anything else stays blocked
    for seg in re.findall(r"(?:^|[;&|])\s*rm\b([^;&|]*)", low):
        paths = [t for t in seg.split() if not t.startswith("-")]
        if not paths or any(not p.startswith("/tmp/") for p in paths):
            print("Blocked: Jarvis can only rm files under /tmp. Ask the user to do it for anything else.", file=sys.stderr)
            sys.exit(2)
    # launchctl is allowed only for read-only inspection (list/print), never load/unload/kill
    if re.search(r"(^|[;&|\s])launchctl\b", low) and not re.search(r"launchctl\s+(list|print)\b", low):
        print("Blocked: Jarvis isn't allowed to run that kind of launchctl command. Ask the user to do it.", file=sys.stderr)
        sys.exit(2)
    if "osascript" in low and re.search(r"\bsend\b", low) and re.search(r'"(mail|messages)"|application id "com\.apple\.(mail|messages|ichat)"', low):
        risky, why = True, "sending an email or text"
    if "osascript" in low and re.search(r"\bdelete\b", low):
        risky, why = True, "deleting something"
elif tool.startswith("mcp__"):
    name = tool.lower()
    if re.search(r"send|reply|forward|delete|trash|remove|spam|purchase|buy|checkout|share_file|post|publish|respond_to_event", name):
        risky, why = True, "an action that can't be undone"
    if "claude-in-chrome" in name or "claude_in_chrome" in name:
        # Clicking a Send / Buy / Delete style button in the browser
        if re.search(r'"(left_click|click|form_input|key|type)"', blob) and re.search(
                r"\b(send|submit|post|buy|purchase|place order|checkout|pay|delete|confirm)\b", blob):
            risky, why = True, "pressing a send, buy or delete button"

if not risky:
    sys.exit(0)

try:
    fresh = time.time() - os.path.getmtime(FLAG) < WINDOW
except OSError:
    fresh = False

if fresh:
    os.remove(FLAG)          # one yes = one action
    sys.exit(0)

print(f"Blocked until the user confirms ({why}). Read them exactly what will happen, "
      "who it goes to and the gist of the message, and ask 'Shall I send it?'. "
      "When he says yes, try again.", file=sys.stderr)
sys.exit(2)
