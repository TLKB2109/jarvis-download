#!/usr/bin/env python3
"""Put a panel on Jarvis's screen.

  hud.py panel "Today" "8:00 - Honors Physics C" "10:15 - Jazz band" "3:30 - Guitar lesson"
  hud.py note "Weather" "72 and sunny"
  hud.py task render-orb "Rendering orb animation" 60
  hud.py task render-orb done
  hud.py clear

Items that start with a time ("8:00 - ...") line up in a time column.
"""
import json
import os
import sys
import urllib.request

PORT = int(os.environ.get("JARVIS_HUD_PORT", "8770"))


def post(path, data):
    req = urllib.request.Request(f"http://127.0.0.1:{PORT}{path}", data=json.dumps(data).encode(),
                                 headers={"content-type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=3) as r:
        return r.read().decode()


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in ("panel", "note", "clear", "task"):
        sys.exit(__doc__)
    cmd = sys.argv[1]
    try:
        if cmd == "clear":
            post("/clear", {})
        elif cmd == "note":
            post("/panel", {"title": sys.argv[2] if len(sys.argv) > 2 else "", "body": " ".join(sys.argv[3:])})
        elif cmd == "task":
            tid = sys.argv[2] if len(sys.argv) > 2 else ""
            if len(sys.argv) > 3 and sys.argv[3] == "done":
                post("/task", {"id": tid, "done": True})
            else:
                label = sys.argv[3] if len(sys.argv) > 3 else ""
                pct = float(sys.argv[4]) if len(sys.argv) > 4 else 0.0
                post("/task", {"id": tid, "label": label, "pct": pct})
        else:
            post("/panel", {"title": sys.argv[2] if len(sys.argv) > 2 else "", "items": sys.argv[3:]})
        print("shown")
    except Exception as e:  # noqa: BLE001
        print(f"HUD not running ({e}); just say it out loud instead.")


if __name__ == "__main__":
    main()
