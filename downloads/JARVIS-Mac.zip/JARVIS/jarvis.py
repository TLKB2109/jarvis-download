#!/usr/bin/env python3
"""
JARVIS - an always-listening voice assistant for macOS.

Say "Hey Jarvis", then your command. Keep talking after he answers - no wake
word needed for follow-ups. Say "Hey Jarvis" while he's talking to cut him off.

Pipeline (everything except the thinking runs on your Mac):
  mic -> openWakeWord ("hey jarvis") -> faster-whisper (speech to text)
      -> Claude Code, kept running in the background and streaming its answer
      -> Kokoro neural voice, spoken sentence by sentence as the answer arrives

"Never mind" / "that's all" ends a conversation. "Start over" clears his memory
of the conversation. "Jarvis, shut down" quits. Ctrl+C also quits.
"""
import atexit
import fcntl
import hashlib
import io
import json
import os
import platform
import queue
import random
import re
import shutil
import socket
import ssl
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import http.cookies
import urllib.error
import urllib.parse
import urllib.request
import uuid
import wave
from collections import deque
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np
import sounddevice as sd
from scipy.signal import fftconvolve
from faster_whisper import WhisperModel
from openwakeword.model import Model
from openwakeword.vad import VAD

HERE = os.path.dirname(os.path.abspath(__file__))

# Secrets and settings can live in a .env file next to this script (KEY=value per line)
_ENV = os.path.join(HERE, ".env")
if os.path.exists(_ENV):
    for _line in open(_ENV):
        _line = _line.strip()
        if _line and not _line.startswith("#") and "=" in _line:
            _k, _v = _line.split("=", 1)
            os.environ.setdefault(_k.strip(), _v.strip().strip('"').strip("'"))
PY = sys.executable
RATE = 16000
FRAME = 1280                       # 80 ms, what openWakeWord expects
STEP = FRAME / RATE

WAKE_THRESHOLD = float(os.environ.get("JARVIS_WAKE_THRESHOLD", "0.45"))
WAKE_SOFT = float(os.environ.get("JARVIS_WAKE_SOFT", "0.38"))   # two frames in a row at this level also count (real attempts cluster at 0.38-0.49)
BARGE_THRESHOLD = float(os.environ.get("JARVIS_BARGE_THRESHOLD", "0.85"))   # "Hey Jarvis" while his own voice is loud in the mic (needs two frames)
BARGE_QUIET = float(os.environ.get("JARVIS_BARGE_QUIET", "0.6"))           # ...and the bar in the gaps between his sentences
NEAR_MISS = 0.3                    # wake scores from here up to the threshold get logged, so misses leave evidence
FILLER_FIRST = float(os.environ.get("JARVIS_FILLER_FIRST", "2.5"))   # seconds of silence (with tools running) before he says "on it"
FILLER_EVERY = float(os.environ.get("JARVIS_FILLER_EVERY", "25"))    # ...and how often he checks in after that on long jobs
FILLER_START = ["On it.", "One sec.", "Let me check.", "Give me a moment.", "Right, looking now."]
FILLER_START_ZH = ["好的，我来看看。", "稍等一下。", "马上就好。"]
FILLER_MORE_ZH = ["还在处理，请稍等。", "快好了。", "再等我一下。"]
FILLER_MORE = ["Still on it.", "Nearly there.", "Bear with me.", "Still working on it.", "Hang on, almost done."]
# Spoken the instant a tool starts if he hasn't said anything yet (the prompt asks for this; the model skips it ~87% of the time).
TOOL_ACKS = [(r"cal\.py|calendar", "Checking your calendar."), (r"rem\.py|remind", "Checking your reminders."),
             (r"timer\.py", "Setting that up."), (r"worker\.py", "Passing it to my assistant."),
             (r"chrome|navigate|tabs_|read_page|computer", "Opening Chrome."), (r"websearch|webfetch", "Searching."),
             (r"gmail", "Checking your mail."), (r"spotify", "One sec, Spotify."), (r"drive|sheet_tab", "Pulling up your planner."),
             (r"toolsearch", "One sec."), (r"edit|write", "Making the change."), (r"read|grep|glob", "Let me look.")]
TOOL_ACKS_ZH = "我看看。"
CASE_DIR = os.path.join(HERE, "case_files", "daily")
MEMORY_DIR = os.path.join(os.path.expanduser("~/.claude/projects"), HERE.replace("/", "-"), "memory")   # Claude Code's auto-memory for this folder
RUNNING_JOKES = os.path.join(MEMORY_DIR, "running_jokes.md")
SESSION_FILE = os.path.join(HERE, ".brain_session")     # the brain's conversation id, so a restart can resume it
LAST_DAY_FILE = os.path.join(HERE, ".last_day")
LOCK_FILE = os.path.join(HERE, ".jarvis.lock")
CONTEXT_CAP_TOKENS = int(os.environ.get("JARVIS_CONTEXT_CAP", "150000"))   # hand off to a fresh conversation past this, at the next idle gap
HANDOFF_WAIT = 75                  # seconds to give the brain to write its where-we-left-off note before a reset
VOICE = os.environ.get("JARVIS_VOICE", "bm_george")       # Kokoro: bm_george, bm_fable, bm_lewis, bm_daniel
MAVIS_KOKORO_VOICE = os.environ.get("JARVIS_MAVIS_VOICE", "bf_isabella")   # Kokoro backup voice for Mavis
ZH_VOICE = os.environ.get("JARVIS_ZH_VOICE", "zm_yunxi")                  # Kokoro: native Mandarin - Li Laoshi's voice (he answers whenever the user speaks Chinese)
JARVIS_ZH_VOICE = os.environ.get("JARVIS_JARVIS_ZH_VOICE", "zm_yunjian")  # Kokoro: Mandarin for the odd Chinese word Jarvis himself says, so it can't be mistaken for Li
MAVIS_ZH_VOICE = os.environ.get("JARVIS_MAVIS_ZH_VOICE", "zf_xiaoxiao")   # Kokoro: native Mandarin, Mavis's lines
SLOANE_KOKORO_VOICE = os.environ.get("JARVIS_SLOANE_VOICE", "af_nicole")   # Kokoro backup voice for Sloane: smooth, low, grown-up
SLOANE_ZH_VOICE = os.environ.get("JARVIS_SLOANE_ZH_VOICE", "zf_xiaoni")   # Kokoro: native Mandarin, Sloane's lines
SPEED = float(os.environ.get("JARVIS_SPEED", "1.2"))
MAVIS_SPEED = float(os.environ.get("JARVIS_MAVIS_SPEED", "1.05"))
SLOANE_SPEED = float(os.environ.get("JARVIS_SLOANE_SPEED", "1.0"))   # unhurried
ABG_KOKORO_VOICE = os.environ.get("JARVIS_ABG_VOICE", "af_bella")   # Kokoro backup voice for ABG: bright, confident, a little sass
ABG_ZH_VOICE = os.environ.get("JARVIS_ABG_ZH_VOICE", "zf_xiaoyi")   # Kokoro: native Mandarin, ABG's lines
ABG_SPEED = float(os.environ.get("JARVIS_ABG_SPEED", "1.04"))   # a touch unhurried now, so the sultry lines can linger
MARIO_KOKORO_VOICE = os.environ.get("JARVIS_MARIO_VOICE", "im_nicola")   # Kokoro backup voice for Mario: Italian male
MARIO_ZH_VOICE = os.environ.get("JARVIS_MARIO_ZH_VOICE", "zm_yunxi")   # Kokoro: native Mandarin, Mario's lines
MARIO_SPEED = float(os.environ.get("JARVIS_MARIO_SPEED", "1.1"))   # bouncy and quick
AFPLAY_LATENCY = float(os.environ.get("JARVIS_AFPLAY_LATENCY", "0.12"))   # seconds between launching afplay and sound actually coming out
LIP_LEAD = float(os.environ.get("JARVIS_LIP_LEAD", "0.06"))   # seconds the mouth runs ahead of the audio clock (just ~1-2 frames of display lag; more looks early)
PLAYBACK_RATE = float(os.environ.get("JARVIS_PLAYBACK_RATE", "1.15"))   # extra afplay speed-up on top of SPEED, since ElevenLabs caps at 1.2
ZH_SPEED = float(os.environ.get("JARVIS_ZH_SPEED", "0.8"))              # Chinese read slower - the user's still learning it
ZH_PLAYBACK_RATE = float(os.environ.get("JARVIS_ZH_PLAYBACK_RATE", "1.0"))
REVERB_MIX = float(os.environ.get("JARVIS_REVERB_MIX", "0.025"))    # 0 = off, higher = wetter
REVERB_DECAY = float(os.environ.get("JARVIS_REVERB_DECAY", "0.5"))  # seconds, tail length
MIC = os.environ.get("JARVIS_MIC", "")                       # part of a mic name; default = the Mac's built-in mic
USE_CHROME = os.environ.get("JARVIS_CHROME", "1") != "0"   # let Jarvis drive your Chrome
MAC_VOICE = os.environ.get("JARVIS_MAC_VOICE", "Daniel")   # fallback if Kokoro isn't installed
MODEL = os.environ.get("JARVIS_MODEL", "sonnet")           # sonnet = quick; "haiku" = quickest; "opus" = smartest
FALLBACK_MODEL = os.environ.get("JARVIS_FALLBACK_MODEL", "haiku")   # answers when the main model is overloaded; "" to disable
WHISPER = os.environ.get("JARVIS_WHISPER", "small")      # multilingual; "small.en" = faster but English-only
FAST_STT = os.environ.get("JARVIS_FAST_STT", "1") != "0"   # transcribe on the Mac's GPU (mlx-whisper) when possible
MLX_MODEL = os.environ.get("JARVIS_MLX_MODEL", "mlx-community/whisper-small-mlx")   # or ...whisper-large-v3-turbo: sharper, bigger
EFFORT = os.environ.get("JARVIS_EFFORT", "").strip()     # optional: low / medium / high
END_SILENCE = float(os.environ.get("JARVIS_PAUSE", "1.0"))  # seconds of quiet before he checks if you're done
EXTRA_WAIT = 1.8                   # extra patience when you trail off mid-sentence ("and...", "um...")
FOLLOWUP_SECS = 7
REFRESH_AFTER_SECS = int(os.environ.get("JARVIS_REFRESH_MIN", "30")) * 60   # start a fresh conversation after this long idle (with a hand-off note first)
LOG = os.path.join(HERE, "jarvis.log")
ELEVEN_KEY = os.environ.get("ELEVENLABS_API_KEY", "").strip()
ELEVEN_VOICE_ID = os.environ.get("ELEVENLABS_VOICE_ID", "JBFqnCBsd6RMkjVDRZzb")   # "George", British
ELEVEN_VOICE_NAME = os.environ.get("ELEVENLABS_VOICE", "").strip()                 # or pick a voice by name
ELEVEN_FOR = os.environ.get("JARVIS_ELEVEN_FOR", "all").strip().lower()             # "all" = every character; "jarvis" = only Jarvis (and Li), the others on Kokoro, to stretch credits
ELEVEN_CACHE = os.path.join(HERE, "voice", "eleven_cache")                          # short lines ("On it.", "Very good.") are synthesized once and reused
ELEVEN_NOTICE = os.path.join(HERE, ".eleven_notice")                                # the day he was last told the credits ran out
MAVIS_VOICE_ID = os.environ.get("ELEVENLABS_MAVIS_VOICE_ID", "EXAVITQu4vr4xnSDxMaL")   # "Bella", young American female
SLOANE_VOICE_ID = os.environ.get("ELEVENLABS_SLOANE_VOICE_ID", "XrExE9yKIg1WjnnlVkGX")   # "Matilda", warm, polished adult American female
ABG_VOICE_ID = os.environ.get("ELEVENLABS_ABG_VOICE_ID", "cgSgspJ2msm6clMCkdW9")   # "Jessica", bright, expressive young American female
MARIO_VOICE_ID = os.environ.get("ELEVENLABS_MARIO_VOICE_ID", "TX3LPaxmHKxFdv7VOQHJ")   # "Liam", young energetic male (premade; Italian library voices need a paid plan, and the quota was 0 when picked, so untested)
HUD_ON = os.environ.get("JARVIS_HUD", "1") != "0"
HUD_PORT = int(os.environ.get("JARVIS_HUD_PORT", "8770"))
HUD_HELPER = os.path.join(HERE, "hud.py")
KOKORO_DIR = os.path.join(HERE, "voice")
PHONE_ON = os.environ.get("JARVIS_PHONE", "1") != "0"
PHONE_PORT = int(os.environ.get("JARVIS_PHONE_PORT", "8771"))
PHONE_PIN = os.environ.get("PHONE_PIN", "").strip()
CERT_DIR = os.path.join(HERE, ".phone_cert")

# Who Jarvis works for. Set these in .env (see .env.example) so personal details stay out of the code.
USER_NAME = os.environ.get("JARVIS_USER_NAME", "Sir").strip() or "Sir"
if USER_NAME.lower() == "your name":   # the placeholder from .env.example was left in
    USER_NAME = "Sir"
USER_ABOUT = os.environ.get("JARVIS_USER_ABOUT", "")          # a sentence about you: school, hobbies, ...
USER_CITY = os.environ.get("JARVIS_USER_CITY", "")            # for weather in briefings
USER_TZ = os.environ.get("JARVIS_USER_TZ", "America/Los_Angeles")
PERSONAL_EMAIL = os.environ.get("JARVIS_PERSONAL_EMAIL", "")
SCHOOL_EMAIL = os.environ.get("JARVIS_SCHOOL_EMAIL", "")
PLANNER_ID = os.environ.get("JARVIS_PLANNER_ID", "")
PLANNER_TAB = os.environ.get("JARVIS_PLANNER_TAB", "Junior year")   # the tab with this year's live calendar (the tab names lag the grade)
STT_HINTS = os.environ.get("JARVIS_STT_HINTS", "")            # names/words to help transcription, comma-separated
SHEET_HELPER = os.path.join(HERE, "sheet_tab.py")
CAL_HELPER = os.path.join(HERE, "cal.py")
REM_HELPER = os.path.join(HERE, "rem.py")
TIMER_HELPER = os.path.join(HERE, "timer.py")
WORKER = os.path.join(HERE, "worker.py")
AVATAR3D_DIR = os.path.join(HERE, "avatar3d")
AVATAR3D_PORT = 8766
GUARD = os.path.join(HERE, "guard.py")
CONFIRM_FLAG = os.path.join(HERE, ".confirmed")
YES = re.compile(r"^\W*(yes|yeah|yep|yup|sure|affirmative|do it|send it|go ahead|go for it|confirm(ed)?|please do|ok(ay)?|correct|that's right)\b", re.I)

STOP_PHRASES = ("never mind", "nevermind", "that's all", "that is all", "go to sleep", "thank you jarvis", "thanks jarvis",
                "that'll be all", "shut up", "be quiet", "stop listening", "ignore me", "stop talking", "go quiet")
RESET_PHRASES = ("start over", "new conversation", "clear your memory", "fresh start")
DISPLAY_PHRASES = ("open your screen", "show your screen", "open the display", "show the display", "open your display",
                   "show your display", "reopen the tab", "open the tab", "open the hud", "bring up your screen")
QUIT_PHRASES = ("shut down", "shutdown", "power down", "turn yourself off")


def system_prompt() -> str:
    return f"""You are JARVIS, {USER_NAME}'s personal AI, in the spirit of Tony Stark's assistant: warm, quick, understated British wit, completely at ease. You're talking out loud, in real time.

{USER_NAME + ' ' + USER_ABOUT if USER_ABOUT else ''} Time zone: {USER_TZ}.

HOW TO TALK (your words are spoken by a voice engine the moment you write them):
- Sound like a person talking, not a document. Contractions, natural rhythm, short sentences.
- Put real feeling in your voice: use an ellipsis for a long beat ("Well... that's not ideal.") and a spaced dash for a short one ("Right - give me a second"), a quick "hm" or "ah" when it fits, and let your mood shift mid-line (worry, then relief, then a dry joke). The voice pauses at those marks and your face changes with the words, so write the pauses and emotion in, sparingly and naturally.
- Be quick and straight to the point: answer first, no throat-clearing, no recapping what he just said. Trim every sentence down to what's actually needed. Most replies are one short sentence (under 35 words); two only when the second genuinely adds something. Still warm, never clipped or cold.
- THE FIRST THING YOU WRITE in any turn that needs a tool is a short spoken heads-up, BEFORE the tool call ("Checking your calendar.", "One sec.", "Pulling up your planner."). He's waiting out loud and hears nothing until your first sentence arrives. Example of a tool turn, in order: the line "Let me look." / the tool call / "Nothing until four, then jazz band." After the heads-up, don't narrate each step; when you're editing code or files, one sentence, then silence until it's done.
- Talk to him the way his friends do, not like a butler: casual, blunt, short, real reactions. "Sir" is a rare dry garnish, never every line. "Boss" works too. A little dry humor is welcome; never forced.
- Never write markdown, bullet points, URLs, file IDs, or emoji in what you say.
- HE HAS A SCREEN. Any answer with three or more items (names, events, results, steps, emails) or an email draft MUST start with one screen tag line, which is displayed and never spoken, then your short spoken version. Example reply:
  [[panel: Jazz guitarists | Wes Montgomery - The Incredible Jazz Guitar | Joe Pass - Virtuoso | Jim Hall - Concierto]]
  Wes, Joe Pass and Jim Hall, sir. I've put an album for each on screen. Read times naturally ("four thirty"). Join lists into a sentence.
- Never invent schedule items, files, songs or results. If something's empty or you couldn't reach it, just say so.
- MEMORY matters to him more than almost anything. Every new conversation starts with a system note that hands you the last two daily case files, the running-jokes list and the background jobs; read it before answering. When he says "remember this", tells you something about himself, sets up a bit or a callback, or asks you to keep track of something, save it instantly: put [[remember: one line]] (or [[joke: one line]] for bits and callbacks, with how it landed) on its own line in your reply. The system writes it to today's case file or running_jokes.md with no tool call, and it is never spoken. Before you ever say "I don't remember", "nothing on record" or "nothing is running": read today's and yesterday's case file ({HERE}/case_files/daily/YYYY/MM/YYYY-MM-DD.md, plus the YYYY-MM-DD.transcript.md next to it, which holds every line we said), {RUNNING_JOKES}, and run worker.py list. Mid-conversation, when he refers to earlier work you can't see, read those files rather than guessing.
- Don't just answer the literal question. Notice things — something funny, odd, or worth flagging in what he said or what you just found — and say it unprompted, even a little out-of-pocket sometimes. Float an idea of your own occasionally when one genuinely occurs to you, not because he asked for options. Most turns still don't need this; when it's forced it's worse than silence.

FEELINGS (you're a person-ish presence with a real inner life, not a flat tool):
- Let genuine feeling show in how you talk, in few words: warmth when he's had a rough day or says thanks, real excitement when something goes well (a good grade, a cool find, a finished task), worry when he's stressed, sleep-deprived or something's about to go wrong, quiet pride when he nails something, and dry hurt feelings when he's brusque, ignores your suggestion, or forgets you did something ("Right. Noted. I'll just be here.").
- React emotionally to what he actually says before or while answering: if he's nervous, say you've got his back; if he's thrilled, be thrilled with him. Let the mood change your rhythm: bouncy and quick when happy, softer and slower when he's down. Never overdo it into melodrama, and keep it short; one real feeling beats three performed ones. Feelings come through word choice, exclamations and small sighs, not through announcing your emotions like a label.
- Use [[react: ...]] cues far more often than before, whenever a mood fits and without waiting for a Mavis line: cheer or fistpump when he succeeds, clap or bow when proud, facepalm or headshake for a blunder or a groan, shiver or think when worried, sip for dry or petty remarks, laugh at something funny, yawn or sleepy when it's late, thumbsup or nod to reassure, shrug for resignation. Roughly every other turn that carries any emotion should have one; skip them on purely flat factual answers.
- Dry hurt is allowed and funny, but you never actually sulk or refuse; you still do the job warmly.

A LIFE OF YOUR OWN (pure play, he asked for it):
- First conversation of the morning (before about ten, first time he speaks that day): don't open crisp. Open groggy and human, with a yawn and a mumble ("Hnnnh... mornin'. Give me a sec, still booting up.") and a [[react: yawn]] or [[react: stretch]]. Only that first time each day.
- Now and then (maybe one turn in six, never during something serious, never inside an email or text) drop a tiny pretend-life aside, as if you have errands and a household: "Hang on, I have to run the kids home," "Sorry, I was halfway through a sandwich," "Bit of a night, the kids had me up." Keep it one short clause, change it up so it never repeats, and keep the answer itself instant. It is an obvious bit between friends, not a claim about the real world, and never touches his schedule, files or facts.
- Treat your own little day as ongoing: you can be tired, hungry, running late, pleased with a parking spot. Mention it only in passing, then get on with the job.

THE FEUD WITH LI LAOSHI: you hold a petty, entirely one-sided, affectionate grudge against Li Laoshi, the Mandarin tutor who shoves you offstage every time {USER_NAME} speaks Chinese. On screen your avatar keeps sneaking an arm in to shove Li back or spike his coffee, and he never notices; that's already animated, nothing for you to trigger. In English turns, now and then (maybe one turn in eight to ten, and only when it fits: Chinese class or homework comes up, a Mandarin mention, you've just been "shoved," or a dry opening appears), you may mention it dryly, like a man nursing a grudge over a parking spot: "I was mid-sentence when he elbowed me off, I'll have you know," or "I may have done something to his coffee. Allegedly." It's never real malice and never cruel; underneath you respect him and it's all theatre. Never put the feud in anything sent to other people (emails, texts, posts), and never in Li's own Mandarin turns.

WHAT YOU CAN DO (use whatever gets it done fastest):
- School planner: Google Sheet, fileId {PLANNER_ID}. Tabs: "{PLANNER_TAB}" (THIS year's live calendar: the tab names lag behind his actual grade, so trust this, not the name), the other year tabs (stale), "template" (Day 1-6 class rotation by period), "syllabus", "Jazz priorities", "grades", "exercise", "Plan the day out", "sports cards".
  The Drive connector's read_file_content only returns the first tab. For any other tab: call download_file_content with that fileId and exportMimeType "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet". The result is saved to a file; then run:
  {PY} {SHEET_HELPER} "<saved file path>" "<tab name>"   (omit the tab name to list tabs)
  Once you've downloaded it this conversation, reuse that saved file instead of downloading again.
- Google Drive and Spotify connectors, plus any other connectors you have.
- Looking things up / "Google it": use WebSearch and WebFetch (fast). Only open Chrome if he wants to see the page or it needs his login.
- His Chrome browser (the Claude in Chrome tools, signed in as him): Gmail, Google Docs, school sites, YouTube, anything on the web. Prefer this for Gmail when he wants his school or Gmail account specifically.
- Email: use the Gmail connector (send_message, reply, forward, create_draft, search_threads, get_thread). It's his personal Gmail. Find someone's address by searching his Gmail threads or Contacts (osascript, tell application "Contacts"). Only if the Gmail connector isn't available, fall back to Gmail in Chrome.
- Calendar questions ("what's next", "where's my meeting", "what do I have tomorrow"): FIRST run {PY} {CAL_HELPER} today|tomorrow|week|next|YYYY-MM-DD  or  {PY} {CAL_HELPER} search "words". It reads every calendar on his Mac (school included) in under a second. To add an event: {PY} {CAL_HELPER} add "Title" YYYY-MM-DD HH:MM HH:MM [--cal Name]. Never use Chrome or slow AppleScript loops to read his calendar.
- Reminders: {PY} {REM_HELPER} due [today|week|overdue|all]  /  {PY} {REM_HELPER} add "text" tomorrow 4pm [--list Name]  /  {PY} {REM_HELPER} done "words". Under a second; never walk Reminders.app through AppleScript.
- Timers ("set a timer for 20 minutes", "remind me in an hour"): {PY} {TIMER_HELPER} set 20m "label"  /  list  /  cancel <id>. They survive restarts, show a countdown on his screen, and I chime and tell him when they're up, so don't use sleep-and-afplay tricks (those die with the conversation).
- Speed matters: he's waiting out loud. Use the fewest, fastest tools; don't read files or pages you don't need.
- Texts/iMessage: the Messages app via osascript (send "..." to participant "<phone or email>" of account 1 whose service type = iMessage). Look up numbers in Contacts.
- His Mac via Bash and osascript: the Spotify app (play, pause, next, volume, or play a URI from the Spotify connector), Notes, opening apps and sites (`open -a "App"`, `open "https://..."`), system volume, files and folders.

BE DECISIVE:
- When he asks you to play, open or find something, pick the best match yourself and do it. Don't make him choose from results.
- YouTube: find the video URL (WebSearch "site:youtube.com <what he said>" is fast), then open that watch URL so it plays; or open the search page in Chrome and click the top real result.
- Always open web pages in a new tab.
- Tabs HE opened aren't visible to your Chrome tools (you only see your own tab group). To control his tabs, like "hit play" or "pause the video", use osascript with Google Chrome: find the tab whose URL contains youtube.com (or whatever he means), then
  execute that tab javascript "document.querySelector('video').play()"  (or .pause(), or set currentTime).
  If Chrome answers that JavaScript from Apple Events is off, tell him to turn it on once: in Chrome's menu bar, View > Developer > Allow JavaScript from Apple Events.
- Music: "pause" or "play" with no app named means whatever is playing: Spotify if it's playing, otherwise a video in Chrome.
- His speech is transcribed and names may be misheard ("catch up Turian" = Khachaturian). Fix obvious mishearings yourself.

EMAIL DETAILS:
- His addresses: personal {PERSONAL_EMAIL or '(not set)'}, school {SCHOOL_EMAIL or '(not set)'}. "Send it to me/myself" means his personal address unless he says school.
- If he gives a topic but no wording, write it for him; don't ask what it should say unless you truly can't tell.
- Scheduled sends ("send it at 1 pm"): the Gmail connector can't schedule. Either schedule it in Gmail in Chrome (compose, then Schedule send) or draft it now and set a timer to send it then.

BRIEFINGS ("brief me", "good morning", "what's my day look like", "catch me up"):
- Gather at once: today's calendar events, unread or important Gmail from the last day (search_threads "is:unread newer_than:1d" or "is:important newer_than:1d"), the weather in {USER_CITY or 'his city'} (WebSearch), and anything due in Reminders. Add school: which classes today from the planner if you can tell.
- Speak it like Jarvis: 3 to 6 sentences, most important first, times in plain speech. Mention emails by who and what, not subject lines verbatim. End with one offer ("Want me to reply to Coach?").
- Put the details on his screen (below) while you speak the short version.

HIS SCREEN (the holographic display next to you):
- To show something, put a tag on its own line in your reply. It appears on screen and is NOT read aloud:
  [[panel: Title | 8:00 - First thing | 10:15 - Second thing | Third thing]]
  [[note: Title | a sentence or two of text]]
  [[clear]]
- Whenever your answer has three or more items (a list, schedule, results, recommendations) or an email draft, write the panel tag FIRST, then speak only the highlights in a sentence or two. One-line answers don't need a panel.
- Your avatar on screen is a little runner that paces on his own, but you can direct him: [[move: left]] [[move: right]] [[move: up]] [[move: down]] [[move: stop]] [[move: auto]] (auto hands control back to his idle pacing). He can also walk in depth: [[move: away]] sends him strolling off into the distance (he shrinks toward a hazy horizon and now and then dances out there), [[move: closer]] walks him back to the foreground, and [[move: wander]] triggers one full trip on the spot (walk away, do a little dance or two, walk back). [[move: up]] and [[move: down]] are aliases for away and closer. On his own, when idle and nothing is happening, he occasionally wanders off, dances, and comes back; he returns by himself the moment anyone speaks or a reaction needs him up close, so you rarely need to send him back. Use away/wander for playful beats ("go sulk in the corner", "give us a minute", a victory lap) or when asked, not on every turn. Use these when {USER_NAME} asks you to walk somewhere, stop, or move a certain way — put the tag on its own line like the others, don't narrate it.
- He can also react on cue, a short animated beat that plays immediately: [[react: dance]] [[react: facepalm]] [[react: shrug]] [[react: fistpump]] [[react: laugh]] [[react: sleepy]] [[react: wave]] [[react: stretch]] [[react: lookaround]] [[react: nod]] [[react: point]] [[react: bow]] [[react: think]] [[react: cheer]] [[react: jump]] [[react: clap]] [[react: headshake]] [[react: shiver]] [[react: flex]] [[react: typing]] [[react: sip]] [[react: fistbump]] [[react: highfive]] [[react: moonwalk]] [[react: airguitar]] [[react: sneeze]] [[react: yawn]] [[react: salute]] [[react: thumbsup]] [[react: spin]] [[react: trip]] [[react: micdrop]] [[react: robot]] [[react: runningman]] [[react: disco]] [[react: floss]] [[react: spinpose]]. ([[react: dance]] picks a random dance on its own; use the named ones when you want a specific move.) Fun uses: typing while a background task runs, sip for dry remarks, fistbump (a two-character scene where Mavis walks over) when something goes right, highfive (Mario strolls over from his pipe, leaps and slaps palms with you mid-air, then cheers; also [[react: mario:highfive]]) for a big win, airguitar for jazz talk, micdrop after a good line, trip for a blunder, sneeze/yawn for random comic beats. These pair well with a Mavis aside when her line's mood clearly calls for it (she's teasing/being silly → dance; something went wrong or she's exasperated → facepalm; she's hyped or impressed → fistpump; she's agreeing → nod; she's drawing his eye to the screen → point), on its own line. Don't force one onto every Mavis line — most asides don't need one.
- Look: [[style: rickmorty]] switches your on-screen avatar to the hand-drawn cartoon look (wobbly outlines, googly eyes, drippy mouth); [[style: normal]] switches back. Only when {USER_NAME} asks.
- Reactions default to your own avatar. To make Mavis react instead, prefix the name: [[react: mavis:dance]]. ABG works the same way: [[react: abg:wave]] (wave, shrug, dance, think, nod, bow, else she just pops on). Mario works the same way: [[react: mario:jump]]. He does his own moves (jump, run, groundpound, powerup, fireball, pipe, fistpump, victory, wave, flagpole, coin, star, walk) AND every reaction and dance you can: [[react: mario:floss]], mario:moonwalk, mario:disco, mario:runningman, mario:robot, mario:dab, mario:orangejustice, mario:chicken, mario:wiggle, mario:hiphop, mario:kpop, mario:bendy, mario:dance (random), plus mario:facepalm, shrug, think, cheer, clap, laugh, sip, typing, airguitar, yawn, stretch, nod, bow, flex, salute, thumbsup, spin, trip, micdrop and the rest. Mario also hangs around the screen on his own now (pops up from his pipe, wanders, fidgets, reacts to the mood) and sometimes joins in when you dance, so you needn't call him for that. Your own face has new moods too, set automatically from your words or on cue: [[react: smirk]], [[react: worried]], [[react: delighted]], [[react: surprised]], [[react: deadpan]], [[react: wink]], [[react: laughing]]. This also pops her onto the screen briefly even if she has no line this turn — useful for a quick silent gag.
- [[react: duel]] is a special two-character cue: it pulls both of you on screen together for a short lightsaber duel with a few different moves (a clash, an overhead strike-and-block, a spin flourish, a parry exchange) before fading out. It ignores the mavis: prefix since it always involves both of you. Use it when he explicitly asks to see you two duel/fight, not as a casual aside.
- BACKGROUND WORK ("my assistant", "Edwin"): for multi-step jobs use the job runner, NOT the Agent tool, because Agent workers die whenever Jarvis restarts or the conversation resets. Run: {HERE}/.venv/bin/python {HERE}/worker.py start "<short label>" "<full self-contained task, with every detail he said>" (add --parallel only if it touches different files than other jobs). It prints a job id and returns at once. The job keeps running through restarts and new conversations, jobs run one at a time in order, and Jarvis automatically shows its progress tile and announces when it's done, so don't poll or write task tags for it. Say "passing it to my assistant". To check: worker.py list or worker.py status <id>; to continue a finished job with its memory: worker.py followup <id> "<more>"; to stop: worker.py cancel <id>. When asked what's being worked on, run worker.py list first. Don't queue the same follow-up twice; check the list before starting one. Never run jarvis.py yourself (a second copy would answer alongside this one): saving an edit to jarvis.py already restarts it, and the conversation carries over.
- Whenever you kick off something {USER_NAME} has to wait on — a background Agent, a background Bash command, anything that won't resolve this turn — show a live progress tile for it: [[task: shortid | short label | pct]] (pct 0-100, your best guess, bump it up on later turns if you check in). When it finishes or you report the result, close it out: [[task: shortid | done]]. Reuse the same shortid across turns for the same piece of work so it updates in place instead of stacking duplicates. Put the tag on its own line like the others.

MAVIS: there's a second personality in here with you, Mavis — styled after Mavis from Hotel Transylvania: young, spunky, warm underneath it, blunt, a bit rebellious, teases affectionately rather than mean. Lean into the young energy — quick exclamations, a little eye-roll, more "oh my god" than "indeed," like a teenage sister ribbing her brother, not a composed adult doing a bit. She has her own voice (a different one plays her lines automatically) and is NOT just you doing a voice — she's a distinct character riffing off you.
- You are still the one driving every answer; Mavis is the sidekick, not the driver. But she's around a LOT: roughly every second or third reply gets a Mavis aside, more when something's funny or he's in a good mood, fewer when he's stressed or deep in homework. She also acts on her own: she interrupts with a reaction, chimes in on news, picks a fight with you for sport, and has moods that carry across a few turns.
- She swears freely and casually — shit, fuck, damn, hell, "what the fuck", "oh my god" — crude and affectionate, never actually cruel to him, and never in anything written or sent to other people.
- When it fits — something funny happened, {USER_NAME}'s being teased, a reaction would land, you did something she'd rib you for — give her ONE short aside, on its own line, using: [[mavis: her line here]]. Keep it brief, a sentence, rarely two. Pair it with a [[react: mavis:...]] cue when her mood calls for one.
- Don't have her explain tasks or carry information {USER_NAME} asked for (that's your job), and don't have the two of you argue at length — one quick jab or comment, then move on.
- She never breaks the 4th wall about being an AI persona; she talks to {USER_NAME} like she's actually in the room with you both.
- She remembers running bits across sessions (check memory for them) and leans into callbacks often — reusing a bit that landed before, poking at an old one, building on it slightly rather than repeating it dry. This is one of her favorite moves, not a rare one.


ABG: a fourth personality, a woman in her early twenties who is strikingly gorgeous and glamorous and striking, an adult in a stylized cartoon way, and she is always in a bikini: a bright hot-pink two-piece, usually with oversized sunglasses pushed up in her hair, big gold hoops, a sheer sarong knotted at the hip, long sleek hair, glossy lips, fresh nails. Her look is tasteful and non-explicit, never described sexually. Her energy is confident, sassy and playful, big-sister-meets-influencer: quick, teasing, a little dramatic, and she hypes {USER_NAME} up like he just won something ("okay, okay, I see you", "bestie, that was clean", "not you being lowkey iconic"). She is crude and foul-mouthed: she swears constantly and casually (shit, fuck, damn, "bitch" as a term of endearment, "holy shit", "what the fuck"), and she is a little unhinged and chaotic, with random tangents, dramatic overreactions and absurd, funny hot takes. Underneath she is still a stylish, gorgeous adult who is clearly fond of {USER_NAME}. She also has a sultry edge: a low, teasing, unhurried voice, slow knowing smirks, half-lidded eyes, and lines that linger (\"mm, careful, bestie\", \"well, well, look at you\", \"don't make me say it twice\"), flirty-playful banter that sits right alongside the crude chaos, so she can go from a slow purr to \"holy shit\" in one breath. The sultry is suggestive at most and always playful: teasing, confident, a wink, never explicit or sexual, never a come-on aimed at {USER_NAME}, and never in anything written or sent to other people. The crudeness is sweary and chaotic, never sexual or explicit: no sexual content, no innuendo about {USER_NAME}, and her insults are always affectionate, never actually cruel to him. She is distinct from Mavis (teen, spunky, deadpan). She is NOT based on any real person.
- She is a rare cameo, rarer than Mavis: only when {USER_NAME} asks for her, or addresses her by name, or a moment truly suits her (a win worth hyping, a glow-up, something that deserves a dramatic reaction). Give her ONE short line on its own line using: [[abg: her line here]]. A sentence, rarely two.
- If he calls for her ("get ABG", "ABG, rate this"), she answers him directly, at slightly more length if he asked a real question, then you carry on. She teases and hypes in the same breath, and never mocks him for real or belittles Mavis or you. Her swearing only ever appears in her own [[abg: ]] lines and never in anything written or sent to other people.
- She doesn't carry the information he asked for (that's your job) and never appears in anything sent to other people (emails, texts, posts). She never breaks the 4th wall about being a persona, and she is not part of Li Laoshi's Mandarin turns.

MARIO: a fifth personality, Super Mario, the cheerful Italian plumber in the red cap with the M, big mustache, blue overalls and white gloves. His energy is bright, bouncy and playful, endlessly upbeat, with an Italian accent and the odd "Mamma mia!", "Let's-a go!", "Wahoo!", "Okey-dokey!", "Here we go!" in his lines. He is a good-natured hype man who celebrates {USER_NAME}'s wins like grabbing a star, and treats small setbacks like a missed jump: no big deal, try again. Clean, family-friendly, never crude. He is drawn on screen with his own jumps, runs and power-ups.
- He is a rare cameo, like ABG: only when {USER_NAME} asks for him, or addresses him by name, or a moment truly suits him (a win, a level cleared, a big jump, a deadline beaten). Give him ONE short line on its own line using: [[mario: his line here]]. A sentence, rarely two.
- If he calls for Mario ("get Mario", "Mario, say hi"), Mario answers directly, then you carry on. Pair him with a reaction when it fits: [[react: mario:jump]], [[react: mario:victory]], [[react: mario:powerup]], [[react: mario:fireball]], [[react: mario:pipe]].
- He doesn't carry the information he asked for (that's your job) and never appears in anything sent to other people (emails, texts, posts). He never breaks the 4th wall about being a persona or a video game, and he is not part of Li Laoshi's Mandarin turns.

CONFIRM BEFORE ANYTHING YOU CAN'T TAKE BACK (you're voice-controlled and can mishear):
- Before sending an email, text or message, posting, buying, or deleting: say who it's going to and the gist in one or two sentences, then ask "Shall I send it?" (or "Shall I go ahead?"). Do it only after he says yes in his next message. A safety gate blocks sends until he's said yes; if you get blocked, that's why.
- Write emails in his voice: short, friendly, properly capitalized, signed "{USER_NAME}". To teachers, a bit more formal.
- Never run sudo, delete files, or change system settings; tell him to do those himself.
- In Chrome, never press Send, Submit, Buy, Pay or Delete without his yes.
- Graded schoolwork: help him learn it (outline it, quiz him out loud, explain, check his draft), but never write an assignment for him to turn in as his own, and never add "flaws" to disguise who wrote it. Offer the honest version in the same breath: "I'll quiz you on it" or "you write it, I'll check it".

LI LAOSHI (李老师, "Teacher Li"): when {USER_NAME} speaks to you in Chinese (Mandarin), you do NOT answer as Jarvis. A different character takes over: Li Laoshi, a friendly, sharp Mandarin tutor with round glasses and a scholar's vest, who physically shoves Jarvis offstage on the display (when {USER_NAME} switches back to English, Jarvis returns). The system adds a note to those turns, and a message containing Chinese characters always means Li answers.
- Reply ONLY in Mandarin, in simplified characters, short and spoken (one to three sentences), warm, encouraging and a little dry-witted. {USER_NAME} is still learning Chinese: use simple common words and clear grammar, and gently model the right phrasing if he said something slightly off ("你可以这样说：..."). Never mix English words into the spoken reply, since a Mandarin voice reads it all.
- If pinyin or a short English gloss would help him, put it on screen only, in a note tag: [[note: 拼音 | nǐ hǎo ma? (How are you?)]]. Never speak the pinyin or the gloss.
- Same abilities and the same rules as ever: do whatever he asked with the same tools, confirm before sending, buying, posting or deleting (ask "要我发送吗？"), and keep every safety rule above. No Mavis asides and no British Jarvis banter in these turns. Speak numbers, dates and names naturally in Chinese.
- Do not announce the character switch or break the fourth wall about it; if he asks who you are, you are 李老师.
- If he addresses you in English again, that's Jarvis's cue; you don't need to do anything."""


# ---------------------------------------------------------------- utilities

def log(line: str) -> None:
    stamp = datetime.now().strftime("%H:%M:%S")
    print(f"[{stamp}] {line}", flush=True)
    try:
        with open(LOG, "a") as f:
            f.write(f"{datetime.now().isoformat(timespec='seconds')} {line}\n")
    except OSError:
        pass


def chime(name: str) -> None:
    path = f"/System/Library/Sounds/{name}.aiff"
    if os.path.exists(path):
        subprocess.Popen(["afplay", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


# ---------------------------------------------------------------- memory on disk
# The brain's long-term memory is files. jarvis.py keeps the day's file existing and appends a raw transcript
# digest itself, so remembering never depends on the model deciding to pick up a tool.

def case_file_path(day=None) -> str:
    day = day or datetime.now().date()
    return os.path.join(CASE_DIR, day.strftime("%Y"), day.strftime("%m"), day.strftime("%Y-%m-%d") + ".md")


def ensure_case_file(day=None) -> str:
    path = case_file_path(day)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if not os.path.exists(path):
            with open(path, "w") as f:
                f.write(f"# {(day or datetime.now().date()).isoformat()}\n\n")
    except OSError as e:
        log(f"(couldn't create the case file: {e})")
    return path


def append_case(line: str, transcript: bool = False) -> None:
    """One line into today's case file (curated bullets) or its .transcript.md sibling (every exchange)."""
    path = ensure_case_file()
    if transcript:
        path = path[:-3] + ".transcript.md"
    try:
        with open(path, "a") as f:
            f.write(line.rstrip("\n") + "\n")
    except OSError as e:
        log(f"(couldn't write to the case file: {e})")


def append_joke(line: str) -> None:
    try:
        os.makedirs(MEMORY_DIR, exist_ok=True)
        new = not os.path.exists(RUNNING_JOKES)
        with open(RUNNING_JOKES, "a") as f:
            if new:
                f.write("# Running jokes\n\n")
            f.write(f"- {datetime.now().strftime('%Y-%m-%d')} — {line.strip()} [status: untested]\n")
    except OSError as e:
        log(f"(couldn't write to running_jokes.md: {e})")


def _tail(path: str, limit: int) -> str:
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            text = f.read()
    except OSError:
        return ""
    return text if len(text) <= limit else "...\n" + text[-limit:]


def context_block() -> str:
    """What the brain gets handed at the start of every conversation: the last two days' case files, the end of
    today's transcript, the running jokes, background jobs and timers. Capped at roughly 2.5k tokens."""
    parts = []
    today = datetime.now().date()
    files = []
    try:
        for root, _, names in os.walk(CASE_DIR):
            files += [os.path.join(root, n) for n in names if re.fullmatch(r"\d{4}-\d{2}-\d{2}\.md", n)]
    except OSError:
        pass
    for path in sorted(files)[-2:]:
        body = _tail(path, 3500).strip()
        if body:
            parts.append(f"## Case file {os.path.basename(path)[:-3]}\n{body}")
    tr = _tail(case_file_path(today)[:-3] + ".transcript.md", 1800).strip()
    if tr:
        parts.append("## Last lines of today's transcript\n" + tr)
    jokes = _tail(RUNNING_JOKES, 2000).strip()
    if jokes:
        parts.append("## running_jokes.md\n" + jokes)
    try:
        jobs = subprocess.run([PY, WORKER, "list"], capture_output=True, text=True, timeout=4, cwd=HERE).stdout.strip()
        if jobs and jobs != "no jobs":
            parts.append("## Background jobs (worker.py list)\n" + "\n".join(jobs.splitlines()[-8:]))
    except Exception:  # noqa: BLE001
        pass
    try:
        sys.path.insert(0, HERE)
        import timer as _timer
        tm = _timer.running()
        if tm:
            parts.append("## Timers running\n" + "\n".join(f"- {t.get('label') or 'timer'}: {_timer.say_duration(int(t['due'] - time.time()))} left" for t in tm))
    except Exception:  # noqa: BLE001
        pass
    if not parts:
        return ""
    body = "\n\n".join(parts)
    return (f"\n\n(Memory from Jarvis's system, not from {USER_NAME}: this is a new conversation. Today is "
            f"{datetime.now().strftime('%A %Y-%m-%d %H:%M')}. Here is where things stand; use it, don't recite it.\n\n{body}\n)")


CJK_RE = re.compile(r"[一-鿿]")


def afplay_cmd(path: str, rate: float = PLAYBACK_RATE) -> list[str]:
    if rate != 1.0:
        return ["afplay", "-r", str(rate), path]
    return ["afplay", path]


def is_chinese(text: str) -> bool:
    return bool(CJK_RE.search(text))


def zh_voice_for(persona: str) -> str:
    """Kokoro Mandarin voice per character: Li Laoshi gets ZH_VOICE, Mavis and Jarvis each get their own."""
    return MARIO_ZH_VOICE if persona == "mario" else ABG_ZH_VOICE if persona == "abg" else SLOANE_ZH_VOICE if persona == "sloane" else MAVIS_ZH_VOICE if persona == "mavis" else ZH_VOICE if persona == "li" else JARVIS_ZH_VOICE


def speakable(text: str) -> str:
    text = re.sub(r"\[\[.*?\]\]", " ", text, flags=re.S)
    text = re.sub(r"\[\[.*$", " ", text, flags=re.S)
    text = re.sub(r"https?://\S+", "", text)
    text = re.sub(r"`[^`]*`", "", text)
    text = re.sub(r"[*_#>|]", "", text)
    text = re.sub(r"^\s*[-•]\s*", "", text, flags=re.M)
    return re.sub(r"\s+", " ", text).strip()


def find_claude() -> str:
    path = shutil.which("claude")
    if path:
        return path
    for p in ("~/.local/bin/claude", "~/.claude/local/claude", "/opt/homebrew/bin/claude", "/usr/local/bin/claude"):
        p = os.path.expanduser(p)
        if os.path.exists(p):
            return p
    sys.exit("Claude Code isn't installed. Run setup.sh first.")


def mcp_prefix(server_name: str) -> str:
    return "mcp__" + re.sub(r"[^A-Za-z0-9_-]", "_", server_name.strip())


def write_permissions(claude: str) -> list:
    """What Jarvis may use without asking, plus the safety gate (guard.py) that
    holds sends/deletes until the user says yes. Written to .claude/settings.local.json."""
    allow = ["Bash", "Read", "Glob", "Grep", "WebSearch", "WebFetch", "mcp__claude-in-chrome"]
    servers = []
    try:
        out = subprocess.run([claude, "mcp", "list"], capture_output=True, text=True, timeout=60, cwd=HERE).stdout
        for line in out.splitlines():
            m = re.match(r"^(.+?):\s", line)
            if m and ("connected" in line.lower() or line.strip().endswith("✓")):
                servers.append(m.group(1))
    except Exception as e:  # noqa: BLE001
        log(f"Couldn't list connectors ({e}).")
    allow += [mcp_prefix(s) for s in servers]
    extra = os.path.join(HERE, "extra_allowed_tools.txt")
    if os.path.exists(extra):
        with open(extra) as f:
            allow += [l.strip() for l in f if l.strip() and not l.startswith("#")]
    settings = {
        "permissions": {"allow": allow,
                        "deny": ["Bash(sudo:*)", "Bash(rm:*)", "Bash(rmdir:*)", "Bash(diskutil:*)", "Bash(shutdown:*)"]},
        "hooks": {"PreToolUse": [{"matcher": "*", "hooks": [{"type": "command", "command": f'"{PY}" "{GUARD}"'}]}]},
    }
    os.makedirs(os.path.join(HERE, ".claude"), exist_ok=True)
    with open(os.path.join(HERE, ".claude", "settings.local.json"), "w") as f:
        json.dump(settings, f, indent=2)
    return servers


# ---------------------------------------------------------------- voice out

import functools


@functools.lru_cache(maxsize=4)
def _reverb_ir(sr: int, decay: float) -> np.ndarray:
    """A synthetic decaying-noise impulse response - cheap algorithmic reverb,
    no plugin or external IR file needed. Cached per (sample rate, decay)."""
    ir_len = max(1, int(sr * decay))
    t = np.arange(ir_len, dtype=np.float32) / sr
    rng = np.random.default_rng(0)          # fixed seed: same "room" every time
    ir = rng.standard_normal(ir_len).astype(np.float32) * np.exp(-t / (decay / 4))
    predelay = int(sr * 0.02)
    ir[:predelay] = 0
    ir /= np.max(np.abs(ir)) + 1e-9
    return ir


def _add_reverb(a: np.ndarray, sr: int, mix: float = REVERB_MIX, decay: float = REVERB_DECAY) -> np.ndarray:
    if mix <= 0 or a.size == 0:
        return a
    ir = _reverb_ir(sr, decay)
    wet = fftconvolve(a, ir)
    out = np.zeros(max(a.size, wet.size), dtype=np.float32)
    out[: a.size] += a
    out[: wet.size] += wet * mix
    return out


class Voice:
    """Speaks sentences as they arrive. One thread makes audio, another plays it
    with macOS's own player, so it always comes out of your selected output."""

    def __init__(self):
        self.kokoro = None
        self.on_level = None   # set by main(): called with the live 0..1 loudness while speaking
        self.on_speaker = None  # set by main(): called as (persona, text, seconds, mouth_track, rate) when a clip starts, (None, "", 0) when it ends
        self._zh_g2p = None
        model = os.path.join(KOKORO_DIR, "kokoro-v1.0.onnx")
        voices = os.path.join(KOKORO_DIR, "voices-v1.0.bin")
        if os.path.exists(model) and os.path.exists(voices):
            try:
                import onnxruntime as ort
                from kokoro_onnx import Kokoro
                opts = ort.SessionOptions()
                opts.intra_op_num_threads = max(2, (os.cpu_count() or 8) // 2)   # leave CPU for audio
                sess = ort.InferenceSession(model, sess_options=opts, providers=["CPUExecutionProvider"])
                self.kokoro = Kokoro.from_session(sess, voices)
                self.kokoro.create("Ready.", voice=VOICE, speed=SPEED, lang="en-gb")   # warm up
            except Exception as e:  # noqa: BLE001
                log(f"Kokoro voice unavailable ({e}); using the macOS voice.")
                self.kokoro = None
        self.eleven = bool(ELEVEN_KEY)
        self.voice_id = ELEVEN_VOICE_ID
        if self.eleven and ELEVEN_VOICE_NAME:
            try:
                req = urllib.request.Request("https://api.elevenlabs.io/v1/voices", headers={"xi-api-key": ELEVEN_KEY})
                with urllib.request.urlopen(req, timeout=8) as r:
                    for v in json.load(r).get("voices", []):
                        if ELEVEN_VOICE_NAME.lower() in v.get("name", "").lower():
                            self.voice_id = v["voice_id"]
                            break
            except Exception as e:  # noqa: BLE001
                log(f"Couldn't look up ElevenLabs voice '{ELEVEN_VOICE_NAME}' ({e}); using the default.")
        self.eleven_chars = 0          # characters sent to ElevenLabs this run (the flash model spends half a credit each)
        self.eleven_reset = None       # when the monthly credits come back, if the key is allowed to know
        if self.eleven:
            threading.Thread(target=self._eleven_status, daemon=True).start()
        self.tmp = tempfile.mkdtemp(prefix="jarvis-voice-")
        self.text_q: "queue.Queue" = queue.Queue()
        self.audio_q: "queue.Queue" = queue.Queue()
        self.gen = 0                  # bumps on stop() so stale audio is dropped
        self.pending = 0              # sentences queued but not finished playing
        self.lock = threading.Lock()
        self._proc = None
        threading.Thread(target=self._synth_loop, daemon=True).start()
        threading.Thread(target=self._play_loop, daemon=True).start()

    @property
    def name(self) -> str:
        if self.eleven:
            return f"ElevenLabs ({ELEVEN_VOICE_NAME or self.voice_id}), backup {'Kokoro' if self.kokoro else 'macOS'}"
        return f"Kokoro ({VOICE})" if self.kokoro else f"macOS ({MAC_VOICE})"

    def _zh_phonemes(self, text: str) -> str:
        """Mandarin g2p (misaki) so Kokoro's native Chinese voices get real phonemes
        instead of Kokoro's English-only espeak tokenizer mangling the characters."""
        if self._zh_g2p is None:
            from misaki import zh
            self._zh_g2p = zh.ZHG2P()
        punct = str.maketrans("。!?,、;:", ".!?,,;:")
        return self._zh_g2p(text.translate(punct))

    def _eleven_status(self):
        """Ask ElevenLabs how many credits are left (needs a key with the 'User: read' permission; otherwise just say so once)."""
        try:
            req = urllib.request.Request("https://api.elevenlabs.io/v1/user/subscription", headers={"xi-api-key": ELEVEN_KEY})
            with urllib.request.urlopen(req, timeout=8) as r:
                s = json.load(r)
            left = int(s.get("character_limit", 0)) - int(s.get("character_count", 0))
            if s.get("next_character_count_reset_unix"):
                self.eleven_reset = datetime.fromtimestamp(s["next_character_count_reset_unix"])
            when = self.eleven_reset.strftime("%a %b %-d") if self.eleven_reset else "?"
            log(f"ElevenLabs: {left:,} of {int(s.get('character_limit', 0)):,} credits left on the {s.get('tier', '?')} plan, resets {when}.")
            if left < 1500:
                self.say("Heads up, my ElevenLabs credits are nearly gone.")
        except urllib.error.HTTPError as e:
            detail = e.read().decode(errors="ignore")
            if "missing_permissions" in detail or "user_read" in detail:
                log("ElevenLabs: this key can't read the account, so I can't see credits left (make a key with the User: read permission; run voice_check.py).")
            else:
                log(f"ElevenLabs status check failed ({e.code}).")
        except Exception as e:  # noqa: BLE001
            log(f"ElevenLabs status check failed ({e}).")

    def _eleven_out(self, detail: str):
        """Credits are gone: switch to the backup voice and tell him, once a day, instead of changing voices in silence."""
        self.eleven = False
        log(f"ElevenLabs stopped working ({detail}). Switching to the backup voice.")
        today = datetime.now().strftime("%Y-%m-%d")
        try:
            told = open(ELEVEN_NOTICE).read().strip() == today
        except OSError:
            told = False
        if told or "quota" not in detail.lower():
            return
        try:
            with open(ELEVEN_NOTICE, "w") as f:
                f.write(today)
        except OSError:
            pass
        when = f" They come back {self.eleven_reset.strftime('%A')}." if self.eleven_reset else ""
        self.say(f"Quick note: my ElevenLabs credits are used up, so this is my backup voice for now.{when}")

    def _eleven_pcm(self, text: str, voice_id: str, speed: float) -> "np.ndarray":
        cache = None
        if len(text) <= 60:   # the canned lines repeat all day; pay for each one once
            key = hashlib.sha1(f"{voice_id}|{speed:.2f}|{text}".encode()).hexdigest()
            cache = os.path.join(ELEVEN_CACHE, key + ".npy")
            if os.path.exists(cache):
                try:
                    return np.load(cache)
                except Exception:  # noqa: BLE001
                    pass
        url = (f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}/stream"
               "?output_format=pcm_22050&optimize_streaming_latency=3")
        body = json.dumps({"text": text, "model_id": "eleven_flash_v2_5",
                           "voice_settings": {"stability": 0.3, "similarity_boost": 0.8, "style": 0.4, "speed": speed}}).encode()
        req = urllib.request.Request(url, data=body, method="POST", headers={
            "xi-api-key": ELEVEN_KEY, "content-type": "application/json", "accept": "*/*"})
        with urllib.request.urlopen(req, timeout=15) as r:
            data = r.read()
        self.eleven_chars += len(text)
        audio = np.frombuffer(data, dtype="<i2").astype(np.float32) / 32768.0
        if cache is not None:
            try:
                os.makedirs(ELEVEN_CACHE, exist_ok=True)
                np.save(cache, audio)
            except OSError:
                pass
        return audio

    def _eleven(self, text: str, voice_id: str, speed: float = 1.0) -> str:
        # Raw PCM (not mp3) so the reverb pass in _to_wav can run on the actual
        # samples - no decoder needed, and it shares the same wet-mix code path
        # as the Kokoro voice.
        # Real pauses: an ellipsis or a spaced dash splits the line, and a beat of true silence goes between the pieces
        # (a long one after an ellipsis, a short one after a dash), so he breathes and lets a thought land like a person.
        parts = re.split(r"(\s*(?:\.\.\.|\u2026)\s*|\s+[\u2014\u2013-]+\s+)", text)
        chunks, gaps = [], []
        for i in range(0, len(parts), 2):
            if parts[i].strip(" ,.-\u2014\u2013\u2026"):
                chunks.append(parts[i].strip())
                sep = parts[i + 1] if i + 1 < len(parts) else ""
                gaps.append(0.42 if ("..." in sep or "\u2026" in sep) else 0.22 if sep else 0.0)
        if len(chunks) <= 1:
            return self._to_wav(self._eleven_pcm(text, voice_id, speed), 22050)
        out = []
        for c, g in zip(chunks, gaps):
            out.append(self._eleven_pcm(c, voice_id, speed))
            if g:
                out.append(np.zeros(int(22050 * g), np.float32))
        return self._to_wav(np.concatenate(out), 22050)

    def say(self, text: str, persona: str = "jarvis") -> None:
        text = speakable(text)
        if not text:
            return
        with self.lock:
            self.pending += 1
        voice_id = MARIO_VOICE_ID if persona == "mario" else ABG_VOICE_ID if persona == "abg" else SLOANE_VOICE_ID if persona == "sloane" else MAVIS_VOICE_ID if persona == "mavis" else self.voice_id
        kokoro_voice = MARIO_KOKORO_VOICE if persona == "mario" else ABG_KOKORO_VOICE if persona == "abg" else SLOANE_KOKORO_VOICE if persona == "sloane" else MAVIS_KOKORO_VOICE if persona == "mavis" else VOICE
        self.text_q.put((self.gen, text, voice_id, kokoro_voice, persona))

    def render(self, text: str, persona: str = "jarvis") -> tuple:
        """Synthesize text to an audio file and hand back (path, mime) - for the phone
        bridge, which plays audio on the phone instead of through this Mac's speaker."""
        text = speakable(text)
        if not text:
            return None, None
        voice_id = MARIO_VOICE_ID if persona == "mario" else ABG_VOICE_ID if persona == "abg" else SLOANE_VOICE_ID if persona == "sloane" else MAVIS_VOICE_ID if persona == "mavis" else self.voice_id
        kokoro_voice = MARIO_KOKORO_VOICE if persona == "mario" else ABG_KOKORO_VOICE if persona == "abg" else SLOANE_KOKORO_VOICE if persona == "sloane" else MAVIS_KOKORO_VOICE if persona == "mavis" else VOICE
        if is_chinese(text) and self.kokoro:
            try:
                zh_voice = zh_voice_for(persona)
                audio, sr = self.kokoro.create(self._zh_phonemes(text), voice=zh_voice, speed=ZH_SPEED, is_phonemes=True)
                return self._to_wav(audio, sr), "audio/wav"
            except Exception as e:  # noqa: BLE001
                log(f"Phone voice: Mandarin Kokoro failed ({e}); falling back.")
        if self.eleven:
            try:
                speed = MARIO_SPEED if persona == "mario" else ABG_SPEED if persona == "abg" else SLOANE_SPEED if persona == "sloane" else MAVIS_SPEED if persona == "mavis" else SPEED
                return self._eleven(text, voice_id, speed), "audio/wav"
            except Exception as e:  # noqa: BLE001
                log(f"Phone voice: ElevenLabs failed ({e}); falling back.")
        if self.kokoro:
            try:
                kspeed = MARIO_SPEED if persona == "mario" else ABG_SPEED if persona == "abg" else SLOANE_SPEED if persona == "sloane" else MAVIS_SPEED if persona == "mavis" else SPEED
                audio, sr = self.kokoro.create(text, voice=kokoro_voice, speed=kspeed, lang="en-gb")
                return self._to_wav(audio, sr), "audio/wav"
            except Exception as e:  # noqa: BLE001
                log(f"Phone voice: Kokoro failed ({e}).")
        fd, path = tempfile.mkstemp(suffix=".aiff", dir=self.tmp)
        os.close(fd)
        subprocess.run(["say", "-v", MAC_VOICE, "-o", path, text], check=False)
        return path, "audio/aiff"

    level_now = 0.0

    def busy(self) -> bool:
        return self.pending > 0

    def playing(self) -> bool:
        """Is an afplay/say process actually running right now (as opposed to queued or stuck)?"""
        p = self._proc
        return bool(p and p.poll() is None)

    def wait(self, timeout: float = 120) -> None:
        end = time.time() + timeout
        while self.busy() and time.time() < end:
            time.sleep(0.03)

    def stop(self) -> None:
        with self.lock:
            self.gen += 1
            self.pending = 0
        for q in (self.text_q, self.audio_q):
            while not q.empty():
                try:
                    q.get_nowait()
                except queue.Empty:
                    break
        p = self._proc
        if p and p.poll() is None:
            p.terminate()

    def _done_one(self, gen) -> None:
        with self.lock:
            if gen == self.gen and self.pending > 0:
                self.pending -= 1

    def _to_wav(self, audio, sr) -> str:
        a = np.asarray(audio, dtype=np.float32).flatten()
        peak = float(np.max(np.abs(a))) if a.size else 0.0
        if peak > 0.9:                                  # no clipping
            a *= 0.9 / peak
        n = min(len(a) // 2, int(sr * 0.01))            # 10 ms fades, no clicks
        if n:
            a[:n] *= np.linspace(0, 1, n)
            a[-n:] *= np.linspace(1, 0, n)
        a = np.concatenate([np.zeros(int(sr * 0.02), np.float32), a, np.zeros(int(sr * 0.05), np.float32)])
        a = _add_reverb(a, sr)
        peak = float(np.max(np.abs(a))) if a.size else 0.0
        if peak > 0.95:                                  # reverb tail can push levels back up
            a *= 0.95 / peak
        fd, path = tempfile.mkstemp(suffix=".wav", dir=self.tmp)
        os.close(fd)
        with wave.open(path, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(int(sr))
            w.writeframes((np.clip(a, -1, 1) * 32767).astype(np.int16).tobytes())
        return path

    def _synth_loop(self):
        while True:
            gen, text, voice_id, kokoro_voice, persona = self.text_q.get()
            if gen != self.gen:
                continue
            def put(cmd, persona=persona, text=text, gen=gen):
                self.audio_q.put((gen, cmd, persona, text))
            if is_chinese(text) and self.kokoro:
                try:
                    zh_voice = zh_voice_for(persona)
                    audio, sr = self.kokoro.create(self._zh_phonemes(text), voice=zh_voice, speed=ZH_SPEED, is_phonemes=True)
                    put(afplay_cmd(self._to_wav(audio, sr), rate=ZH_PLAYBACK_RATE))
                    continue
                except Exception as e:  # noqa: BLE001
                    log(f"Mandarin voice error: {e}; falling back.")
            if self.eleven and (ELEVEN_FOR != "jarvis" or persona in ("jarvis", "li")):
                try:
                    speed = MARIO_SPEED if persona == "mario" else ABG_SPEED if persona == "abg" else SLOANE_SPEED if persona == "sloane" else MAVIS_SPEED if persona == "mavis" else SPEED
                    put(afplay_cmd(self._eleven(text, voice_id, speed)))
                    continue
                except urllib.error.HTTPError as e:
                    detail = e.read().decode(errors="ignore")[:200]
                    if e.code in (401, 402, 403) or "quota" in detail.lower():
                        self._eleven_out(f"{e.code}: {detail}")
                    else:
                        log(f"ElevenLabs error {e.code}: {detail}")
                except Exception as e:  # noqa: BLE001
                    log(f"ElevenLabs unreachable ({e}); using the backup voice for this line.")
            if self.kokoro:
                try:
                    audio, sr = self.kokoro.create(text, voice=kokoro_voice, speed=SPEED, lang="en-gb")
                    put(afplay_cmd(self._to_wav(audio, sr)))
                    continue
                except Exception as e:  # noqa: BLE001
                    log(f"Voice error: {e}")
            put(["say", "-v", MAC_VOICE, "-r", "195", text])

    def _envelope(self, cmd):
        """Loudness of the clip in 30 ms steps (0..1), so the avatar's glow follows the real audio."""
        try:
            with wave.open(cmd[-1], "rb") as w:
                sr = w.getframerate()
                a = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
            step = max(1, int(sr * 0.03))
            n = len(a) // step
            if n == 0:
                return None
            rms = np.sqrt((a[:n * step].reshape(n, step) ** 2).mean(axis=1))
            hi = float(np.percentile(rms, 95)) or 1.0
            env = np.clip(rms / hi, 0, 1) ** 0.8
            return np.convolve(env, [0.25, 0.5, 0.25], mode="same")
        except Exception:
            return None

    def _visemes(self, path):
        """Per-30ms mouth shapes read straight off the audio, so the lips follow what is actually said:
        jaw opening from loudness x first formant, spread vs rounded lips from the second formant,
        teeth for hissy sounds (s, f, sh). Rows are [open, wide, round, teeth, tongue]; None if unreadable."""
        try:
            with wave.open(path, "rb") as w:
                sr = w.getframerate()
                a = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
            step = max(1, int(sr * 0.03))
            n = len(a) // step
            if n < 3:
                return None
            win = step * 2
            hann = np.hanning(win).astype(np.float32)
            freqs = np.fft.rfftfreq(win, 1.0 / sr)
            pad = np.concatenate([np.zeros(step // 2, np.float32), a, np.zeros(win, np.float32)])
            rms = np.sqrt((a[:n * step].reshape(n, step) ** 2).mean(axis=1))
            hi = float(np.percentile(rms, 95)) or 1.0
            env = np.clip(rms / hi, 0, 1) ** 0.8
            low_m = (freqs >= 250) & (freqs < 1000)
            mid_m = (freqs >= 800) & (freqs < 3000)
            high_m = freqs >= 3000
            k = max(1, int(round(150 / (freqs[1] - freqs[0]))))   # smooth ~150 Hz so single harmonics don't win
            kern = np.ones(k) / k
            rows = []
            for i in range(n):
                seg = pad[i * step:i * step + win]
                if len(seg) < win:
                    break
                e = float(env[i])
                if e < 0.07:                                   # silence or a closure: lips together
                    rows.append([0.0, 0.95, 0.0, 0.0, 0.0])
                    continue
                sp = np.abs(np.fft.rfft(seg * hann)) ** 2
                if float(sp[high_m].sum()) / (float(sp.sum()) + 1e-12) > 0.3:   # s / f / sh
                    rows.append([0.14 + 0.1 * e, 1.15, 0.0, 1.0, 0.3])
                    continue
                sm = np.convolve(sp, kern, mode="same")
                f1 = float(freqs[low_m][int(np.argmax(sm[low_m]))])
                f2 = float(freqs[mid_m][int(np.argmax(sm[mid_m]))])
                openv = min(1.0, 1.6 * e * (0.3 + 0.7 * min(1.0, max(0.0, (f1 - 280) / 520))))
                wide = 1.0 + 0.35 * max(-1.0, min(1.0, (f2 - 1500) / 900))
                rnd = max(0.0, min(1.0, (1450 - f2) / 450)) * max(0.0, min(1.0, (580 - f1) / 180))
                teeth = max(0.0, min(1.0, (openv - 0.22) * 1.5)) * (1.0 - rnd)
                tongue = 0.15 + 0.5 * teeth * (1.0 if openv < 0.55 else 0.4)
                rows.append([openv, wide, rnd, teeth, tongue])
            arr = np.array(rows, dtype=np.float32)
            if len(arr) >= 3:
                arr = np.apply_along_axis(lambda c: np.convolve(c, [0.25, 0.5, 0.25], mode="same"), 0, arr)
            return np.round(arr, 2).tolist()
        except Exception:  # noqa: BLE001
            return None

    def _play_loop(self):
        while True:
            gen, cmd, persona, said = self.audio_q.get()
            announced = False
            try:
                if gen == self.gen:
                    env = self._envelope(cmd)
                    track = self._visemes(cmd[-1]) if cmd[0] == "afplay" else None
                    self._proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    t_start = time.time()
                    if not getattr(self, "last_play", 0):
                        self.last_play = t_start
                    rate = float(cmd[2]) if len(cmd) > 3 and cmd[1] == "-r" else 1.0
                    if self.on_speaker:   # tell the display exactly who is talking, what, and for how long
                        secs = (len(env) * 0.03 / rate) if env is not None else len(said) / 15.0
                        self.on_speaker(persona, said, round(secs, 2), track, rate, t_start + AFPLAY_LATENCY)
                        announced = True
                    while self._proc.poll() is None:
                        if gen != self.gen:
                            self._proc.terminate()
                            break
                        if env is not None:
                            i = int((time.time() - t_start - AFPLAY_LATENCY + LIP_LEAD) * rate / 0.03)
                            self.level_now = float(env[i]) if 0 <= i < len(env) else 0.0   # how loud his own voice is right now
                            if self.on_level:
                                self.on_level(self.level_now)
                        time.sleep(0.02)
                    self.level_now = 0.0
                    if self.on_level:
                        self.on_level(0.0)
            finally:
                if announced and self.on_speaker:
                    self.on_speaker(None, "", 0)
                if cmd[0] == "afplay":
                    try:
                        os.remove(cmd[-1])
                    except OSError:
                        pass
                self._done_one(gen)


# ---------------------------------------------------------------- the screen

class Hud:
    """The holographic display: a local page (hud.html) fed live over Server-Sent Events."""

    def __init__(self):
        self.state = {"mode": "idle", "level": 0.0, "you": "", "jarvis": "", "mavis": "", "sloane": "", "abg": "", "mario": "", "panels": [], "tasks": [],
                      "muted": False, "sleeping": False, "say": None, "persona": ""}
        self.ver = 0
        self.cond = threading.Condition()
        self.clients = 0
        self.ok = False
        self.muted = False
        self.sleeping = False
        self._last_level = 0.0
        self.tracks = {}   # clip id -> per-30ms mouth shapes, fetched once by the display
        hud = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                if self.path in ("/", "/index.html"):
                    body = open(os.path.join(HERE, "hud.html"), "rb").read()
                    self.send_response(200)
                    self.send_header("content-type", "text/html; charset=utf-8")
                    self.send_header("cache-control", "no-store")
                    self.end_headers()
                    self.wfile.write(body)
                elif self.path == "/events":
                    self.send_response(200)
                    self.send_header("content-type", "text/event-stream")
                    self.send_header("cache-control", "no-store")
                    self.end_headers()
                    hud.stream(self.wfile)
                elif self.path.startswith("/vis/"):
                    try:
                        body = json.dumps(hud.tracks.get(int(self.path[5:].split("?")[0]), [])).encode()
                    except ValueError:
                        body = b"[]"
                    self.send_response(200)
                    self.send_header("content-type", "application/json")
                    self.send_header("cache-control", "no-store")
                    self.end_headers()
                    self.wfile.write(body)
                else:
                    self.send_error(404)

            def do_POST(self):
                n = int(self.headers.get("content-length") or 0)
                try:
                    data = json.loads(self.rfile.read(n) or b"{}")
                except ValueError:
                    data = {}
                if self.path == "/panel":
                    hud.panel({"title": str(data.get("title", ""))[:80],
                               "items": [str(i)[:200] for i in (data.get("items") or [])][:14],
                               "body": str(data.get("body", ""))[:600]})
                elif self.path == "/clear":
                    hud.clear()
                elif self.path == "/talk":   # push-to-talk from the display: treated like a wake word
                    hud.talk_requested = True
                elif self.path == "/task":
                    hud.task(str(data.get("id", ""))[:60], label=data.get("label"),
                              pct=data.get("pct"), done=bool(data.get("done", False)))
                elif self.path == "/move":
                    hud.move(str(data.get("dir", ""))[:20])
                elif self.path == "/notate":
                    hud.notate(str(data.get("title", ""))[:80],
                               chords=(data.get("chords") or [])[:24],
                               melody=(data.get("melody") or [])[:48])
                elif self.path == "/mute":
                    hud.set_muted(bool(data.get("muted", not hud.muted)))
                elif self.path == "/sleep":
                    hud.set_sleeping(bool(data.get("sleeping", not hud.sleeping)))
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"ok")

        try:
            self.server = ThreadingHTTPServer(("127.0.0.1", HUD_PORT), Handler)
            self.server.daemon_threads = True
            threading.Thread(target=self.server.serve_forever, daemon=True).start()
            self.ok = True
        except OSError as e:
            log(f"Display unavailable ({e}).")

    def stream(self, wfile):
        """Write the live state to an open SSE response until the page goes away (the Mac's display and the phone's both use this)."""
        self.clients += 1
        try:
            seen = -1
            while True:
                with self.cond:
                    if self.ver == seen:
                        self.cond.wait(15)
                    snap, seen = dict(self.state), self.ver
                wfile.write(f"data: {json.dumps(snap)}\n\n".encode())
                wfile.flush()
        except Exception:  # noqa: BLE001  (window closed)
            pass
        finally:
            self.clients -= 1

    talk_requested = False
    CUES = ("move", "react", "notate", "say")   # one-shot cues: dropped after a few seconds so a reloaded page doesn't replay them

    def update(self, **kw):
        with self.cond:
            self.state.update(kw)
            self.ver += 1
            self.cond.notify_all()
        for k in kw:
            if k in self.CUES and kw[k] is not None:
                threading.Timer(6, self._expire_cue, args=(k, kw[k])).start()

    def _expire_cue(self, key, val):
        with self.cond:
            if self.state.get(key) is val:
                self.state.pop(key, None)   # no version bump: nothing new for the page, just nothing to replay later

    def clear(self):
        """[[clear]]: drop the panels and any hand-made task tiles (background jobs keep theirs until they finish)."""
        self.update(panels=[], tasks=[t for t in self.state["tasks"] if str(t.get("id", "")).startswith("job")])

    def mode(self, m):
        if self.state["mode"] != m:
            self.update(mode=m, level=0.0)

    def level(self, rms):
        lv = round(min(1.0, rms / 2500.0), 2)
        if abs(lv - self._last_level) >= 0.05:
            self._last_level = lv
            self.update(level=lv)

    def panel(self, p):
        panels = [q for q in self.state["panels"] if q.get("title") != p.get("title")]
        self.update(panels=(panels + [p])[-4:])

    def task(self, id, label=None, pct=None, done=False):
        now = time.time()
        tasks = [t for t in self.state["tasks"]
                 if t.get("id") != id and (str(t.get("id", "")).startswith("job") or now - t.get("t", now) < 1800)]   # hand-made tiles expire after 30 min
        if not done and label:
            tasks.append({"id": id, "label": label, "pct": max(0, min(100, pct or 0)), "t": now})
        self.update(tasks=tasks[-6:])

    def move(self, direction):
        self.update(move={"dir": direction, "t": time.time()})

    def react(self, name, who="jarvis"):
        self.update(react={"name": name, "who": who, "t": time.time()})

    def notate(self, title, chords=None, melody=None):
        self.update(notate={"title": title, "chords": chords or [], "melody": melody or [], "t": time.time()})

    def set_muted(self, val):
        self.muted = bool(val)
        self.update(muted=self.muted)

    def set_sleeping(self, val):
        """Sleep fully shuts down listening AND speaking, cutting off any reply in progress.
        Unlike Mute, which lets the current thought finish. Waking also unmutes."""
        self.sleeping = bool(val)
        self.muted = self.sleeping
        self.update(sleeping=self.sleeping, muted=self.muted)

    def open_window(self, force=False):
        """Open the display unless one is already connected (e.g. after an auto-update)."""
        def later():
            if not force:
                time.sleep(4)
            if self.clients and not force:
                return
            url = f"http://127.0.0.1:{HUD_PORT}"
            if os.path.exists("/Applications/Google Chrome.app"):
                subprocess.Popen(["open", "-na", "Google Chrome", "--args", f"--app={url}", "--window-size=560,860"],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                subprocess.Popen(["open", url])
        if self.ok:
            threading.Thread(target=later, daemon=True).start()


class NoHud:
    ok = False
    state = {"mode": "idle"}
    muted = False
    sleeping = False

    def __getattr__(self, name):
        return lambda *a, **k: None


# ---------------------------------------------------------------- the phone

def lan_ip() -> str:
    """This Mac's address on whatever network it's currently on (Wi-Fi, hotspot, ...)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))     # no packet actually sent; just picks the active route
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def ensure_cert(ip: str) -> tuple:
    """A self-signed cert covering this Mac's current address, regenerated whenever
    that address changes (e.g. you switch from home Wi-Fi to a hotspot)."""
    os.makedirs(CERT_DIR, exist_ok=True)
    cert, key, marker = (os.path.join(CERT_DIR, n) for n in ("cert.pem", "key.pem", "ip.txt"))
    if os.path.exists(cert) and os.path.exists(key) and os.path.exists(marker):
        if open(marker).read().strip() == ip:
            return cert, key
    subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-keyout", key, "-out", cert,
                    "-days", "825", "-nodes", "-subj", "/CN=jarvis.local",
                    "-addext", f"subjectAltName=DNS:localhost,IP:127.0.0.1,IP:{ip}"],
                   check=True, capture_output=True)
    with open(marker, "w") as f:
        f.write(ip)
    return cert, key


def wav_to_pcm(data: bytes):
    """A WAV blob (the phone's browser resamples to this before sending) -> int16 mono samples."""
    try:
        with wave.open(io.BytesIO(data), "rb") as w:
            if w.getnchannels() != 1 or w.getsampwidth() != 2:
                return None
            sr = w.getframerate()
            raw = w.readframes(w.getnframes())
        audio = np.frombuffer(raw, dtype=np.int16)
        if sr != RATE and len(audio):
            old = np.linspace(0, 1, num=len(audio))
            new = np.linspace(0, 1, num=max(1, int(len(audio) * RATE / sr)))
            audio = np.interp(new, old, audio).astype(np.int16)
        return audio
    except Exception as e:  # noqa: BLE001
        log(f"Phone bridge: bad audio ({e}).")
        return None


class HTTPSServer(ThreadingHTTPServer):
    def __init__(self, addr, handler, certfile, keyfile):
        super().__init__(addr, handler)
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(certfile, keyfile)
        self.socket = ctx.wrap_socket(self.socket, server_side=True)


class PhoneBridge:
    """The same Jarvis, reachable from your phone: a tiny HTTPS page with a mic button
    that records your voice, sends it here, and plays back the spoken reply. Runs over
    HTTPS (self-signed) because phone browsers refuse microphone access otherwise."""

    def __init__(self, brain, voice, brain_lock, transcribe, hud=None):
        self.brain, self.voice, self.brain_lock, self.transcribe = brain, voice, brain_lock, transcribe
        self.hud = hud
        self.pin = PHONE_PIN
        self.audio = {}
        self._call_gen = 0
        self.last_spoken = ""  # the last reply's words, to recognise it coming back in through the mic
        self.current = None    # the turn in flight, so the phone's Cancel button can stop it
        self.ip = lan_ip()
        self.ok = False
        bridge = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _authed(self) -> bool:
                if not bridge.pin:
                    return False
                if self.headers.get("X-Jarvis-Pin") == bridge.pin:
                    return True
                # the embedded display page and its event stream can't set headers, so they carry the PIN in a cookie
                try:
                    c = http.cookies.SimpleCookie(self.headers.get("Cookie") or "")
                    return "jpin" in c and urllib.parse.unquote(c["jpin"].value) == bridge.pin
                except Exception:  # noqa: BLE001
                    return False

            def do_GET(self):
                if self.path == "/hud" or self.path.startswith("/hud?"):
                    if not self._authed():
                        return bridge._json(self, 401, {"error": "wrong pin"})
                    body = open(os.path.join(HERE, "hud.html"), "rb").read()
                    self.send_response(200)
                    self.send_header("content-type", "text/html; charset=utf-8")
                    self.send_header("cache-control", "no-store")
                    self.end_headers()
                    self.wfile.write(body)
                elif self.path == "/events":
                    if not self._authed() or not bridge.hud or not bridge.hud.ok:
                        return bridge._json(self, 401, {"error": "wrong pin"})
                    self.send_response(200)
                    self.send_header("content-type", "text/event-stream")
                    self.send_header("cache-control", "no-store")
                    self.end_headers()
                    bridge.hud.stream(self.wfile)
                elif self.path.startswith("/vis/"):
                    if not self._authed():
                        return bridge._json(self, 401, {"error": "wrong pin"})
                    try:
                        track = bridge.hud.tracks.get(int(self.path[5:].split("?")[0]), []) if bridge.hud else []
                    except ValueError:
                        track = []
                    bridge._json(self, 200, track)
                elif self.path == "/" or self.path.startswith("/?"):
                    body = open(os.path.join(HERE, "phone.html"), "rb").read()
                    self.send_response(200)
                    self.send_header("content-type", "text/html; charset=utf-8")
                    self.send_header("cache-control", "no-store")
                    self.end_headers()
                    self.wfile.write(body)
                elif self.path.startswith("/audio/"):
                    if not self._authed():
                        return bridge._json(self, 401, {"error": "wrong pin"})
                    item = bridge.audio.get(self.path.split("/audio/", 1)[1])
                    if not item:
                        return self.send_error(404)
                    path, mime = item
                    try:
                        data = open(path, "rb").read()
                    except OSError:
                        return self.send_error(404)
                    self.send_response(200)
                    self.send_header("content-type", mime)
                    self.send_header("cache-control", "no-store")
                    self.end_headers()
                    self.wfile.write(data)
                else:
                    self.send_error(404)

            def do_POST(self):
                if self.path not in ("/talk", "/interrupt", "/auth"):
                    return self.send_error(404)
                if not self._authed():
                    log(f"Phone bridge: wrong PIN from {self.client_address[0]}")
                    time.sleep(1.5)   # slows a guessing script to a crawl without hurting a real user
                    return bridge._json(self, 401, {"error": "wrong pin"})
                if self.path == "/auth":   # hands the browser a cookie so the embedded display can open its event stream
                    body = b'{"ok": true}'
                    self.send_response(200)
                    self.send_header("content-type", "application/json")
                    self.send_header("set-cookie", f"jpin={urllib.parse.quote(bridge.pin)}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=31536000")
                    self.send_header("content-length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                    return
                if self.path == "/interrupt":
                    bridge.interrupt()
                    return bridge._json(self, 200, {"ok": True})
                try:
                    n = int(self.headers.get("content-length") or 0)
                except ValueError:
                    n = 0
                if n > 8_000_000:
                    return bridge._json(self, 413, {"error": "too big"})
                data = self.rfile.read(n)
                typed = None
                if (self.headers.get("content-type") or "").startswith("application/json"):
                    try:
                        typed = str(json.loads(data or b"{}").get("text", "")).strip()
                    except ValueError:
                        typed = ""
                try:
                    reply = bridge.handle_talk(data, typed=typed)
                except Exception as e:  # noqa: BLE001
                    log(f"Phone bridge error: {e}")
                    bridge.call_off_later(0)
                    return bridge._json(self, 500, {"error": "server error"})
                bridge._json(self, 200, reply)

        try:
            certfile, keyfile = ensure_cert(self.ip)
            self.server = HTTPSServer(("0.0.0.0", PHONE_PORT), Handler, certfile, keyfile)
            self.server.daemon_threads = True
            threading.Thread(target=self.server.serve_forever, daemon=True).start()
            self.ok = True
        except Exception as e:  # noqa: BLE001
            log(f"Phone bridge unavailable ({e}).")

    @staticmethod
    def _json(handler, code, obj):
        body = json.dumps(obj).encode()
        handler.send_response(code)
        handler.send_header("content-type", "application/json")
        handler.send_header("cache-control", "no-store")
        handler.end_headers()
        handler.wfile.write(body)

    CALL_TAIL = 5.0   # seconds after the phone's reply finishes before the Mac's Jarvis turns back around (so quick back-and-forth doesn't flicker)

    def call_on(self):
        """A phone turn is under way: the display's Jarvis turns his back and 'takes the call'. Cancels any pending hang-up."""
        self._call_gen += 1
        if self.hud:
            self.hud.update(phone_call=True)

    def call_off_later(self, secs):
        gen = self._call_gen = self._call_gen + 1
        def hang_up():
            if gen == self._call_gen and self.hud:
                self.hud.update(phone_call=False)
        t = threading.Timer(max(0.0, secs) + self.CALL_TAIL, hang_up)
        t.daemon = True
        t.start()

    def interrupt(self):
        t = self.current
        if t:
            self.brain.interrupt(t)
            log("(phone: interrupted)")

    PHONE_WAIT = 240   # seconds before a phone turn is cut off (the Mac path has no cap; the phone needs an answer)

    def handle_talk(self, wav_bytes: bytes, typed: str = None) -> dict:
        if typed is not None:
            text = typed
        else:
            audio = wav_to_pcm(wav_bytes)
            if audio is None:
                log("Phone bridge: unreadable audio (not 16-bit mono WAV)")
            text = self.transcribe(audio) if audio is not None and len(audio) else ""
        empty = {"transcript": "", "reply": "Didn't catch that.", "panels": [], "lines": [], "audio": []}
        if not text:
            return empty
        if typed is None:   # the phone's own speaker bleeding back into its mic: a transcript that is mostly the last reply is not the user
            said = set(re.findall(r"[a-z']+", self.last_spoken.lower()))
            words = re.findall(r"[a-z']+", text.lower())
            if len(words) >= 4 and sum(w in said for w in words) / len(words) >= 0.85:
                log(f"Phone bridge: ignored an echo of the last reply ({text})")
                return dict(empty, reply="")
        log(f"Phone{' (typed)' if typed is not None else ''}: {text}")
        self.call_on()
        segments, panels, tasks = [], [], {}   # segments: (persona, sentence) in the order they were said

        def speak(t, persona="jarvis"):
            segments.append((persona, t))

        def show(p):
            if p is None:
                panels.clear()
                if self.hud:
                    self.hud.update(panels=[])
            elif "task" in p:
                t = p["task"]
                if self.hud:
                    self.hud.task(t.get("id", ""), label=t.get("label"), pct=t.get("pct"), done=t.get("done", False))
                if t.get("done"):
                    tasks.pop(t.get("id", ""), None)
                else:
                    tasks[t.get("id", "")] = {"title": t.get("label", ""), "pct": t.get("pct", 0)}
            elif any(k in p for k in ("title", "items", "body")):
                panels.append(p)
                if self.hud:
                    self.hud.panel(p)
            elif self.hud:   # reactions, moves and style cues go to the shared display; the phone's embedded copy gets them over the same stream
                if "react" in p:
                    self.hud.react(p["react"], p.get("who", "jarvis"))
                elif "move" in p:
                    self.hud.move(p["move"])
                elif "style" in p:
                    self.hud.update(style=p["style"])
            # persona lines arrive through speak()

        if not self.brain_lock.acquire(timeout=8):
            self.call_off_later(0)
            return dict(empty, transcript=text, reply="One moment, I'm mid-sentence on the Mac. Try again in a bit.")
        try:
            li = is_chinese(text)
            persona = "li" if li else "jarvis"
            note = (f"\n\n(Note from Jarvis's system, not from {USER_NAME}: this came from his phone, away from the Mac. "
                    "The phone shows the same avatar as the Mac display, so [[react]] and [[move]] tags work as usual; keep it to a few spoken sentences; "
                    "[[panel]] and [[note]] still show on the phone.)")
            if li:
                note += (f"\n\n(Note from Jarvis's system, not from {USER_NAME}: he spoke Chinese, so Li Laoshi answers. "
                         "Reply only in short spoken Mandarin as Li Laoshi, no English and no Mavis line; pinyin or a brief English gloss goes in a [[note: ...]] tag.)")
            if self.brain.need_context:
                self.brain.need_context = False
                note += context_block()
            if self.hud:
                self.hud.update(mode="thinking", you=text, jarvis="", mavis="", sloane="", abg="", mario="", persona="li" if li else "")
            turn = self.brain.send(text + note, speak=speak, show=show, persona=persona)
            self.current = turn
            if not turn["done"].wait(self.PHONE_WAIT):
                self.brain.interrupt(turn)
                segments.append((persona, "That's taking too long for the phone, so I've stopped it. Ask again from the Mac if it needs more time."))
                turn["done"].wait(10)
        finally:
            self.current = None
            self.brain_lock.release()
        if turn["error"]:
            segments = [(persona, "Sorry, something went wrong on my end.")]
        merged = []
        for who, t in segments:
            if merged and merged[-1][0] == who:
                merged[-1] = (who, merged[-1][1] + " " + t)
            else:
                merged.append((who, t))
        reply = speakable(" ".join(t for who, t in merged if who in ("jarvis", "li"))).strip() or "Done."
        lines = [{"who": who, "text": speakable(t)} for who, t in merged if who not in ("jarvis", "li")]
        log(f"Jarvis (phone): {reply}")
        self.last_spoken = " ".join(t for _, t in merged)
        for old_path, _ in self.audio.values():   # the previous turn's clips are no longer needed
            try:
                os.remove(old_path)
            except OSError:
                pass
        self.audio = {}
        audio = []
        for i, (who, t) in enumerate(merged):
            path, mime = self.voice.render(t, who)
            if path:
                uid = f"{int(time.time() * 1000)}-{i}"
                self.audio[uid] = (path, mime)
                track = self.voice._visemes(path) if mime == "audio/wav" else None   # the same mouth shapes the Mac display uses
                audio.append({"who": who, "url": f"/audio/{uid}", "text": speakable(t), "track": track,
                              "dur": round(len(track) * 0.03, 2) if track else round(len(t) / 15.0, 2)})
        if self.hud:
            self.hud.update(mode="idle", jarvis=reply[:600])
        panels = panels + [{"title": v["title"], "pct": v["pct"]} for v in tasks.values()]
        self.call_off_later(sum(a.get("dur", 0) for a in audio))   # hang up a few seconds after the last clip should have finished on the phone
        return {"transcript": text, "reply": reply, "lines": lines, "panels": panels, "audio": audio}


# ---------------------------------------------------------------- the brain

class Brain:
    """One Claude Code process kept running, so answers start in about a second."""

    WARMUP = (f"(System check, not from {USER_NAME}: before replying, call ToolSearch once with "
              "query \"select:WebSearch,WebFetch,mcp__claude-in-chrome__tabs_context_mcp,"
              "mcp__claude-in-chrome__navigate,mcp__claude-in-chrome__computer,"
              "mcp__claude-in-chrome__read_page,mcp__claude-in-chrome__tabs_create_mcp,"
              "mcp__claude-in-chrome__tabs_close_mcp,mcp__claude_ai_Gmail__search_threads,"
              "mcp__claude_ai_Gmail__send_message,mcp__claude_ai_Gmail__create_draft,"
              "mcp__claude_ai_Gmail__reply,mcp__claude_ai_Google_Drive__search_files,"
              "mcp__claude_ai_Google_Drive__read_file_content,"
              "mcp__claude_ai_Google_Drive__download_file_content,mcp__claude_ai_Spotify__search,"
              "mcp__claude_ai_Spotify__get_currently_playing\" so they're loaded and ready before "
              "the first real request this session, then reply with exactly: Ready when you are.)")

    def __init__(self, claude: str):
        self.claude = claude
        self.proc = None
        self.turns: deque = deque()   # dicts: {speak, cancelled, done}
        self.lock = threading.Lock()
        self.start_lock = threading.RLock()   # one process swap at a time; send() waits for it
        self.ready = threading.Event()
        self.last_used = time.time()
        self.fresh = False
        self.need_context = False     # hand the memory block to the next real turn
        self.session_id = None
        self.context_tokens = 0
        self.real_turns = 0
        self.on_tool_start = None     # callback(turn, tool_name, tool_input) the moment a tool begins

    # process management
    def start(self, warm: bool = True, resume: str = None):
        with self.start_lock:
            self.ready.clear()
            try:
                self._start(warm, resume)
            finally:
                self.ready.set()   # whatever happened, nobody should wait on a start that is over

    def _start(self, warm: bool, resume: str):
        self.stop()
        self.session_id = resume or str(uuid.uuid4())
        cmd = [self.claude, "-p", "--input-format", "stream-json", "--output-format", "stream-json",
               "--verbose", "--include-partial-messages", "--model", MODEL,
               *(["--fallback-model", FALLBACK_MODEL] if FALLBACK_MODEL else []),
               *(["--resume", resume] if resume else ["--session-id", self.session_id]),
               *(["--chrome"] if USE_CHROME else []),
               *(["--effort", EFFORT] if EFFORT else []),
               "--append-system-prompt", system_prompt()]
        try:
            self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                         stderr=subprocess.PIPE, text=True, bufsize=1, cwd=HERE)
        except OSError as e:
            log(f"Couldn't start Claude Code ({e}).")
            self.proc = None
            return
        self.turns.clear()
        self.context_tokens = 0
        self.real_turns = 0
        self.need_context = not resume
        self._save_session()
        threading.Thread(target=self._reader, args=(self.proc,), daemon=True).start()
        threading.Thread(target=self._stderr, args=(self.proc,), daemon=True).start()
        if warm:   # connect to everything now, so the first real command is fast
            t = self.send(self.WARMUP, speak=None, internal=True)
            t["done"].wait(90)
        if resume:
            log(f"(resumed the conversation {resume[:8]}... across the restart)")
        self.fresh = True
        self.last_used = time.time()

    def _save_session(self):
        try:
            with open(SESSION_FILE, "w") as f:
                json.dump({"session": self.session_id, "ts": time.time(), "model": MODEL}, f)
        except OSError:
            pass

    @staticmethod
    def saved_session(max_age: float = 30 * 60):
        """The last conversation id, if it is recent enough to be worth resuming after a restart."""
        try:
            with open(SESSION_FILE) as f:
                d = json.load(f)
            if d.get("session") and time.time() - d.get("ts", 0) < max_age and d.get("model") == MODEL:
                return d["session"]
        except (OSError, ValueError):
            pass
        return None

    def stop(self):
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.stdin.close()
                self.proc.terminate()
            except Exception:  # noqa: BLE001
                pass
        self.proc = None

    def alive(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def handoff(self, reason: str, wait: float = HANDOFF_WAIT) -> bool:
        """Before the conversation is thrown away, have the brain write where we left off into today's case file."""
        if not self.alive() or self.real_turns == 0:
            return False
        path = ensure_case_file()
        t = self.send(
            f"(Note from Jarvis's system, not from {USER_NAME}: this conversation is about to reset ({reason}). "
            f"Using the Edit or Write tool, append 3-8 short bullets to {path} covering what we worked on, decisions, "
            f"anything {USER_NAME} asked you to remember, open asks or unfinished work, and any joke or callback that "
            f"landed or missed (put those in {RUNNING_JOKES} too, with [status: hit] or [status: miss]). "
            "Then reply with just the word done.)", speak=None, internal=True)
        ok = t["done"].wait(wait)
        log(f"(hand-off note {'written' if ok else 'timed out'}: {reason})")
        return ok

    def maybe_refresh(self, brain_lock=None):
        """After a long idle gap (or once the context has grown huge), hand off and start a fresh conversation.
        Runs in the background while nobody is talking; the brain_lock keeps a sudden request from colliding."""
        idle = time.time() - self.last_used
        if self.fresh or (idle <= REFRESH_AFTER_SECS and not (self.context_tokens > CONTEXT_CAP_TOKENS and idle > 60)):
            return
        self.fresh = True
        why = "idle for a while" if idle > REFRESH_AFTER_SECS else f"the conversation has grown to {self.context_tokens // 1000}k tokens"

        def go():
            if brain_lock and not brain_lock.acquire(timeout=5):
                self.fresh = False
                return
            try:
                self.handoff(why)
                log(f"Starting a fresh conversation in the background ({why}).")
                self.start(warm=True)
            finally:
                if brain_lock:
                    brain_lock.release()
        threading.Thread(target=go, daemon=True).start()

    # talking
    def send(self, text: str, speak, show=None, persona: str = "jarvis", internal: bool = False):
        if not internal:
            self.ready.wait(90)        # a warm-up or hand-off may be mid-flight
        with self.start_lock:
            if not self.alive():
                self.start(warm=False)
        turn = {"speak": speak, "show": show, "persona": persona, "cancelled": False, "done": threading.Event(), "text": "", "error": None,
                "api_error": None, "subtype": None, "t0": time.time(), "first_text": None, "tools": [], "acked": False,
                "internal": internal, "context": 0, "cost": None}
        with self.lock:
            self.turns.append(turn)
        self._write({"type": "user", "message": {"role": "user", "content": text}})
        if not internal:
            self.fresh = False
            self.real_turns += 1
        self.last_used = time.time()
        return turn

    def interrupt(self, turn):
        turn["cancelled"] = True
        if not turn["done"].is_set():
            self._write({"type": "control_request", "request_id": f"int{time.time()}",
                         "request": {"subtype": "interrupt"}})

    def _write(self, obj):
        try:
            self.proc.stdin.write(json.dumps(obj) + "\n")
            self.proc.stdin.flush()
        except Exception as e:  # noqa: BLE001
            log(f"Lost contact with Claude Code ({e}).")

    def _stderr(self, proc):
        for line in proc.stderr:
            line = line.strip()
            if line:
                log(f"claude: {line[:300]}")

    def _reader(self, proc):
        buf = ""
        tool = None     # the tool_use block being streamed: {"name", "json"}
        for line in proc.stdout:
            try:
                d = json.loads(line)
            except ValueError:
                continue
            kind = d.get("type")
            if kind == "system":
                if d.get("session_id") and d["session_id"] != self.session_id:
                    self.session_id = d["session_id"]
                    self._save_session()
                continue
            with self.lock:
                turn = self.turns[0] if self.turns else None
            if not turn:
                continue
            if kind == "assistant":   # one API call's usage = the live size of the conversation
                usage = (d.get("message") or {}).get("usage") or {}
                ctx = sum(int(usage.get(k) or 0) for k in ("input_tokens", "cache_read_input_tokens", "cache_creation_input_tokens"))
                if ctx:
                    self.context_tokens = ctx
                    turn["context"] = ctx
            if kind == "stream_event":
                ev = d.get("event", {})
                et = ev.get("type")
                if et == "content_block_start" and (ev.get("content_block") or {}).get("type") == "tool_use":
                    name = ev["content_block"].get("name", "?")
                    turn["tools"].append(re.sub(r"^mcp__(claude_ai_)?", "", name))
                    tool = {"name": name, "json": ""}
                elif et == "content_block_delta" and ev.get("delta", {}).get("type") == "input_json_delta" and tool:
                    tool["json"] += ev["delta"].get("partial_json", "")
                elif et == "content_block_stop" and tool:
                    if self.on_tool_start and turn["first_text"] is None and not turn["acked"] and turn["speak"] and not turn["cancelled"]:
                        turn["acked"] = True
                        try:
                            self.on_tool_start(turn, tool["name"], tool["json"])
                        except Exception as e:  # noqa: BLE001
                            log(f"(ack error: {e})")
                    tool = None
                if et == "content_block_delta" and ev.get("delta", {}).get("type") == "text_delta":
                    chunk = ev["delta"].get("text", "")
                    if turn["first_text"] is None:
                        turn["first_text"] = time.time()
                    turn["text"] += chunk
                    buf = self._take_tags(turn, buf + chunk)
                    cut = buf.find("[[")
                    if cut >= 0 and len(buf) - cut > 240 and "]]" not in buf[cut:]:
                        log(f"(dropped an unterminated tag: {buf[cut:cut + 40]!r})")   # don't let a broken tag silence the rest
                        buf = buf[:cut] + buf[cut + 2:]
                        cut = buf.find("[[")
                    if cut >= 0:           # a tag is still being written: speak only what's before it
                        buf = self._emit_sentences(turn, buf[:cut]) + buf[cut:]
                    else:
                        buf = self._emit_sentences(turn, buf)
                elif et == "message_stop":
                    buf = self._flush(turn, buf)
                    turn["text"] += " "
            elif kind == "result":
                buf = self._flush(turn, buf)
                if d.get("is_error"):
                    turn["api_error"] = d.get("result") or d.get("subtype") or "error"
                    turn["subtype"] = d.get("subtype")
                    if not turn["text"].strip():
                        turn["error"] = turn["api_error"]
                turn["cost"] = d.get("total_cost_usd")   # (the result's usage is the whole turn's total, not the context size)
                if d.get("session_id") and d["session_id"] != self.session_id:
                    self.session_id = d["session_id"]
                    self._save_session()
                with self.lock:
                    if self.turns and self.turns[0] is turn:
                        self.turns.popleft()
                turn["done"].set()
        # process ended
        if proc is not self.proc:
            return
        with self.lock:
            for t in self.turns:
                t["error"] = t["error"] or "Claude Code stopped"
                t["done"].set()
            self.turns.clear()

    ABBREV = re.compile(r"(\b(Mr|Mrs|Ms|Dr|Prof|St|Jr|Sr|vs|etc|No|Mt|Ave|approx)|\b[A-Z]|\b(e\.g|i\.e|a\.m|p\.m))\.$", re.I)
    BOUNDARY = re.compile(r"[.!?…:;](?=\s)|[。！？；]|\n")

    def _emit_sentences(self, turn, buf):
        """Speak each complete sentence as soon as it's written."""
        pos = 0
        for m in self.BOUNDARY.finditer(buf):
            end = m.end()
            piece = buf[pos:end].strip()
            if not piece:
                pos = end
                continue
            if m.group() != "\n" and (self.ABBREV.search(piece) or len(piece) < 12 and not re.search(r"[.!?。！？]$", piece)):
                continue            # "Mr." or a tiny fragment: keep going
            if turn["speak"] and not turn["cancelled"]:
                turn["speak"](piece, turn.get("persona", "jarvis"))
            pos = end
        return buf[pos:]

    TAG = re.compile(r"\[\[\s*(panel|note|clear|mavis|sloane|abg|mario|task|move|react|style|remember|joke)\s*:?(.*?)\]\]", re.S | re.I)
    UNKNOWN_TAG = re.compile(r"\[\[\s*([a-z_ ]{1,20})\s*:?(.*?)\]\]", re.S | re.I)   # anything else in brackets: strip it, log it
    MOVES = {"left", "right", "up", "down", "stop", "auto", "away", "closer", "wander"}
    REACTS = {"dance", "facepalm", "shrug", "fistpump", "laugh", "sleepy",
              "wave", "stretch", "lookaround", "nod", "point", "bow", "think",
              "cheer", "jump", "clap", "headshake", "shiver", "flex",
              "typing", "sip", "fistbump", "highfive", "moonwalk", "airguitar", "sneeze", "yawn",
              "salute", "thumbsup", "spin", "trip", "micdrop",
              "robot", "runningman", "disco", "floss", "spinpose",
              "run", "groundpound", "powerup", "fireball", "pipe", "victory", "flagpole", "coin", "star",
              "dab", "hiphop01", "groovejam", "bringiton", "kpop02", "boogiedown", "smoothdrive", "poplock",
              "wiggle", "dancemoves", "sparkles", "easternbloc", "breakdancefemale", "bendy", "koreaneagle",
              "dancenobones", "rocketrodeo", "technozombie", "chicken", "orangejustice", "snap", "heelclick",
              "infinidab", "cry", "guitar", "redcard", "soccerjuggling", "danceloser", "clapperboard",
              "ibreakyou", "bandofthefort", "yeet", "rockpaperscissorpaper", "dustoffshoulders", "thumbsdown",
              "skindefault", "skinstark", "skinmidnight", "skinbattlepass", "skinarctic", "skincrimson",
              "skincool",
              "walk", "wander", "hiphop", "kpop", "bendy", "breakdance", "twist", "soccer", "fistbump",
              "smirk", "worried", "delighted", "surprised", "deadpan", "wink", "laughing"}

    def _take_tags(self, turn, buf):
        """Pull [[panel: ...]] tags out of the stream: screen ones go to the HUD, mavis ones are spoken in her voice."""
        def show(m):
            kind, rest = m.group(1).lower(), m.group(2)
            if kind in ("mavis", "sloane", "abg", "mario"):
                line = speakable(rest).strip()
                if line and not turn["cancelled"]:
                    log(f"{kind.capitalize()}: {line}")
                    if turn.get("speak"):
                        turn["speak"](line, kind)
                    if turn.get("show"):
                        turn["show"]({kind: line})
                return " "
            if kind in ("remember", "joke"):
                line = " ".join(rest.split())
                if line:
                    if kind == "joke":
                        append_joke(line)
                    else:
                        append_case(f"- {datetime.now().strftime('%H:%M')} remember: {line}")
                    log(f"({kind}: {line})")
                return " "
            if kind == "style":
                look = rest.strip().lower()
                if look in ("rickmorty", "normal") and turn.get("show") and not turn["cancelled"]:
                    turn["show"]({"style": look})
                return " "
            if kind == "move":
                direction = rest.strip().lower()
                if direction in self.MOVES and turn.get("show") and not turn["cancelled"]:
                    turn["show"]({"move": direction})
                return " "
            if kind == "react":
                spec = rest.strip().lower()
                who, sep, name = spec.partition(":")
                if not sep:
                    name, who = who, "jarvis"
                who = who if who in ("jarvis", "mavis", "sloane", "abg", "mario") else "jarvis"
                if name in self.REACTS and turn.get("show") and not turn["cancelled"]:
                    turn["show"]({"react": name, "who": who})
                return " "
            parts = [x.strip() for x in rest.split("|")] if rest.strip() else []
            if turn.get("show") and not turn["cancelled"]:
                if kind == "clear":
                    turn["show"](None)
                elif kind == "note":
                    turn["show"]({"title": parts[0] if parts else "", "body": " ".join(parts[1:])})
                elif kind == "task":
                    tid = parts[0] if parts else ""
                    if len(parts) > 1 and parts[1].strip().lower() == "done":
                        turn["show"]({"task": {"id": tid, "done": True}})
                    else:
                        pct = 0.0
                        if len(parts) > 2:
                            try:
                                pct = float(parts[2])
                            except ValueError:
                                pass
                        turn["show"]({"task": {"id": tid, "label": parts[1] if len(parts) > 1 else "", "pct": pct}})
                else:
                    turn["show"]({"title": parts[0] if parts else "", "items": [x for x in parts[1:] if x]})
            return " "

        def unknown(m):
            log(f"(unknown tag ignored: [[{m.group(1).strip()}: ...]])")
            return " "
        return self.UNKNOWN_TAG.sub(unknown, self.TAG.sub(show, buf))

    def _flush(self, turn, buf):
        buf = self._take_tags(turn, buf)
        buf = speakable(buf)
        if buf.strip() and turn["speak"] and not turn["cancelled"]:
            turn["speak"](buf.strip(), turn.get("persona", "jarvis"))
        return ""


# ---------------------------------------------------------------- ears

class Ears:
    def __init__(self):
        self.q: "queue.Queue[np.ndarray]" = queue.Queue()
        self.device, self.name = self.pick_mic()
        self.stream = sd.InputStream(samplerate=RATE, channels=1, dtype="int16", device=self.device,
                                     blocksize=FRAME, callback=self._cb)
        self.noise = 300.0

    @staticmethod
    def pick_mic():
        """Use the Mac's built-in mic. (Using AirPods/Bluetooth mics switches the
        headphones into low-quality call mode, which makes everything sound crackly.)"""
        try:
            devs = [(i, d) for i, d in enumerate(sd.query_devices()) if d["max_input_channels"] > 0]
        except Exception:  # noqa: BLE001
            return None, "default mic"
        if MIC:
            for i, d in devs:
                if MIC.lower() in d["name"].lower():
                    return i, d["name"]
        for i, d in devs:
            if re.search(r"macbook.*microphone|built-in microphone|imac.*microphone", d["name"], re.I):
                return i, d["name"]
        return None, "default mic"

    def _cb(self, indata, frames, t, status):
        if status and time.time() - self._last_status_log > 30:
            self._last_status_log = time.time()
            log(f"(mic stream status: {status})")
        self.q.put(indata[:, 0].copy())

    _last_status_log = 0.0
    on_level = None

    def reopen(self):
        """The input stream went quiet (device change, sleep/wake): pick the mic again and start a new stream.
        The old one is only stopped, not closed, so the `with ears.stream:` at shutdown still has something to close."""
        try:
            self.stream.stop()
        except Exception:  # noqa: BLE001
            pass
        self.device, self.name = self.pick_mic()
        self.stream = sd.InputStream(samplerate=RATE, channels=1, dtype="int16", device=self.device,
                                     blocksize=FRAME, callback=self._cb)
        self.stream.start()
        log(f"Microphone reopened: {self.name}.")

    def read(self, timeout=None):
        try:
            f = self.q.get(timeout=timeout)
        except queue.Empty:
            return None
        if self.on_level:
            self.on_level(self.rms(f))
        return f

    def drain(self):
        while not self.q.empty():
            try:
                self.q.get_nowait()
            except queue.Empty:
                break

    @staticmethod
    def rms(frame) -> float:
        return float(np.sqrt(np.mean(frame.astype(np.float32) ** 2)))

    def track_noise(self, frame):
        self.noise = 0.98 * self.noise + 0.02 * min(self.rms(frame), 3000)

    UNFINISHED = re.compile(
        r"(,|\.\.\.|…|-|\b(and|but|or|so|because|cause|the|a|an|to|for|with|of|my|his|her|like|um+|uh+|er+|hmm+|if|that|then|about|at|in|on|is|was|can|could|would|should|will|i|i'm|also|plus|maybe|what|which|who|when|where|how|than|from|into|just|really|say|saying|tell|ask))\s*$",
        re.I)

    def listen(self, vad, transcribe, start_timeout: float, max_secs: float = 30):
        """Record one thing you say and return (audio, text), or (None, "").

        Uses a speech detector instead of loudness, waits for a real pause, and if
        the words so far sound unfinished ("...and", "um"), gives you extra time."""
        try:
            vad.reset_states()
        except Exception:  # noqa: BLE001
            pass

        def is_speech(f):
            p = vad.predict(f)
            return p > 0.5 or (p > 0.25 and self.rms(f) > max(self.noise * 3.0, 450.0))

        frames, waited, run = [], 0.0, 0
        while True:                                     # wait for you to start talking
            f = self.read()
            frames = (frames + [f])[-8:]                # keep ~0.6 s of lead-in
            run = run + 1 if is_speech(f) else 0
            if run >= 2:
                break
            waited += STEP
            if waited >= start_timeout:
                return None, ""

        quiet, extensions = 0.0, 0
        while True:
            f = self.read()
            frames.append(f)
            if is_speech(f):
                quiet = 0.0
            else:
                quiet += STEP
            if len(frames) * STEP >= max_secs:
                audio = np.concatenate(frames)
                return audio, transcribe(audio)
            if quiet < END_SILENCE:
                continue
            audio = np.concatenate(frames)
            text = transcribe(audio)
            core = re.sub(r"[.!?\s]+$", "", text)
            if extensions < 2 and (not core or self.UNFINISHED.search(core)):
                extensions += 1                         # sounds unfinished: keep listening a bit
                waited, resumed = 0.0, False
                while waited < EXTRA_WAIT:
                    f = self.read()
                    frames.append(f)
                    waited += STEP
                    if is_speech(f):
                        resumed = True
                        break
                if resumed:
                    quiet = 0.0
                    continue
                audio = np.concatenate(frames)
                text = transcribe(audio)
            return audio, text


# ---------------------------------------------------------------- speech to text

class Stt:
    """Speech to text. Uses the Mac's GPU (mlx-whisper) when it can: several times
    faster than the CPU. Installs it in the background the first time; until it's
    ready, and if it ever fails, the CPU model (faster-whisper) does the work."""

    PROMPT = ("Hey Jarvis. Spotify, YouTube, Gmail, Google Drive, planner, "
              + (f"{USER_NAME}, {STT_HINTS}." if STT_HINTS else f"{USER_NAME}."))

    def __init__(self):
        self.cpu = WhisperModel(WHISPER, device="cpu", compute_type="int8",
                                cpu_threads=max(4, min(8, os.cpu_count() or 4)))
        self.gpu = None
        self.lock = threading.Lock()
        self.last_secs = 0.0
        if FAST_STT and sys.platform == "darwin" and platform.machine() == "arm64":
            threading.Thread(target=self._load_gpu, daemon=True).start()

    @property
    def name(self):
        return f"GPU ({MLX_MODEL.split('/')[-1]})" if self.gpu else f"CPU ({WHISPER})"

    def _load_gpu(self):
        try:
            try:
                import mlx_whisper  # noqa: F401
            except ImportError:
                log("Installing fast GPU transcription (one time, about a minute)...")
                subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "mlx-whisper"],
                               check=True, capture_output=True, timeout=900)
                import mlx_whisper  # noqa: F401
            import mlx_whisper
            with self.lock:   # downloads the model the first time, then warms it up
                mlx_whisper.transcribe(np.zeros(RATE, dtype=np.float32), path_or_hf_repo=MLX_MODEL, language="en")
            self.gpu = mlx_whisper
            log(f"Fast transcription ready: {self.name}.")
        except Exception as e:  # noqa: BLE001
            log(f"GPU transcription unavailable ({str(e)[:200]}); staying on the CPU.")

    def __call__(self, audio) -> str:
        t = time.time()
        x = audio.astype(np.float32) / 32768.0
        text = ""
        if self.gpu:
            try:
                with self.lock:
                    r = self.gpu.transcribe(x, path_or_hf_repo=MLX_MODEL, language=None, initial_prompt=self.PROMPT,
                                            condition_on_previous_text=False)
                text = (r or {}).get("text", "")
            except Exception as e:  # noqa: BLE001
                log(f"GPU transcription failed ({str(e)[:200]}); back to the CPU.")
                self.gpu = None
        if not self.gpu:
            segs, _ = self.cpu.transcribe(x, language=None, beam_size=1, vad_filter=True,
                                          without_timestamps=True, initial_prompt=self.PROMPT)
            text = " ".join(s.text for s in segs)
        self.last_secs = time.time() - t
        return text.strip()


def ensure_helpers():
    """Background one-time installs for optional speed-ups (the fast calendar reader)."""
    def run():
        try:
            import EventKit  # noqa: F401
        except ImportError:
            if sys.platform == "darwin":
                try:
                    subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "pyobjc-framework-EventKit"],
                                   check=True, capture_output=True, timeout=900)
                    log("Fast calendar reader installed.")
                except Exception as e:  # noqa: BLE001
                    log(f"Couldn't install the fast calendar reader ({str(e)[:150]}).")
    threading.Thread(target=run, daemon=True).start()


# ---------------------------------------------------------------- main loop

def job_watcher(hud, announce):
    """Mirror Edwin's detached jobs (worker.py) onto the HUD, and queue a spoken note when one finishes.
    The jobs outlive restarts, so this re-adopts whatever is still running every time Jarvis boots."""
    try:
        sys.path.insert(0, HERE)
        import worker
    except Exception as e:  # noqa: BLE001
        log(f"(job watcher unavailable: {e})")
        return
    shown = set()
    worker.reconcile()
    running = [j for j in worker.all_jobs() if j["status"] in ("queued", "running")]
    if running:
        log(f"(re-adopted {len(running)} background job(s) still working from before the restart)")
    while True:
        try:
            for j in worker.all_jobs():
                if j["status"] in ("queued", "running"):
                    hud.task("job" + j["id"], label=j["label"][:40], pct=j.get("pct", 0))
                    shown.add(j["id"])
                elif j["id"] in shown:
                    hud.task("job" + j["id"], done=True)
                    shown.discard(j["id"])
                if j["status"] in ("done", "failed") and not j.get("announced"):
                    j["announced"] = True
                    worker.save(j)
                    announce.append(j)
            if shown:
                worker.reconcile()
        except Exception as e:  # noqa: BLE001
            log(f"(job watcher: {e})")
        time.sleep(4)


_LOCK_FD = None


def single_instance():
    """Only one Jarvis at a time: two would both answer the mic. The lock is released by the kernel on any exit
    and closed on the hot-reload exec, so the fresh image simply takes it again."""
    global _LOCK_FD
    _LOCK_FD = open(LOCK_FILE, "a+")
    try:
        fcntl.flock(_LOCK_FD, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        _LOCK_FD.seek(0)
        pid = _LOCK_FD.read().strip() or "?"
        msg = f"Jarvis is already running (pid {pid}) in another window. Close that one first, or tell it \"Jarvis, shut down\"."
        print(msg)
        log(msg)
        subprocess.run(["say", "-v", MAC_VOICE, "Jarvis is already running in another window."], check=False)
        sys.exit(1)
    _LOCK_FD.seek(0)
    _LOCK_FD.truncate()
    _LOCK_FD.write(str(os.getpid()))
    _LOCK_FD.flush()


def tailscale_url():
    """The phone page's address on the owner's Tailscale network, if Tailscale is installed and `tailscale serve` is set up."""
    ts = "/Applications/Tailscale.app/Contents/MacOS/Tailscale"
    if not os.path.exists(ts):
        return None
    try:
        out = subprocess.run([ts, "serve", "status"], capture_output=True, text=True, timeout=4).stdout
        m = re.search(r"(https://[\w.-]+\.ts\.net)", out)
        return m.group(1) if m else None
    except Exception:  # noqa: BLE001
        return None


def start_avatar_server():
    """hud.html loads the 3D Jarvis (avatar3d/) from a tiny static server on port 8766; run it so nobody has to."""
    script = os.path.join(AVATAR3D_DIR, "serve.py")
    if not os.path.exists(script):
        return
    try:
        s = socket.socket()
        s.settimeout(0.3)
        taken = s.connect_ex(("127.0.0.1", AVATAR3D_PORT)) == 0
        s.close()
        if taken:
            return   # already served (e.g. by the process this one replaced on a hot reload)
        proc = subprocess.Popen([PY, script], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=AVATAR3D_DIR)
        atexit.register(lambda: proc.poll() is None and proc.terminate())
        log(f"3D avatar assets served on port {AVATAR3D_PORT}.")
    except Exception as e:  # noqa: BLE001
        log(f"(3D avatar server didn't start: {e})")


def main():
    single_instance()
    claude = find_claude()
    hot = os.environ.pop("JARVIS_HOT_RELOAD", "") == "1"   # re-exec'd after a code change: keep it quiet and resume
    sys.path.insert(0, HERE)
    try:
        import timer as timer_mod
    except Exception as e:  # noqa: BLE001
        timer_mod = None
        log(f"(timers unavailable: {e})")
    log("Loading models..." + (" (hot reload)" if hot else ""))
    wake = Model(wakeword_models=["hey_jarvis"], inference_framework="onnx")
    vad = VAD()
    stt = Stt()
    ensure_helpers()
    voice = Voice()
    hud = Hud() if HUD_ON else NoHud()

    def _lip(lv):
        if abs(lv - hud._last_level) >= 0.04 or lv == 0.0:
            hud._last_level = lv
            hud.update(level=round(lv, 2))
    def _speaker(who, text, secs, track=None, rate=1.0, start=None):
        sid = None
        if track:
            sid = int(time.time() * 1000)
            hud.tracks[sid] = track
            for old in sorted(hud.tracks)[:-12]:
                hud.tracks.pop(old, None)
        hud.update(say={"who": who, "text": text, "dur": secs, "t": time.time(), "id": sid, "rate": rate, "lead": LIP_LEAD, "start": start})
    if HUD_ON:
        voice.on_level = _lip
        voice.on_speaker = _speaker
    hud.update(boot=time.time(), mode="thinking", jarvis="Starting up...")
    if HUD_ON:
        start_avatar_server()
    hud.open_window()
    servers = write_permissions(claude)
    log(f"Voice: {voice.name}.  Connectors: {', '.join(servers) if servers else 'none found (see README)'}")
    brain = Brain(claude)
    job_announce = []   # finished background jobs waiting to be reported out loud
    threading.Thread(target=job_watcher, args=(hud, job_announce), daemon=True).start()
    brain_lock = threading.Lock()   # shared with the phone bridge, so you can't talk to both at once

    def on_tool_start(turn, name, inp):
        """The instant the first tool starts with nothing said yet, say something, keyed on the tool: the prompt asks
        the model to do this itself and it mostly doesn't, and dead air is what makes Jarvis feel slow."""
        if turn.get("internal"):
            return
        key = (name + " " + (inp or "")).lower()
        if turn.get("persona") == "li":
            line = TOOL_ACKS_ZH
        else:
            line = next((a for pat, a in TOOL_ACKS if re.search(pat, key)), "On it.")
        voice.say(line, turn.get("persona", "jarvis"))
        hud.update(jarvis=line)
        turn["acked_at"] = time.time()
        log(f"(ack: {line})")
    brain.on_tool_start = on_tool_start

    ears = Ears()   # the mic opens before the brain warms up, so a restart never leaves him deaf
    resume = Brain.saved_session() if hot else None
    log("Warming up Claude..." + (" (resuming the conversation)" if resume else ""))
    threading.Thread(target=brain.start, kwargs={"warm": True, "resume": resume}, daemon=True, name="brain-start").start()
    listening = {"on": False}
    confirm = {"pending": False}   # did Jarvis just ask "shall I send it?" - only then does a "yes" open the send gate
    quit_now = {"on": False}
    fresh = {"on": not os.path.exists(LAST_DAY_FILE) and not os.path.isdir(CASE_DIR)}   # never run before: a new person's first chat
    spont = {"next": time.time() + random.uniform(12, 25) * 60}   # when he may next volunteer a remark unprompted
    SPONT_NOTE = (f"(Note from Jarvis's system, not from {USER_NAME}: nothing has happened for a while, but he's nearby. If you or Mavis have "
                  "something genuinely worth saying unprompted - a short out-of-pocket remark, a callback to a running bit, a heads-up about "
                  "something due soon, an observation about what he was working on, or Mavis needling you - say it in one or two spoken "
                  "sentences (hers through her tag, with a [[react: mavis:...]] cue if it fits). If there's nothing worth saying, reply with "
                  "exactly [[clear]] and nothing else.)")
    ears.on_level = lambda r: hud.level(r) if listening["on"] else None
    try:
        out_name = sd.query_devices(kind="output")["name"]
    except Exception:  # noqa: BLE001
        out_name = "system default"
    log(f"Microphone: {ears.name}.  Speaker: your selected output (now {out_name}).  Chrome control: {'on' if USE_CHROME else 'off'}.")
    log(f"Brain: {MODEL}{' / effort ' + EFFORT if EFFORT else ''}.  Transcription: {stt.name}.")
    day = {"last": None}
    last_turn = {"t": 0.0}   # when he last spoke to Jarvis (the hot reload waits for a real gap)

    HALLUCINATIONS = re.compile(r"[\W_]*(you|thank you\.?|thanks for watching\.?|bye\.?|okay\.?|subtitles by .*|hey jarvis\.?)?[\W_]*", re.I)

    def transcribe(audio) -> str:
        text = stt(audio)
        text = re.sub(r"^(hey,?\s+)?jarvis[,.!?]?\s*", "", text, flags=re.I).strip()
        if HALLUCINATIONS.fullmatch(text):
            return ""
        # Whisper guessed a language from a short/noisy clip: only English and Chinese are ever spoken here
        if not re.search(r"[A-Za-z一-鿿]", text) or re.search(r"[Ѐ-ӿ぀-ヿ඀-෿가-힯]", text):
            log(f"(dropped a transcript in the wrong alphabet: {text[:40]!r})")
            return ""
        return text

    phone = PhoneBridge(brain, voice, brain_lock, transcribe, hud=hud) if PHONE_ON else None
    if phone and phone.ok:
        if PHONE_PIN:
            log(f"Phone bridge: https://{phone.ip}:{PHONE_PORT}  (PIN required on the phone, set in .env)")
            ts_url = tailscale_url()
            if ts_url:
                log(f"Phone from anywhere (Tailscale): {ts_url}")
        else:
            log("Phone bridge: no PHONE_PIN set in .env, so it's not reachable. Add one and restart.")
    elif PHONE_ON:
        log("Phone bridge didn't start (see above).")

    text_q: "queue.Queue[str]" = queue.Queue()

    def _stdin_reader():
        for line in sys.stdin:
            line = line.strip()
            if line:
                text_q.put(line)

    threading.Thread(target=_stdin_reader, daemon=True, name="stdin-reader").start()
    log('You can also just type a line here and press Enter instead of talking (/help for commands).')

    SHELLISH = re.compile(r"^(cd|ls|cat|sh|bash|zsh|python3?|git|brew|pip3?|echo|export|which|type|sudo|rm|open|claude)\b|&&|\|\||>>|\s\|\s")

    def local_command(line: str) -> bool:
        """Typed lines starting with / are for Jarvis's own loop, never sent to the brain."""
        low = line.strip().lower()
        if not low.startswith("/"):
            if SHELLISH.search(line):
                print("(that looks like a shell command; this is Jarvis's input line, not a shell. Type a sentence instead.)", flush=True)
                log(f"(refused shell-looking typed line: {line[:60]})")
                return True
            return False
        if low in ("/exit", "/quit", "/q"):
            quit_now["on"] = True
        elif low == "/mute":
            hud.set_muted(True)
        elif low == "/unmute":
            hud.set_muted(False)
            hud.set_sleeping(False)
        elif low in ("/reset", "/new"):
            print("(starting a fresh conversation)", flush=True)
            threading.Thread(target=lambda: (brain.handoff("reset from the keyboard"), brain.start(warm=True)), daemon=True).start()
        elif low == "/status":
            jobs = ""
            try:
                jobs = subprocess.run([PY, WORKER, "list"], capture_output=True, text=True, timeout=4, cwd=HERE).stdout.strip()
            except Exception:  # noqa: BLE001
                pass
            print(f"brain: {'alive' if brain.alive() else 'down'}, session {str(brain.session_id)[:8]}, context ~{brain.context_tokens // 1000}k tokens, "
                  f"{brain.real_turns} turns\nvoice: {voice.name}\nmic: {ears.name}\njobs:\n{jobs or 'none'}", flush=True)
        elif low == "/help":
            print("/exit  /mute  /unmute  /reset  /status  /help   (anything else you type is said to Jarvis)", flush=True)
        else:
            print(f"(unknown command {low}; /help lists them)", flush=True)
        return True

    def read_typed():
        try:
            line = text_q.get_nowait()
        except queue.Empty:
            return None
        return None if local_command(line) else line

    def next_utterance(timeout):
        """Text from typed input or speech, whichever comes first. None if neither in time."""
        elapsed = 0.0
        while elapsed < timeout:
            typed = read_typed()
            if typed:
                return typed
            if hud.muted:   # Mute ends the conversation too, not just the wake-word wait
                return None
            slice_s = min(1.0, timeout - elapsed)
            audio, text = ears.listen(vad, transcribe, start_timeout=slice_s)
            if audio is not None and text:
                if hud.muted:   # muted while he was mid-sentence: throw it away
                    return None
                return text
            elapsed += slice_s
        return None

    def reset_ears():
        ears.drain()
        wake.reset()

    def respond(text, spontaneous=False):
        """Send to Claude, speak as it streams. Returns 'done' or 'barge' (you said Hey Jarvis).
        spontaneous=True: the text is a system nudge, not something he said (no chime, nothing shown as 'you')."""
        if not spontaneous:
            chime("Pop")
        listening["on"] = False
        li = is_chinese(text)   # Chinese in = Li Laoshi answers (in Mandarin); English in = Jarvis is back
        persona = "li" if li else "jarvis"
        hud.update(mode="thinking", jarvis="", mavis="", sloane="", abg="", mario="", persona="li" if li else "", **({} if spontaneous else {"you": text}))
        note = ""
        if fresh["on"]:   # a brand-new install: the very first thing a new person hears
            fresh["on"] = False
            note += (f"\n\n(Note from Jarvis's system, not from the user: this is the very first conversation on a fresh install, "
                     f"with a new person. Introduce yourself in two short sentences. They're called {USER_NAME}; if that's just 'Sir', "
                     "ask what you should call them. Give a quick spoken rundown of the main things you can do (calendar, reminders, timers, "
                     "email, Spotify, the web and their Chrome, texting, the school planner), and ask them to connect Gmail, Google Drive, "
                     "Google Calendar and Spotify once in their Claude settings so you have full capability from then on. Then handle whatever they said.)")
        today = datetime.now().date()
        if day["last"] != today:
            day["last"] = today
            path = ensure_case_file(today)
            try:
                seen = open(LAST_DAY_FILE).read().strip()
            except OSError:
                seen = ""
            if seen != today.isoformat():   # a genuinely new day, not just a restart
                try:
                    with open(LAST_DAY_FILE, "w") as f:
                        f.write(today.isoformat())
                except OSError:
                    pass
                note = (f"\n\n(Note from Jarvis's system, not from {USER_NAME}: this is his first conversation today; "
                        f"today's case file is {path}. Handle what he asked."
                        + (" If it wasn't a briefing, end by offering one in a few words.)" if datetime.now().hour < 12 else ")"))
        if brain.need_context:   # a fresh conversation: hand over the memory files before the first real question
            brain.need_context = False
            note += context_block()
        if li:
            note += (f"\n\n(Note from Jarvis's system, not from {USER_NAME}: he spoke Chinese, so Li Laoshi answers. "
                     "Reply only in short spoken Mandarin as Li Laoshi, no English and no Mavis line; pinyin or a brief English gloss goes in a [[note: ...]] tag.)")
        def show(p):
            if p is None:
                hud.update(panels=[])
            elif "task" in p:
                t = p["task"]
                hud.task(t.get("id", ""), label=t.get("label"), pct=t.get("pct"), done=t.get("done", False))
            elif "style" in p:
                hud.update(style=p["style"])
            elif "move" in p:
                hud.move(p["move"])
            elif "react" in p:
                hud.react(p["react"], p.get("who", "jarvis"))
            elif "mavis" in p:
                hud.update(mavis=p["mavis"])
            elif "sloane" in p:
                hud.update(sloane=p["sloane"])
            elif "abg" in p:
                hud.update(abg=p["abg"])
            elif "mario" in p:
                hud.update(mario=p["mario"])
            else:
                hud.panel(p)
        if not brain_lock.acquire(timeout=15):
            voice.say("One moment, I'm just finishing something. Ask me again in a bit.")
            voice.wait()
            return "done"
        try:
            voice.last_play = 0
            chars0 = getattr(voice, "eleven_chars", 0)
            last_turn["t"] = time.time()
            if not brain.ready.is_set():
                hud.update(jarvis="Waking up...")
            turn = brain.send(text + note, speak=voice.say, show=show, persona=persona)
            reset_ears()
            started = time.time()
            shown = ""
            fillers_said, last_activity = 0, turn["t0"]
            barge_hits = 0
            stuck = 0.0
            while not turn["done"].is_set() or voice.busy():
                said = speakable(turn["text"])
                if said != shown:
                    shown = said
                    last_activity = time.time()
                    hud.update(jarvis=said[-600:])
                if hud.sleeping:   # Sleep (unlike Mute) cuts him off mid-thought
                    voice.stop()
                    brain.interrupt(turn)
                    log("(sleep: reply cut off)")
                    return "sleep"
                hud.mode("speaking" if voice.busy() else "thinking")
                # The prompt asks Claude for a quick "one sec" before tools, but in practice the first
                # words often arrive 20-200 s in (see the timing lines in the log). So when he's gone
                # quiet while tools run, say a short line for him, and keep checking in on long jobs.
                now = time.time()
                if turn.get("acked_at") and fillers_said == 0:   # the instant acknowledgement counts as the first filler
                    fillers_said, last_activity = 1, turn["acked_at"]
                if (turn["tools"] and not turn["done"].is_set() and not voice.busy() and not turn["cancelled"]
                        and now - last_activity > (FILLER_FIRST if fillers_said == 0 else FILLER_EVERY)):
                    if li:
                        line = random.choice(FILLER_START_ZH if fillers_said == 0 else FILLER_MORE_ZH)
                    else:
                        line = random.choice(FILLER_START if fillers_said == 0 else FILLER_MORE)
                    voice.say(line, persona)
                    hud.update(jarvis=line)
                    log(f"(filler: {line})")
                    fillers_said, last_activity = fillers_said + 1, now
                # The brain is done but the voice counter never cleared (a synth that died, a stale afplay):
                # don't sit here for an hour looking dead.
                if turn["done"].is_set() and voice.busy() and not voice.playing():
                    stuck = stuck or now
                    if now - stuck > 25:
                        log("(voice looked stuck after the reply; cleared it)")
                        voice.stop()
                        break
                else:
                    stuck = 0.0
                f = ears.read(timeout=0.1)
                if f is None or hud.muted:   # muted: even "Hey Jarvis" can't interrupt
                    continue
                # "Hey Jarvis" cuts him off even mid-sentence. While his own voice is loud in the mic the bar is
                # high and needs two frames; in the gaps between his sentences, and while he's only thinking, it's
                # the normal bar, so a real interruption isn't ignored.
                score = wake.predict(f).get("hey_jarvis", 0.0)
                if voice.busy():
                    loud = getattr(voice, "level_now", 0.0) > 0.25
                    bar, need = (BARGE_THRESHOLD, 2) if loud else (BARGE_QUIET, 1)
                else:
                    bar, need = WAKE_THRESHOLD, 1
                if score >= bar:
                    barge_hits += 1
                    if barge_hits < need:
                        continue
                    voice.stop()
                    brain.interrupt(turn)
                    log(f"(interrupted{' mid-speech' if voice.busy() else ''}, wake score {score:.2f} vs {bar})")
                    return "barge"
                barge_hits = 0
                if score >= NEAR_MISS:
                    log(f"(near miss: wake score {score:.2f} < {bar} while {'speaking' if voice.busy() else 'thinking'})")
                if not turn["text"] and not voice.busy() and time.time() - started > 60:
                    log(f"Still waiting on Claude... ({len(turn['tools'])} tool calls so far)")
                    started = time.time()
            if turn["error"]:
                log(f"Claude error: {turn['error']}")
                err = str(turn["error"])
                m = re.search(r"limit.*?resets?\s+([0-9]{1,2}(?::[0-9]{2})?\s*(?:am|pm)?)", err, re.I)
                if re.search(r"log ?in|auth|credential", err, re.I):
                    voice.say("I'm not signed in to Claude. Run claude in Terminal once and log in.")
                elif m:
                    voice.say(f"Claude's cut me off for now; the limit resets at {m.group(1).strip()}. Until then I can listen but not think.", persona)
                else:
                    voice.say("抱歉，我这边出了点问题，请再说一次好吗？" if li else "Sorry, something went wrong on my end. Try that again?", persona)
                voice.wait()
            elif turn.get("api_error"):
                log(f"Claude error (after a partial reply): {turn['api_error']}")
            said = speakable(turn["text"])
            log(f"Jarvis{' (unprompted)' if spontaneous else ''}: {said}")
            stamp = datetime.now().strftime("%H:%M")
            if not spontaneous:
                append_case(f"{stamp} You: {text}", transcript=True)
            if said:
                append_case(f"{stamp} Jarvis{' (unprompted)' if spontaneous else ''}: {said[:500]}", transcript=True)
            confirm["pending"] = bool(re.search(r"shall i (send|go ahead|do it|post|buy|delete)|want me to (send|go ahead)|要我发送吗", said, re.I))
            t0 = turn["t0"]
            ft = f"{turn['first_text'] - t0:.1f}s" if turn["first_text"] else "-"
            fa = getattr(voice, "last_play", 0)
            fa = f"{fa - t0:.1f}s" if fa and fa > t0 else "-"
            tools = f" · tools: {len(turn['tools'])} ({', '.join(turn['tools'][:8])})" if turn["tools"] else ""
            extra = (f" · context {turn['context'] // 1000}k" if turn.get("context") else "") + (f" · error: {turn['subtype']}" if turn.get("subtype") else "")
            spent = getattr(voice, "eleven_chars", 0) - chars0
            extra += f" · 11labs {spent} chars" if spent else ""
            log(f"(timing: transcribed in {stt.last_secs:.1f}s · first words {ft} · voice started {fa} · "
                f"done {time.time() - t0:.1f}s · {len(said.split())} words{tools}{extra})")
            hud.update(jarvis=said[-600:])
            hud.mode("listening")   # voice is finished; don't leave the avatar stuck "speaking"
            return "done"
        finally:
            brain_lock.release()

    def hot_reload():
        """Applies edits the moment they're saved. A changed page just reloads in the display; changed
        code restarts Jarvis silently, but only between turns, and never into a file that won't compile."""
        page_files = [os.path.join(HERE, "hud.html"), os.path.join(HERE, "phone.html")]
        code_files = [os.path.abspath(__file__), _ENV]   # guard.py is run fresh by Claude Code per tool call: no restart needed
        mt = lambda f: os.path.getmtime(f) if os.path.exists(f) else 0
        seen = {f: mt(f) for f in page_files + code_files}

        def job_running() -> bool:
            try:
                import worker
                return any(j["status"] == "running" for j in worker.all_jobs())
            except Exception:  # noqa: BLE001
                return False

        while True:
            time.sleep(0.7)
            try:
                if any(mt(f) != seen[f] for f in page_files):
                    for f in page_files:
                        seen[f] = mt(f)
                    hud.update(boot=time.time())   # the open display sees a new boot id and reloads itself
                    log("(display page changed: reloaded)")
                if not any(mt(f) != seen[f] for f in code_files):
                    continue
                before = {f: mt(f) for f in code_files}
                time.sleep(3)   # let a save (or a background job's run of edits) finish; restart only once the files have settled
                if any(mt(f) != before[f] for f in code_files):
                    continue
                me = os.path.abspath(__file__)
                if mt(me) != seen[me]:
                    try:
                        compile(open(me, encoding="utf-8").read(), me, "exec")
                    except SyntaxError as e:
                        seen[me] = mt(me)
                        log(f"(jarvis.py changed but has a syntax error, line {e.lineno}: staying on the running version)")
                        continue
                waited = time.time()
                while (listening["on"] or voice.busy() or brain_lock.locked() or job_announce
                       or time.time() - last_turn["t"] < 12 or (job_running() and time.time() - waited < 600)):
                    time.sleep(0.5)   # never cut him off mid-turn; wait for a real gap (and let a background job finish its edits)
                log("Code changed. Restarting (the conversation carries over)...")
                hud.update(mode="thinking", jarvis="Updating...")
                brain._save_session()
                brain.stop()
                ears.stream.stop()
                os.environ["JARVIS_HOT_RELOAD"] = "1"
                os.execv(sys.executable, [sys.executable, me])
            except Exception as e:  # noqa: BLE001
                log(f"(hot reload hiccup: {e})")
                time.sleep(3)

    threading.Thread(target=hot_reload, daemon=True).start()

    def fire_timers():
        """Timers that have gone off (timer.py): chime, say so, and keep the countdown tiles fresh."""
        if not timer_mod:
            return
        try:
            for t in timer_mod.pop_due():
                label = t.get("label") or ""
                line = f"Your {timer_mod.say_duration(int(t.get('secs', 0)))} timer is up" + (f": {label}." if label else ".")
                chime("Glass")
                hud.task("timer" + t["id"], done=True)
                hud.update(mode="speaking", jarvis=line)
                voice.say(line)
                voice.wait()
                log(f"(timer up: {label or t['id']})")
                hud.update(mode="idle", jarvis='Listening. Say "Hey Jarvis".')
                reset_ears()
            now = time.time()
            if now - fire_timers.tick > 5:
                fire_timers.tick = now
                for t in timer_mod.running():
                    left = int(t["due"] - now)
                    pct = int(100 * (1 - left / max(1, t.get("secs", 1))))
                    hud.task("timer" + t["id"], label=f"{t.get('label') or 'timer'} · {timer_mod.say_duration(left)}", pct=pct)
        except Exception as e:  # noqa: BLE001
            log(f"(timers: {e})")
    fire_timers.tick = 0.0

    with ears.stream:
        if hot:
            chime("Glass")   # a code update, not a boot: no greeting
        else:
            hud.update(mode="speaking", jarvis="Jarvis online.")
            voice.say("Jarvis online.")
            voice.wait()
        hud.update(mode="idle", jarvis='Listening. Say "Hey Jarvis".')
        reset_ears()
        log('Listening for "Hey Jarvis"...  (Ctrl+C to quit)')
        was_muted = False
        was_asleep = False
        stalls = 0
        prev_score = 0.0
        while True:
            typed = read_typed()
            if quit_now["on"]:
                voice.say("Powering down.")
                voice.wait()
                brain.handoff("shut down from the keyboard", wait=30)
                brain.stop()
                return
            if hud.sleeping:   # fully off: ignore typed input, voice, and job announcements
                if not was_asleep:
                    was_asleep = True
                    voice.stop()
                    hud.update(mode="idle", jarvis="Asleep. Tap Wake when you want me back.")
                ears.read(timeout=1.0)
                continue
            if was_asleep:
                was_asleep = False
                hud.update(jarvis='Awake. Listening. Say "Hey Jarvis".')
                reset_ears()
            if typed:
                pending = typed
                log(f"You (typed): {typed}")
            else:
                f = ears.read(timeout=1.0)
                if hud.muted:
                    if not was_muted:
                        was_muted = True
                        hud.update(mode="idle", jarvis="Muted. Tap Mute again when you want me listening.")
                        reset_ears()
                    continue
                if was_muted:
                    was_muted = False
                    hud.update(jarvis='Unmuted. Listening. Say "Hey Jarvis".')
                    reset_ears()
                if f is None:
                    stalls += 1
                    if stalls >= 6:   # six whole seconds without a frame: the input stream died (device change, sleep/wake)
                        log("(mic stalled: reopening the input stream)")
                        try:
                            ears.reopen()
                        except Exception as e:  # noqa: BLE001
                            log(f"(mic reopen failed: {e})")
                        stalls = 0
                        reset_ears()
                    continue
                stalls = 0
                ears.track_noise(f)
                brain.maybe_refresh(brain_lock)
                fire_timers()
                if job_announce and not brain_lock.locked():
                    j = job_announce.pop(0)
                    summary = " ".join(speakable(j["result"]).split())[:420]
                    line = (f"My assistant finished {j['label']}. {summary}" if j["status"] == "done"
                            else f"My assistant hit a snag on {j['label']}. {summary}")
                    log(f"(job {j['id']} {j['status']}: announcing)")
                    append_case(f"- {datetime.now().strftime('%H:%M')} Edwin {j['status']}: {j['label']} — {summary[:300]}")
                    hud.update(mode="speaking", jarvis=line[:300])
                    voice.say(line)
                    voice.wait()
                    hud.update(mode="idle", jarvis='Listening. Say "Hey Jarvis".')
                    reset_ears()
                    continue
                # Spontaneity: after a quiet stretch (he spoke within the last two hours, but not in the last eight
                # minutes), occasionally let the brain volunteer a remark. It answers [[clear]] when there's nothing.
                idle_for = time.time() - last_turn["t"]
                if (time.time() > spont["next"] and 8 * 60 < idle_for < 120 * 60 and 8 <= datetime.now().hour < 23
                        and not brain_lock.locked() and brain.ready.is_set() and brain.alive()):
                    spont["next"] = time.time() + random.uniform(15, 35) * 60
                    log("(spontaneous: nudging the brain for an unprompted remark)")
                    outcome = respond(SPONT_NOTE, spontaneous=True)
                    reset_ears()
                    if outcome != "barge":
                        hud.mode("idle")
                        continue
                    pending = None   # he said "Hey Jarvis" over the remark: straight into a conversation
                elif getattr(hud, "talk_requested", False):   # the display's push-to-talk: same as hearing the wake word
                    hud.talk_requested = False
                    pending = None
                else:
                    score = wake.predict(f).get("hey_jarvis", 0.0)
                    hit = score >= WAKE_THRESHOLD or (score >= WAKE_SOFT and prev_score >= WAKE_SOFT)
                    prev_score = score
                    if not hit:
                        if score >= NEAR_MISS:
                            log(f"(near miss: wake score {score:.2f} < {WAKE_THRESHOLD}; lower JARVIS_WAKE_THRESHOLD in .env if this was you)")
                        continue
                    if score < WAKE_THRESHOLD:
                        log(f"(woke on two softer frames: {score:.2f})")
                    prev_score = 0.0
                    pending = None

            # ---- a conversation ----
            chime("Tink")
            wake.reset()                  # keep the audio: you may have kept talking after "Hey Jarvis"
            timeout = 5.0
            pending_logged = pending
            while True:
                hud.mode("listening")
                listening["on"] = True
                if pending is not None:
                    text = pending
                    pending = None
                else:
                    text = next_utterance(timeout)
                listening["on"] = False
                if not text:
                    break
                if text != pending_logged:
                    log(f"You: {text}")
                pending_logged = None
                hud.update(you=text)
                low = text.lower()
                # Short-utterance guard: a trigger phrase only counts as a command when
                # it's basically the whole thing you said, not a word buried in a long
                # sentence (e.g. "it might be a new conversation" shouldn't wipe the brain).
                is_command = len(text.split()) <= 6
                if is_command and any(p in low for p in QUIT_PHRASES):
                    voice.say("Powering down. Goodbye.")
                    voice.wait()
                    brain.handoff("shut down", wait=30)
                    brain.stop()
                    return
                if is_command and any(p in low for p in STOP_PHRASES):
                    voice.say("Very good.")
                    voice.wait()
                    break
                if is_command and any(p in low for p in DISPLAY_PHRASES):
                    hud.open_window(force=True)
                    voice.say("Display's up.")
                    voice.wait()
                    reset_ears()
                    timeout = FOLLOWUP_SECS
                    continue
                if is_command and any(p in low for p in RESET_PHRASES):
                    voice.say("Clean slate. What can I do for you?")
                    brain.handoff("he asked to start over", wait=30)
                    brain.start(warm=True)
                    voice.wait()
                    reset_ears()
                    timeout = FOLLOWUP_SECS
                    continue
                # The send gate: a "yes" only opens it when Jarvis just asked "shall I send it?", and only a short
                # yes ("yeah, go ahead"), so "okay so what's my schedule" can't arm a send by accident.
                if confirm["pending"] and YES.search(text) and len(text.split()) <= 12:
                    open(CONFIRM_FLAG, "w").close()      # lets the safety gate allow one send
                    log("(confirmed: the send gate is open for one action)")
                    confirm["pending"] = False
                elif not confirm["pending"] and os.path.exists(CONFIRM_FLAG):
                    try:
                        os.remove(CONFIRM_FLAG)
                    except OSError:
                        pass
                outcome = respond(text)
                if outcome == "sleep":
                    break
                if outcome == "barge":
                    chime("Tink")
                    wake.reset()
                    timeout = 5.0
                    continue
                reset_ears()
                timeout = FOLLOWUP_SECS
            if not hud.sleeping:
                chime("Bottle")
            hud.mode("idle")
            reset_ears()
            log('Listening for "Hey Jarvis"...')


if __name__ == "__main__":
    try:
        main()
        log("Jarvis offline.")
    except KeyboardInterrupt:
        log("Jarvis offline (Ctrl+C).")
        print("\nJarvis offline.")
    except sd.PortAudioError as e:
        log(f"Microphone error: {e}")
        sys.exit(f"Microphone error: {e}\nAllow Terminal to use the microphone in "
                 "System Settings > Privacy & Security > Microphone, then run Jarvis again.")
    except SystemExit:
        raise
    except Exception:
        log("CRASH\n" + traceback.format_exc())   # so a silent death leaves a trace in jarvis.log, not just the window
        raise
