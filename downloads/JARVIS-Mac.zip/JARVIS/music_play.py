#!/usr/bin/env python3
"""
music_play.py — synthesize and play back a musical idea as audio, and log it.

WHO THIS IS FOR
----------------
This script is called by Jarvis (an LLM voice assistant) after Jarvis has
already translated a spoken, natural-language musical idea from the user
(a jazz guitar student) into precise notes/chords + durations. This script
does NOT do any music theory or NLP — it only synthesizes sound from
already-structured input and (optionally) logs the idea to a markdown file.

Run with the project venv's python, e.g.:
    <the Jarvis folder>/.venv/bin/python \
        <the Jarvis folder>/music_play.py melody "C4:0.5 E4:0.5 G4:0.5 C5:1.0" --label "opening riff"

HOW TO INVOKE (two subcommands: "melody" and "chords")
--------------------------------------------------------
1) MELODY MODE — play a sequence of single notes.

   music_play.py melody "NOTE:DUR NOTE:DUR ..." [--label "text"] [--no-log] [--append-only]

   - NOTE is a letter A-G (upper or lower case), optional accidental
     ('#' for sharp or 'b' for flat), then an octave number, e.g. C4, F#3,
     Bb5. Octave numbers follow standard MIDI/scientific pitch notation
     where middle C is C4 (A4 = 440 Hz).
   - DUR is the note's duration in seconds, e.g. 0.5, 1.0, 0.25.
   - NOTE and DUR are joined by a colon, tokens are separated by spaces.
   - A rest (silence) is written as "R:<dur>" or "rest:<dur>", e.g. "R:0.5".

   Example:
     music_play.py melody "C4:0.5 E4:0.5 G4:0.5 C5:1.0 R:0.25 D4:0.5" --label "verse riff idea"

2) CHORD MODE — play a chord progression, one chord at a time.

   music_play.py chords "CHORD:DUR CHORD:DUR ..." [--label "text"] [--no-log] [--append-only]

   - CHORD is a root note letter (A-G, optional # or b) followed by a
     quality suffix. Supported quality suffixes (case sensitive first,
     falls back to case-insensitive):
         ""      or "maj"           -> major triad
         "m"     or "min" or "-"    -> minor triad
         "7"                        -> dominant 7th
         "maj7"  or "M7"            -> major 7th
         "m7"    or "min7" or "-7"  -> minor 7th
         "dim"   or "o"             -> diminished triad
         "aug"   or "+"             -> augmented triad
         "sus2"                     -> sus2
         "sus4"  or "sus"           -> sus4
         "6"                        -> major 6th
         "m6"    or "min6" or "-6"  -> minor 6th
         "9"                        -> dominant 9th
         "maj9"  or "M9"            -> major 9th
         "m9"    or "min9" or "-9"  -> minor 9th
     Examples of valid chord tokens: Cmaj7, Am7, Dm7, G7, Bbmaj7, C#dim,
     Esus4, Faug, G6, Am6, D9, Cmaj9, Fm9.
   - DUR is duration in seconds, same as melody mode.
   - Optional: override the default voicing octave with "@<octave>"
     right after the quality, e.g. "Cmaj7@2:1.0" voices the chord an
     octave lower. Default root octave is 3 (a comfortable low/mid guitar
     register); chord tones are stacked upward from there.

   Example:
     music_play.py chords "Cmaj7:1.0 Am7:1.0 Dm7:1.0 G7:1.0" --label "turnaround idea"

3) DISCOVERY — list supported chord quality suffixes:
     music_play.py list-chords

FLAGS (apply to both melody and chords)
----------------------------------------
  --label TEXT       Short human-readable description of the idea, stored
                      in the log. If omitted, logged as "(untitled idea)".
  --no-log           Do not write an entry to the log file. By default,
                      every successful play IS logged.
  --append-only      Write the log entry WITHOUT synthesizing or playing
                      any audio. Use this when the user just wants an idea
                      saved for later, not played right now.
                      (Combining --append-only with --no-log is an error —
                      there would be nothing to do.)

WHAT HAPPENS
-------------
- Audio is synthesized as sine waves (fundamental + two quiet harmonics
  for a slightly warmer, less harsh timbre than a pure sine), with a short
  attack/release fade on every note/chord segment to avoid clicks/pops.
- The result is written to a temporary WAV file under /tmp and then played
  immediately with the macOS `afplay` command (playback is awaited —
  the process doesn't exit until the sound has finished playing).
- Unless --append-only or --no-log is given, a timestamped entry is always
  appended to:
      <the Jarvis folder>/music_ideas.md
  so a future Jarvis session can read that file to recall past ideas
  (e.g. "what was that last riff idea?").

EXIT CODES
-----------
  0  success
  1  bad input (couldn't parse notes/chords/durations) or playback error

This script requires numpy (already present in the project venv at
<the Jarvis folder>/.venv/bin/python). It uses only the
stdlib `wave` module to write audio files (no extra WAV library needed).
"""

import argparse
import datetime
import json
import os
import subprocess
import sys
import tempfile
import urllib.request
import wave

import numpy as np

SAMPLE_RATE = 44100
DEFAULT_CHORD_OCTAVE = 3
FADE_MS = 15  # attack/release fade length in milliseconds
LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "music_ideas.md")
HUD_PORT = int(os.environ.get("JARVIS_HUD_PORT", "8770"))


def tokens_to_steps(tokens):
    """[('C4:0.5'), ...] -> [{"label": "C4", "dur": 0.5}, ...] for the HUD's live notation."""
    steps = []
    for token in tokens:
        label, _, dur = token.partition(":")
        try:
            dur = float(dur)
        except ValueError:
            dur = 0.5
        steps.append({"label": "·" if label.upper() in ("R", "REST") else label, "dur": dur})
    return steps


def notate_hud(title, chords=None, melody=None):
    """Best-effort: tell the HUD to animate this idea in sync with playback. Silent if it's not running."""
    try:
        req = urllib.request.Request(
            f"http://127.0.0.1:{HUD_PORT}/notate",
            data=json.dumps({"title": title, "chords": chords or [], "melody": melody or []}).encode(),
            headers={"content-type": "application/json"}, method="POST",
        )
        urllib.request.urlopen(req, timeout=1)
    except Exception:  # noqa: BLE001
        pass

PITCH_CLASS = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}

# Chord quality -> intervals in semitones from the root.
CHORD_INTERVALS = {
    "major": [0, 4, 7],
    "minor": [0, 3, 7],
    "dom7": [0, 4, 7, 10],
    "maj7": [0, 4, 7, 11],
    "min7": [0, 3, 7, 10],
    "dim": [0, 3, 6],
    "m7b5": [0, 3, 6, 10],
    "aug": [0, 4, 8],
    "sus2": [0, 2, 7],
    "sus4": [0, 5, 7],
    "six": [0, 4, 7, 9],
    "min6": [0, 3, 7, 9],
    "dom9": [0, 4, 7, 10, 14],
    "maj9": [0, 4, 7, 11, 14],
    "min9": [0, 3, 7, 10, 14],
}

# Quality suffix string (as typed after the root) -> canonical quality name.
# Checked case-sensitively first, then a lowercase fallback pass runs.
QUALITY_ALIASES = {
    "": "major", "maj": "major", "M": "major",
    "m": "minor", "min": "minor", "-": "minor",
    "7": "dom7",
    "maj7": "maj7", "M7": "maj7",
    "m7": "min7", "min7": "min7", "-7": "min7",
    "dim": "dim", "o": "dim",
    "m7b5": "m7b5", "min7b5": "m7b5", "-7b5": "m7b5",
    "aug": "aug", "+": "aug",
    "sus2": "sus2",
    "sus4": "sus4", "sus": "sus4",
    "6": "six",
    "m6": "min6", "min6": "min6", "-6": "min6",
    "9": "dom9",
    "maj9": "maj9", "M9": "maj9",
    "m9": "min9", "min9": "min9", "-9": "min9",
}
# Lowercase fallback map (built once).
_QUALITY_ALIASES_LOWER = {k.lower(): v for k, v in QUALITY_ALIASES.items()}


class MusicInputError(ValueError):
    """Raised when the note/chord string can't be parsed."""


def note_letter_to_midi(letter, accidental, octave):
    letter = letter.upper()
    if letter not in PITCH_CLASS:
        raise MusicInputError(f"Unknown note letter '{letter}'")
    semis = PITCH_CLASS[letter]
    if accidental == "#":
        semis += 1
    elif accidental == "b":
        semis -= 1
    return (octave + 1) * 12 + semis


def midi_to_freq(midi):
    return 440.0 * (2.0 ** ((midi - 69) / 12.0))


def parse_melody_note(token):
    """Return (freq_or_None, duration). freq is None for a rest."""
    if ":" not in token:
        raise MusicInputError(
            f"Melody token '{token}' is missing ':<duration>' (e.g. 'C4:0.5')"
        )
    note_str, dur_str = token.rsplit(":", 1)
    try:
        duration = float(dur_str)
    except ValueError:
        raise MusicInputError(f"Bad duration '{dur_str}' in token '{token}'")
    if duration <= 0:
        raise MusicInputError(f"Duration must be > 0 in token '{token}'")

    if note_str.strip().upper() in ("R", "REST"):
        return None, duration

    import re
    m = re.match(r"^([A-Ga-g])([#b]?)(-?\d+)$", note_str.strip())
    if not m:
        raise MusicInputError(
            f"Bad note '{note_str}' in token '{token}'. "
            "Expected e.g. 'C4', 'F#3', 'Bb5', or 'R'/'rest' for silence."
        )
    letter, accidental, octave = m.group(1), m.group(2), int(m.group(3))
    midi = note_letter_to_midi(letter, accidental, octave)
    return midi_to_freq(midi), duration


def parse_chord_quality(quality_str):
    if quality_str in QUALITY_ALIASES:
        return CHORD_INTERVALS[QUALITY_ALIASES[quality_str]]
    lowered = quality_str.lower()
    if lowered in _QUALITY_ALIASES_LOWER:
        return CHORD_INTERVALS[_QUALITY_ALIASES_LOWER[lowered]]
    raise MusicInputError(
        f"Unknown chord quality '{quality_str}'. "
        "Run 'music_play.py list-chords' to see supported qualities."
    )


def parse_chord_token(token):
    """Return (list_of_freqs, duration) for one 'CHORD:DUR' token."""
    import re
    if ":" not in token:
        raise MusicInputError(
            f"Chord token '{token}' is missing ':<duration>' (e.g. 'Cmaj7:1.0')"
        )
    chord_str, dur_str = token.rsplit(":", 1)
    try:
        duration = float(dur_str)
    except ValueError:
        raise MusicInputError(f"Bad duration '{dur_str}' in token '{token}'")
    if duration <= 0:
        raise MusicInputError(f"Duration must be > 0 in token '{token}'")

    chord_str = chord_str.strip()
    octave = DEFAULT_CHORD_OCTAVE
    octave_match = re.search(r"@(-?\d+)$", chord_str)
    if octave_match:
        octave = int(octave_match.group(1))
        chord_str = chord_str[: octave_match.start()]

    m = re.match(r"^([A-Ga-g])([#b]?)(.*)$", chord_str)
    if not m:
        raise MusicInputError(f"Bad chord '{chord_str}' in token '{token}'")
    letter, accidental, quality_str = m.group(1), m.group(2), m.group(3)
    root_midi = note_letter_to_midi(letter, accidental, octave)
    intervals = parse_chord_quality(quality_str)
    freqs = [midi_to_freq(root_midi + i) for i in intervals]
    return freqs, duration


def envelope(n_samples, sr=SAMPLE_RATE, fade_ms=FADE_MS):
    """Linear attack/release fade to avoid clicks. Safe for tiny n_samples."""
    if n_samples <= 0:
        return np.zeros(0)
    fade_samples = min(int(sr * fade_ms / 1000), n_samples // 2)
    env = np.ones(n_samples)
    if fade_samples > 0:
        ramp = np.linspace(0.0, 1.0, fade_samples)
        env[:fade_samples] *= ramp
        env[n_samples - fade_samples:] *= ramp[::-1]
    return env


def raw_tone(freq, duration, sr=SAMPLE_RATE):
    """Sine fundamental + two quiet harmonics for a warmer timbre. No envelope."""
    n = int(sr * duration)
    if n <= 0:
        return np.zeros(0)
    t = np.arange(n) / sr
    wave_data = (
        0.6 * np.sin(2 * np.pi * freq * t)
        + 0.3 * np.sin(2 * np.pi * 2 * freq * t)
        + 0.1 * np.sin(2 * np.pi * 3 * freq * t)
    )
    return wave_data


def build_melody_buffer(tokens):
    segments = []
    for token in tokens:
        freq, duration = parse_melody_note(token)
        n = int(SAMPLE_RATE * duration)
        segment = np.zeros(n) if freq is None else raw_tone(freq, duration)
        segment = segment * envelope(len(segment))
        segments.append(segment)
    return np.concatenate(segments) if segments else np.zeros(0)


def build_chord_buffer(tokens):
    segments = []
    for token in tokens:
        freqs, duration = parse_chord_token(token)
        n = int(SAMPLE_RATE * duration)
        mix = np.zeros(n)
        for f in freqs:
            mix += raw_tone(f, duration)
        if freqs:
            mix /= len(freqs)
        mix = mix * envelope(len(mix))
        segments.append(mix)
    return np.concatenate(segments) if segments else np.zeros(0)


def normalize(buffer_, target_peak=0.9):
    peak = np.max(np.abs(buffer_)) if buffer_.size else 0.0
    if peak > 0:
        buffer_ = buffer_ * (target_peak / peak)
    return buffer_


def write_wav(path, buffer_, sr=SAMPLE_RATE):
    clipped = np.clip(buffer_, -1.0, 1.0)
    pcm = (clipped * 32767.0).astype(np.int16)
    with wave.open(path, "w") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(sr)
        f.writeframes(pcm.tobytes())


def play_wav(path):
    subprocess.run(["afplay", path], check=True)


def log_idea(mode, sequence, label):
    label = label or "(untitled idea)"
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    is_new = not os.path.exists(LOG_PATH)
    with open(LOG_PATH, "a") as f:
        if is_new:
            f.write("# Music Ideas Log\n\n")
            f.write(
                "Running log of musical ideas played/saved via music_play.py. "
                "Newest entries at the bottom.\n\n"
            )
        f.write(f"## {timestamp} — {label}\n")
        f.write(f"- type: {mode}\n")
        f.write(f"- input: `{sequence}`\n\n")


def list_chords():
    print("Supported chord quality suffixes (attach directly after the root note):\n")
    seen_canonical = set()
    for alias, canonical in QUALITY_ALIASES.items():
        seen_canonical.add(canonical)
    by_canonical = {}
    for alias, canonical in QUALITY_ALIASES.items():
        by_canonical.setdefault(canonical, []).append(alias if alias else '""(none)')
    for canonical, aliases in by_canonical.items():
        print(f"  {canonical:8s} : " + ", ".join(aliases))
    print('\nExample: "Cmaj7" "Am7" "Dm7" "G7" "Bbmaj9" "C#dim" "Esus4" "Faug" "G6" "Am6"')


def run_mode(mode, args):
    sequence = args.sequence.strip()
    if not sequence:
        print(f"error: empty {mode} sequence", file=sys.stderr)
        return 1
    if args.append_only and args.no_log:
        print("error: --append-only and --no-log together would do nothing", file=sys.stderr)
        return 1

    tokens = sequence.split()

    try:
        if not args.append_only:
            builder = build_melody_buffer if mode == "melody" else build_chord_buffer
            buffer_ = builder(tokens)
            buffer_ = normalize(buffer_)
            with tempfile.NamedTemporaryFile(
                prefix=f"music_play_{mode}_", suffix=".wav", dir="/tmp", delete=False
            ) as tmp:
                wav_path = tmp.name
            write_wav(wav_path, buffer_)
            steps = tokens_to_steps(tokens)
            notate_hud(args.label or "(untitled idea)",
                       chords=steps if mode == "chords" else None,
                       melody=steps if mode == "melody" else None)
            play_wav(wav_path)
        else:
            # Still validate the sequence even if we're not playing it, so a
            # bad idea doesn't get silently logged as if it were valid.
            parser_fn = parse_melody_note if mode == "melody" else parse_chord_token
            for token in tokens:
                parser_fn(token)
    except MusicInputError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    except subprocess.CalledProcessError as e:
        print(f"error: afplay failed: {e}", file=sys.stderr)
        return 1

    if not args.no_log:
        log_idea(mode, sequence, args.label)

    return 0


def run_together(args):
    chord_tokens = args.chords.strip().split()
    melody_tokens = args.melody.strip().split()
    if not chord_tokens or not melody_tokens:
        print("error: both --chords and --melody need at least one token", file=sys.stderr)
        return 1

    try:
        chord_buffer = build_chord_buffer(chord_tokens) * 0.6
        melody_buffer = build_melody_buffer(melody_tokens)
        n = max(len(chord_buffer), len(melody_buffer))
        chord_buffer = np.pad(chord_buffer, (0, n - len(chord_buffer)))
        melody_buffer = np.pad(melody_buffer, (0, n - len(melody_buffer)))
        buffer_ = normalize(chord_buffer + melody_buffer)
        with tempfile.NamedTemporaryFile(
            prefix="music_play_together_", suffix=".wav", dir="/tmp", delete=False
        ) as tmp:
            wav_path = tmp.name
        write_wav(wav_path, buffer_)
        notate_hud(args.label or "(untitled idea)",
                   chords=tokens_to_steps(chord_tokens), melody=tokens_to_steps(melody_tokens))
        play_wav(wav_path)
    except MusicInputError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    except subprocess.CalledProcessError as e:
        print(f"error: afplay failed: {e}", file=sys.stderr)
        return 1

    if not args.no_log:
        label = args.label or "(untitled idea)"
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        is_new = not os.path.exists(LOG_PATH)
        with open(LOG_PATH, "a") as f:
            if is_new:
                f.write("# Music Ideas Log\n\n")
                f.write(
                    "Running log of musical ideas played/saved via music_play.py. "
                    "Newest entries at the bottom.\n\n"
                )
            f.write(f"## {timestamp} — {label}\n")
            f.write("- type: together\n")
            f.write(f"- chords: `{args.chords.strip()}`\n")
            f.write(f"- melody: `{args.melody.strip()}`\n\n")

    return 0


def main():
    parser = argparse.ArgumentParser(
        prog="music_play.py",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=__doc__,
    )
    subparsers = parser.add_subparsers(dest="mode", required=True)

    melody_parser = subparsers.add_parser(
        "melody",
        help='Play a sequence of single notes, e.g. "C4:0.5 E4:0.5 G4:0.5 C5:1.0"',
    )
    melody_parser.add_argument(
        "sequence",
        help='Space-separated NOTE:DURATION tokens, e.g. "C4:0.5 E4:0.5 G4:0.5 C5:1.0". '
        "Use R:0.5 or rest:0.5 for silence.",
    )
    melody_parser.add_argument("--label", default=None, help="Short description for the log")
    melody_parser.add_argument("--no-log", action="store_true", help="Don't write a log entry")
    melody_parser.add_argument(
        "--append-only", action="store_true",
        help="Only log the idea; don't synthesize or play audio",
    )

    chords_parser = subparsers.add_parser(
        "chords",
        help='Play a chord progression, e.g. "Cmaj7:1.0 Am7:1.0 Dm7:1.0 G7:1.0"',
    )
    chords_parser.add_argument(
        "sequence",
        help='Space-separated CHORD:DURATION tokens, e.g. "Cmaj7:1.0 Am7:1.0 Dm7:1.0 G7:1.0". '
        'Optional octave override: "Cmaj7@2:1.0". Run "music_play.py list-chords" for '
        "supported chord quality suffixes.",
    )
    chords_parser.add_argument("--label", default=None, help="Short description for the log")
    chords_parser.add_argument("--no-log", action="store_true", help="Don't write a log entry")
    chords_parser.add_argument(
        "--append-only", action="store_true",
        help="Only log the idea; don't synthesize or play audio",
    )

    together_parser = subparsers.add_parser(
        "together",
        help="Layer a melody over a chord progression and play them at the same time",
    )
    together_parser.add_argument(
        "--chords", required=True,
        help='Space-separated CHORD:DURATION tokens, e.g. "Cmaj7:1.0 Am7:1.0 Fmaj7:1.0 G7:1.0"',
    )
    together_parser.add_argument(
        "--melody", required=True,
        help='Space-separated NOTE:DURATION tokens, e.g. "C4:0.5 E4:0.5 A4:0.5 G4:1.0"',
    )
    together_parser.add_argument("--label", default=None, help="Short description for the log")
    together_parser.add_argument("--no-log", action="store_true", help="Don't write a log entry")

    subparsers.add_parser("list-chords", help="Print supported chord quality suffixes")

    args = parser.parse_args()

    if args.mode == "list-chords":
        list_chords()
        return 0

    if args.mode == "together":
        return run_together(args)

    return run_mode(args.mode, args)


if __name__ == "__main__":
    sys.exit(main())
