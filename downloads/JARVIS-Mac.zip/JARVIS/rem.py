#!/usr/bin/env python3
"""Fast Reminders lookup straight from your Mac's Reminders data (every list, every account).

  rem.py due                       everything incomplete with a due date up to end of today (plus overdue)
  rem.py due week | due overdue | due all
  rem.py add "Practice Autumn Leaves" 2026-10-12 19:00 [--list Music]
  rem.py add "Buy strings" tomorrow 9am
  rem.py done "Autumn Leaves"      marks the first incomplete reminder whose title contains the words

Much faster than walking Reminders.app through AppleScript. Same EventKit access as cal.py.
"""
import datetime as dt
import re
import sys
import time

try:
    from EventKit import EKAlarm, EKEntityTypeReminder, EKEventStore, EKReminder
    from Foundation import NSCalendar, NSDate, NSDateComponents, NSRunLoop
except ImportError:
    print("Reminders helper not installed yet (pyobjc-framework-EventKit). Use Reminders.app via osascript for now.")
    sys.exit(3)

AUTHORIZED = (3, 4)   # EKAuthorizationStatus: 3 = full access (or 'authorized' before macOS 14), 4 = write-only


def spin(done, limit):
    end = time.time() + limit
    while not done() and time.time() < end:
        NSRunLoop.currentRunLoop().runUntilDate_(NSDate.dateWithTimeIntervalSinceNow_(0.05))
    return done()


def access(store) -> bool:
    status = EKEventStore.authorizationStatusForEntityType_(EKEntityTypeReminder)
    if status in AUTHORIZED:
        return True
    if status in (1, 2):   # restricted / denied: don't wait on a dialog nobody can click
        return False
    got = {"ok": None}

    def cb(granted, err):
        got["ok"] = bool(granted)

    if hasattr(store, "requestFullAccessToRemindersWithCompletion_"):
        store.requestFullAccessToRemindersWithCompletion_(cb)
    else:
        store.requestAccessToEntityType_completion_(EKEntityTypeReminder, cb)
    spin(lambda: got["ok"] is not None, 15)
    return bool(got["ok"])


def ns(d: dt.datetime):
    return NSDate.dateWithTimeIntervalSince1970_(d.timestamp())


def due_date(r):
    comps = r.dueDateComponents()
    if comps is None:
        return None
    d = NSCalendar.currentCalendar().dateFromComponents_(comps)
    if d is None:
        return None
    return dt.datetime.fromtimestamp(d.timeIntervalSince1970())


def fmt_when(d: dt.datetime) -> str:
    day = d.strftime("%a %b %-d")
    if d.hour == 0 and d.minute == 0:
        return day
    return day + " " + d.strftime("%-I:%M %p").replace(":00 ", " ")


def fetch_incomplete(store, start, end):
    pred = store.predicateForIncompleteRemindersWithDueDateStarting_ending_calendars_(
        ns(start) if start else None, ns(end) if end else None, None)
    got = {"items": None}

    def cb(items):
        got["items"] = list(items or [])

    store.fetchRemindersMatchingPredicate_completion_(pred, cb)
    spin(lambda: got["items"] is not None, 20)
    return got["items"] or []


def parse_when(words):
    """'2026-10-12 19:00', '2026-10-12', 'tomorrow 9am', 'today 4:30pm', 'friday 7pm' -> datetime (or None)."""
    text = " ".join(words).strip().lower()
    if not text:
        return None
    now = dt.datetime.now()
    base = None
    m = re.match(r"(\d{4}-\d{2}-\d{2})", text)
    if m:
        base = dt.datetime.strptime(m.group(1), "%Y-%m-%d")
        text = text[m.end():].strip()
    elif text.startswith("today"):
        base, text = now.replace(hour=0, minute=0, second=0, microsecond=0), text[5:].strip()
    elif text.startswith("tomorrow"):
        base, text = (now + dt.timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0), text[8:].strip()
    else:
        days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
        for i, name in enumerate(days):
            if text.startswith(name) or text.startswith(name[:3] + " ") or text == name[:3]:
                ahead = (i - now.weekday()) % 7 or 7
                base = (now + dt.timedelta(days=ahead)).replace(hour=0, minute=0, second=0, microsecond=0)
                text = text[len(name) if text.startswith(name) else 3:].strip()
                break
    if base is None:
        base = now.replace(hour=0, minute=0, second=0, microsecond=0)
    m = re.match(r"(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm)?", text)
    if m:
        h, mi, ap = int(m.group(1)), int(m.group(2) or 0), m.group(3)
        if ap == "pm" and h < 12:
            h += 12
        if ap == "am" and h == 12:
            h = 0
        if not ap and h < 7:   # "at 4" with no am/pm: a student means the afternoon
            h += 12
        base = base.replace(hour=h, minute=mi)
    return base


def main():
    args = sys.argv[1:] or ["due"]
    store = EKEventStore.alloc().init()
    if not access(store):
        print("No Reminders access. In System Settings > Privacy & Security > Reminders, turn on Python "
              "(or the app you launched Jarvis from), then try again.")
        sys.exit(2)
    now = dt.datetime.now()
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)

    if args[0] == "due":
        scope = args[1] if len(args) > 1 else "today"
        if scope == "overdue":
            items = fetch_incomplete(store, None, now)
        elif scope == "week":
            items = fetch_incomplete(store, None, midnight + dt.timedelta(days=7))
        elif scope == "all":
            items = fetch_incomplete(store, None, None)
        else:
            items = fetch_incomplete(store, None, midnight + dt.timedelta(days=1))
        rows = []
        for r in items:
            d = due_date(r)
            rows.append((d or dt.datetime.max, str(r.title() or "(untitled)"), str(r.calendar().title() or ""), d))
        rows.sort(key=lambda x: x[0])
        if not rows:
            print("No reminders due.")
            return
        for _, title, lst, d in rows[:60]:
            when = ("OVERDUE " if d and d < now else "") + (fmt_when(d) if d else "no date")
            print(" | ".join(x for x in (when, title, f"[{lst}]") if x))
        return

    if args[0] == "add" and len(args) > 1:
        title = args[1]
        rest = args[2:]
        list_name = None
        if "--list" in rest:
            i = rest.index("--list")
            list_name = rest[i + 1] if i + 1 < len(rest) else None
            rest = rest[:i] + rest[i + 2:]
        when = parse_when(rest)
        r = EKReminder.reminderWithEventStore_(store)
        r.setTitle_(title)
        cal = store.defaultCalendarForNewReminders()
        if list_name:
            for c in store.calendarsForEntityType_(EKEntityTypeReminder) or []:
                if list_name.lower() in str(c.title() or "").lower():
                    cal = c
                    break
        r.setCalendar_(cal)
        if when:
            comps = NSDateComponents.alloc().init()
            comps.setYear_(when.year)
            comps.setMonth_(when.month)
            comps.setDay_(when.day)
            if when.hour or when.minute:
                comps.setHour_(when.hour)
                comps.setMinute_(when.minute)
            r.setDueDateComponents_(comps)
            if when.hour or when.minute:
                r.addAlarm_(EKAlarm.alarmWithAbsoluteDate_(ns(when)))
        ok, err = store.saveReminder_commit_error_(r, True, None)
        if not ok:
            print(f"Couldn't save the reminder: {err}")
            sys.exit(1)
        print(f"Added: {title}" + (f" | {fmt_when(when)}" if when else "") + f" [{cal.title()}]")
        return

    if args[0] == "done" and len(args) > 1:
        words = " ".join(args[1:]).lower()
        for r in fetch_incomplete(store, None, None):
            if words in str(r.title() or "").lower():
                r.setCompleted_(True)
                ok, err = store.saveReminder_commit_error_(r, True, None)
                print(f"Done: {r.title()}" if ok else f"Couldn't mark it done: {err}")
                return
        print("No incomplete reminder matches that.")
        sys.exit(1)

    sys.exit(__doc__)


if __name__ == "__main__":
    main()
