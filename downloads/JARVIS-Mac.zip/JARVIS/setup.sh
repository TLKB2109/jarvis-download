#!/bin/bash
# One-time setup for JARVIS. Run from Terminal:  bash setup.sh
# Safe to run again later: it only does what is still missing.
set -e
cd "$(dirname "$0")"
echo "=== Setting up JARVIS ==="

# Files downloaded from the web are quarantined by macOS; clear that so the launcher opens.
xattr -dr com.apple.quarantine . 2>/dev/null || true
chmod +x Jarvis.command jarvis.py *.py 2>/dev/null || true

# 1. Python (prefer a newer Homebrew Python if you have one)
PY=""
for c in python3.12 python3.11 python3.13 python3.10 python3; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c "import sys; assert sys.version_info >= (3,10)" 2>/dev/null; then PY="$c"; break; fi
done
if [ -z "$PY" ]; then
  echo "Python 3.10 or newer isn't installed. Get it from https://www.python.org/downloads/macos/ (the macOS installer),"
  echo "then run:  bash setup.sh  again."
  exit 1
fi
echo "Using $($PY --version)"

# 2. Who Jarvis works for (.env). Asked once; edit .env later to change anything.
if [ ! -f .env ]; then
  if [ -t 0 ]; then
    echo
    echo "A few questions so Jarvis knows who he's talking to (press Return to skip any):"
    read -r -p "  Your first name: " NAME
    read -r -p "  One sentence about you (school, hobbies...), e.g. 'is a junior at Lincoln High and plays guitar': " ABOUT
    read -r -p "  Your city (for weather): " CITY
    TZ_GUESS="$(readlink /etc/localtime 2>/dev/null | sed 's#.*/zoneinfo/##')"
    read -r -p "  Time zone [${TZ_GUESS:-America/Los_Angeles}]: " TZV
    read -r -p "  Your personal email: " EMAIL
    read -r -p "  Your school email (optional): " SCHOOL
    PIN="$(( RANDOM % 900000 + 100000 ))"
    read -r -p "  PIN for the phone page [$PIN]: " PINV
    {
      echo "JARVIS_USER_NAME=${NAME:-Sir}"
      [ -n "$ABOUT" ] && echo "JARVIS_USER_ABOUT=$ABOUT"
      [ -n "$CITY" ] && echo "JARVIS_USER_CITY=$CITY"
      echo "JARVIS_USER_TZ=${TZV:-${TZ_GUESS:-America/Los_Angeles}}"
      [ -n "$EMAIL" ] && echo "JARVIS_PERSONAL_EMAIL=$EMAIL"
      [ -n "$SCHOOL" ] && echo "JARVIS_SCHOOL_EMAIL=$SCHOOL"
      echo "PHONE_PIN=${PINV:-$PIN}"
      echo "# More settings: see .env.example (ElevenLabs voice key, planner sheet, thresholds...)"
    } > .env
    echo "  Saved to .env"
  else
    cp .env.example .env
    echo "Created .env from .env.example - edit it with your name and details."
  fi
fi
chmod 600 .env

# 3. Private Python environment + packages
[ -d .venv ] || "$PY" -m venv .venv
.venv/bin/pip install --quiet --upgrade pip
echo "Installing packages (a few minutes the first time)..."
.venv/bin/pip install --quiet -r requirements.txt
if [ "$(uname -m)" = "arm64" ]; then
  .venv/bin/pip install --quiet mlx-whisper || echo "  (mlx-whisper didn't install; Jarvis will transcribe on the CPU, a bit slower)"
fi

# 4. Download the models once (wake word, speech recognition, the voice)
echo "Downloading the wake-word and speech models..."
.venv/bin/python -c "import openwakeword.utils as u; u.download_models(['hey_jarvis'])" >/dev/null
WHISPER="$(grep -E '^JARVIS_WHISPER=' .env | cut -d= -f2- | tr -d '"' )"
.venv/bin/python -c "from faster_whisper import WhisperModel; WhisperModel('${WHISPER:-small}', device='cpu', compute_type='int8')" >/dev/null 2>&1 || true
if [ "$(uname -m)" = "arm64" ]; then
  echo "Warming up the fast (GPU) transcription model (one-time download, ~500 MB)..."
  .venv/bin/python -c "import numpy as np, mlx_whisper; mlx_whisper.transcribe(np.zeros(16000, dtype=np.float32), path_or_hf_repo='mlx-community/whisper-small-mlx', language='en')" >/dev/null 2>&1 || echo "  (skipped; it'll download on first run instead)"
fi
mkdir -p voice
for f in kokoro-v1.0.onnx voices-v1.0.bin; do
  if [ ! -s "voice/$f" ]; then
    echo "Downloading voice file $f..."
    curl -fL --progress-bar -o "voice/$f.part" "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/$f" && mv "voice/$f.part" "voice/$f"
  fi
done

# 5. Claude Code (the brain)
if ! command -v claude >/dev/null 2>&1 && [ ! -x "$HOME/.local/bin/claude" ]; then
  echo "Installing Claude Code..."
  curl -fsSL https://claude.ai/install.sh | bash
fi
CLAUDE="$(command -v claude || echo "$HOME/.local/bin/claude")"
echo "Checking your Claude sign-in..."
if "$CLAUDE" -p "Reply with just OK" --output-format json >/dev/null 2>&1; then
  echo "Signed in."
else
  echo
  echo ">>> Sign in once: Claude Code will open now. Log in with your claude.ai account,"
  echo ">>> then type /exit to come back here."
  "$CLAUDE" || true
fi

# 6. macOS permissions: trigger the dialogs now, while you're here to click Allow
echo
echo "macOS will now ask for a few permissions. Click Allow (or OK) on each:"
.venv/bin/python -c "import sounddevice as sd; sd.rec(8000, samplerate=16000, channels=1); sd.wait()" >/dev/null 2>&1 || echo "  (microphone: allow it in System Settings > Privacy & Security > Microphone for Terminal and Python)"
.venv/bin/python cal.py today >/dev/null 2>&1 || true
.venv/bin/python rem.py due >/dev/null 2>&1 || true

echo
echo "Connectors Claude Code can see (Gmail, Google Drive, Calendar, Spotify...):"
"$CLAUDE" mcp list 2>/dev/null || echo "  (couldn't list them)"
echo "To add connectors: on claude.ai go to Settings > Connectors and connect Gmail, Google Drive, Google Calendar and Spotify once;"
echo "Jarvis gets full access to them from then on."
echo
echo "=== Done. Double-click Jarvis.command (or run ./Jarvis.command) and say \"Hey Jarvis\". ==="
