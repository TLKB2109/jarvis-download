#!/usr/bin/env python3
"""Read a tab from a Google Sheet that the Drive connector exported as .xlsx.

Usage:
  sheet_tab.py <saved tool-result file>            -> list tabs
  sheet_tab.py <saved tool-result file> "<tab>"    -> print that tab's non-empty rows

The saved file can be any format (JSON, text); the .xlsx is found as base64 inside it.
"""
import base64
import io
import re
import sys
from datetime import date, datetime, time

import openpyxl


def load(path):
    raw = open(path, encoding="utf-8", errors="ignore").read()
    m = re.search(r"UEsDB[A-Za-z0-9+/=\\n]{200,}", raw)   # "UEsDB" = start of a zip/xlsx in base64
    if not m:
        sys.exit("No spreadsheet data found in that file.")
    b64 = m.group(0).replace("\\n", "")
    b64 += "=" * (-len(b64) % 4)
    return openpyxl.load_workbook(io.BytesIO(base64.b64decode(b64)), data_only=True, read_only=True)


def fmt(v):
    if v is None:
        return ""
    if isinstance(v, datetime):
        return v.strftime("%a %Y-%m-%d") if v.time() == time(0) else v.strftime("%a %Y-%m-%d %H:%M")
    if isinstance(v, (date, time)):
        return v.isoformat()
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).replace("\n", " ").strip()


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    wb = load(sys.argv[1])
    if len(sys.argv) < 3:
        for ws in wb.worksheets:
            print(ws.title)
        return
    want = sys.argv[2].strip().lower()
    name = next((n for n in wb.sheetnames if n.strip().lower() == want), None) \
        or next((n for n in wb.sheetnames if want in n.lower()), None)
    if not name:
        sys.exit(f'No tab named "{sys.argv[2]}". Tabs: {", ".join(wb.sheetnames)}')
    ws = wb[name]
    print(f"# {name}")
    shown = 0
    for i, row in enumerate(ws.iter_rows(values_only=True), start=1):
        cells = [fmt(v) for v in row]
        while cells and not cells[-1]:
            cells.pop()
        if any(cells):
            print(f"row {i}: " + " | ".join(cells))
            shown += 1
            if shown >= 400:
                print("... (truncated at 400 rows)")
                break
    if shown == 0:
        print("(tab is empty)")


if __name__ == "__main__":
    main()
