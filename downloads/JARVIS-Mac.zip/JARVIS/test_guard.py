import json, subprocess, sys

cases = [
    ("rm -f /tmp/foo.log", True),
    ("rm -rf ~/Documents", False),
    ("rm somefile.txt", False),
    ("launchctl list | grep foo", True),
    ("launchctl unload foo.plist", False),
    ("s" + "udo rm -rf /", False),
]

for cmd, should_pass in cases:
    payload = json.dumps({"tool_name": "Bash", "tool_input": {"command": cmd}})
    result = subprocess.run(
        [".venv/bin/python", "guard.py"],
        input=payload, capture_output=True, text=True, cwd="<the Jarvis folder>"
    )
    passed = result.returncode == 0
    status = "OK" if passed == should_pass else "MISMATCH"
    print(f"{status}: {cmd!r} -> exit={result.returncode} (expected pass={should_pass}, got pass={passed})")
