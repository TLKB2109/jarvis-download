#!/usr/bin/env python3
"""Timers that survive conversation resets and restarts (unlike `sleep N && afplay`).

  timer.py set 20m "stretch"        start a timer (20m, 90s, 1h30m, "25 minutes", "1 hour")
  timer.py list                     what's running and how long is left
  timer.py cancel <id|label words>  stop one

The timers live in .timers.json next to this file. jarvis.py checks them every second,
chimes and speaks "Your twenty-minute stretch timer is up" when one is due, and shows a
countdown tile on the display while they run.
"""
import json
import os
import re
import sys
import time
import uuid

HERE = os.path.dirname(os.path.abspath(__file__))
PATH = os.path.join(HERE, ".timers.json")


def load():
    try:
        with open(PATH) as f:
            return [t for t in json.load(f) if isinstance(t, dict) and "due" in t]
    except (OSError, ValueError):
        return []


def save(timers):
    tmp = PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(timers, f, indent=1)
    os.replace(tmp, PATH)


def parse_duration(text: str):
    """'20m' / '90s' / '1h30m' / '25 minutes' / '1 hour' / '1:30' (h:mm) -> seconds, or None."""
    t = text.strip().lower()
    m = re.fullmatch(r"(\d{1,2}):(\d{2})", t)
    if m:
        return int(m.group(1)) * 3600 + int(m.group(2)) * 60
    total = 0
    for num, unit in re.findall(r"(\d+(?:\.\d+)?)\s*(h(?:ours?|rs?)?|m(?:in(?:ute)?s?)?|s(?:ec(?:ond)?s?)?)\b", t):
        n = float(num)
        total += n * (3600 if unit.startswith("h") else 60 if unit.startswith("m") else 1)
    if total == 0 and re.fullmatch(r"\d+(?:\.\d+)?", t):
        total = float(t) * 60          # a bare number means minutes
    return int(total) or None


def say_duration(secs: int) -> str:
    h, m, s = secs // 3600, (secs % 3600) // 60, secs % 60
    parts = []
    if h:
        parts.append(f"{h} hour" + ("s" if h != 1 else ""))
    if m:
        parts.append(f"{m} minute" + ("s" if m != 1 else ""))
    if s and not h:
        parts.append(f"{s} second" + ("s" if s != 1 else ""))
    return " ".join(parts) or "0 seconds"


def pop_due(now=None):
    """Remove and return every timer that has gone off. Called by jarvis.py."""
    now = now or time.time()
    timers = load()
    due = [t for t in timers if t["due"] <= now]
    if due:
        save([t for t in timers if t["due"] > now])
    return due


def running(now=None):
    now = now or time.time()
    return sorted((t for t in load() if t["due"] > now), key=lambda t: t["due"])


def main():
    a = sys.argv[1:]
    if not a:
        print(__doc__)
        return
    if a[0] == "set" and len(a) > 1:
        secs = parse_duration(a[1])
        label = " ".join(a[2:]).strip()
        if not secs:
            # allow "set 25 minutes stretch" too
            joined = " ".join(a[1:])
            m = re.match(r"((?:\d+(?:\.\d+)?\s*(?:h|hours?|hrs?|m|min|mins|minutes?|s|secs?|seconds?)\s*)+)(.*)", joined)
            if m:
                secs, label = parse_duration(m.group(1)), m.group(2).strip()
        if not secs:
            sys.exit("Couldn't read that duration. Try: timer.py set 20m \"stretch\"")
        t = {"id": uuid.uuid4().hex[:6], "label": label, "secs": secs, "set": time.time(), "due": time.time() + secs}
        timers = load()
        timers.append(t)
        save(timers)
        print(f"{t['id']}  {say_duration(secs)}" + (f"  {label}" if label else ""))
        return
    if a[0] == "list":
        items = running()
        if not items:
            print("no timers")
        for t in items:
            left = int(t["due"] - time.time())
            print(f"{t['id']}  {say_duration(left)} left" + (f"  {t['label']}" if t.get("label") else ""))
        return
    if a[0] == "cancel" and len(a) > 1:
        key = " ".join(a[1:]).lower()
        timers = load()
        keep = [t for t in timers if not (t["id"] == key or (key and key in (t.get("label") or "").lower()))]
        if len(keep) == len(timers):
            sys.exit("no such timer")
        save(keep)
        print("cancelled")
        return
    print(__doc__)


if __name__ == "__main__":
    main()
