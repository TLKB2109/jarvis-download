#!/usr/bin/env python3
"""Check the ElevenLabs voice setup: is the key good, how many credits are left, do the voices work.

  voice_check.py            key, permissions, credits and reset date, one tiny synthesis test
  voice_check.py --play     also speak a sample line in each character's ElevenLabs voice (costs ~150 credits)
  voice_check.py --voices   list the voices the key can see (needs the voices_read permission)

Reads ELEVENLABS_API_KEY and the voice ids from .env next to this file (same as jarvis.py).
"""
import datetime as dt
import json
import os
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request
import wave

HERE = os.path.dirname(os.path.abspath(__file__))
for _line in (open(os.path.join(HERE, ".env")) if os.path.exists(os.path.join(HERE, ".env")) else []):
    _line = _line.strip()
    if _line and not _line.startswith("#") and "=" in _line:
        _k, _v = _line.split("=", 1)
        os.environ.setdefault(_k.strip(), _v.strip().strip('"').strip("'"))

KEY = os.environ.get("ELEVENLABS_API_KEY", "").strip()
API = "https://api.elevenlabs.io"
MODEL = "eleven_flash_v2_5"          # what jarvis.py uses: fast, and half the credits per character of the multilingual model
VOICES = {
    "Jarvis": os.environ.get("ELEVENLABS_VOICE_ID", "JBFqnCBsd6RMkjVDRZzb"),
    "Mavis": os.environ.get("ELEVENLABS_MAVIS_VOICE_ID", "EXAVITQu4vr4xnSDxMaL"),
    "Sloane": os.environ.get("ELEVENLABS_SLOANE_VOICE_ID", "XrExE9yKIg1WjnnlVkGX"),
    "ABG": os.environ.get("ELEVENLABS_ABG_VOICE_ID", "cgSgspJ2msm6clMCkdW9"),
    "Mario": os.environ.get("ELEVENLABS_MARIO_VOICE_ID", "TX3LPaxmHKxFdv7VOQHJ"),   # same defaults as jarvis.py
}
PLANS = [("Free", 10_000, 0), ("Starter", 30_000, 5), ("Creator", 100_000, 22), ("Pro", 500_000, 99)]


def call(path, body=None):
    req = urllib.request.Request(API + path, data=body, method="POST" if body else "GET",
                                 headers={"xi-api-key": KEY, "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            raw = r.read()
            return r.status, raw
    except urllib.error.HTTPError as e:
        return e.code, e.read()
    except Exception as e:  # noqa: BLE001
        return None, str(e).encode()


def detail(raw):
    try:
        d = json.loads(raw)
        d = d.get("detail", d)
        return d.get("message") or d.get("status") or str(d)[:160]
    except Exception:  # noqa: BLE001
        return raw.decode(errors="ignore")[:160]


def main():
    if not KEY:
        print("No ELEVENLABS_API_KEY in .env. Add a line like  ELEVENLABS_API_KEY=sk_...  and run this again.")
        sys.exit(1)
    print(f"Key: sk_…{KEY[-4:]} ({len(KEY)} chars)")

    code, raw = call("/v1/user/subscription")
    can_read_account = code == 200
    if code == 200:
        s = json.loads(raw)
        used, limit = s.get("character_count", 0), s.get("character_limit", 0)
        reset = s.get("next_character_count_reset_unix")
        when = dt.datetime.fromtimestamp(reset).strftime("%a %b %-d, %-I:%M %p") if reset else "?"
        print(f"Plan: {s.get('tier', '?')} ({s.get('status', '?')}).  Credits: {limit - used:,} of {limit:,} left, resets {when}.")
        print(f"  That's about {int((limit - used) * 2 / 1000)}k characters on the flash model, roughly {(limit - used) * 2 // 900} minutes of speech.")
    elif code == 401 and "missing" in detail(raw).lower():
        print("Credits: can't read them - the key lacks the 'User: read' permission. (TTS still works.)")
        print("  To see credits here and let Jarvis warn you before they run out, make a key with that permission (steps below).")
    else:
        print(f"Credits: couldn't check ({code}: {detail(raw)})")

    if "--voices" in sys.argv:
        code, raw = call("/v1/voices")
        if code == 200:
            for v in json.loads(raw).get("voices", []):
                print(f"  {v['voice_id']}  {v['name']}  {', '.join(str(x) for x in (v.get('labels') or {}).values())}")
        else:
            print(f"Voices: can't list them ({detail(raw)}) - needs the 'Voices: read' permission; voice ids in .env still work.")

    body = json.dumps({"text": "Testing.", "model_id": MODEL}).encode()
    code, raw = call(f"/v1/text-to-speech/{VOICES['Jarvis']}?output_format=pcm_22050", body)
    if code == 200:
        print(f"Synthesis: OK ({len(raw) / 44100:.1f}s of audio for the word Testing).")
    else:
        msg = detail(raw)
        print(f"Synthesis: FAILED ({code}: {msg})")
        if "quota" in msg.lower():
            print("  Out of credits for this month. Jarvis is on the Kokoro backup voice until they reset or you upgrade.")
        elif code == 401:
            print("  The key is wrong or disabled. Make a new one (steps below) and paste it into .env.")

    if "--play" in sys.argv and code == 200:
        for who, vid in VOICES.items():
            line = f"Hi, I'm {who}. This is my ElevenLabs voice."
            c, raw = call(f"/v1/text-to-speech/{vid}?output_format=pcm_22050", json.dumps({"text": line, "model_id": MODEL}).encode())
            if c != 200:
                print(f"  {who}: failed ({detail(raw)})")
                continue
            fd, path = tempfile.mkstemp(suffix=".wav")
            os.close(fd)
            with wave.open(path, "wb") as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(22050)
                w.writeframes(raw)
            print(f"  {who}: playing ({vid})")
            subprocess.run(["afplay", path], check=False)
            os.remove(path)

    print("\nPlans (credits per month; the flash model spends 0.5 per character):")
    for name, credits, price in PLANS:
        print(f"  {name:8} {credits:>8,} credits  ${price:>3}/mo  ~{credits * 2 // 900:>4} min of speech")
    print("Jarvis talks roughly 10-15 minutes a day, so Free lasts ~2 days, Starter ~5, Creator ~3 weeks.")
    if not can_read_account:
        print("\nTo make a key Jarvis can fully use: elevenlabs.io > Developers (left sidebar) > API Keys > Create Key,")
        print("leave it unrestricted (or allow Text to Speech, User read, Voices read), copy it, and put  ELEVENLABS_API_KEY=sk_...  in .env.")


if __name__ == "__main__":
    main()
