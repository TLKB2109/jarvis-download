#!/usr/bin/env python3
"""Edwin's job runner: background work that survives Jarvis restarts and ended conversations.

  worker.py start "<label>" "<prompt>" [--parallel]   queue a job, prints its id (returns at once)
  worker.py list                                       every job and its status
  worker.py status <id>                                one job in full
  worker.py followup <id> "<more instructions>"        continue a finished job with its full memory
  worker.py cancel <id>

Each job is a detached `claude -p` process (own session, so restarting Jarvis never touches it) with its
state in jobs/<id>/job.json and a running log in jobs/<id>/log.txt. Jobs run one at a time, in order, so
two of them never edit the same file at once; --parallel skips the queue. jarvis.py watches jobs/ and
shows progress tiles on the HUD, then tells the user when each job finishes.
"""
import fcntl
import json
import os
import shutil
import signal
import subprocess
import sys
import time
import uuid

HERE = os.path.dirname(os.path.abspath(__file__))
JOBS = os.path.join(HERE, "jobs")
LOCK = os.path.join(JOBS, ".queue.lock")

# Same .env as jarvis.py, so the worker knows who it works for without hard-coding anyone.
_ENV = os.path.join(HERE, ".env")
if os.path.exists(_ENV):
    for _line in open(_ENV):
        _line = _line.strip()
        if _line and not _line.startswith("#") and "=" in _line:
            _k, _v = _line.split("=", 1)
            os.environ.setdefault(_k.strip(), _v.strip().strip('"').strip("'"))
MODEL = os.environ.get("JARVIS_WORKER_MODEL", "sonnet")
USER_NAME = os.environ.get("JARVIS_USER_NAME", "the user")
USER_ABOUT = os.environ.get("JARVIS_USER_ABOUT", "")
LOG_LINE_CAP = 6000        # tool results can be huge; keep log.txt readable and small
KEEP_LOGS_DAYS = 7

BRIEF = (
    f"You are Edwin, Jarvis's background worker. {USER_NAME} asked Jarvis for the task below; "
    "Jarvis handed it to you so it keeps going even if Jarvis restarts. "
    + (f"About {USER_NAME}: {USER_NAME} {USER_ABOUT.rstrip('.')}. " if USER_ABOUT else "") +
    "Work in this folder (the Jarvis project). "
    "Never send emails or texts, post, buy or delete anything without it being in the task itself. "
    "If you edit jarvis.py, hud.html or other live files, make small careful edits and syntax-check them "
    "(python -m py_compile, node --check on extracted JS) since Jarvis reloads them on its own. "
    "When finished, append one bullet about what you produced to today's case file "
    "(case_files/daily/YYYY/MM/YYYY-MM-DD.md, create it with a '# YYYY-MM-DD' header if missing), then reply with a "
    "short plain-spoken summary (two or three sentences, no markdown) of what you did "
    f"and anything {USER_NAME} still needs to do or check.\n\nTASK:\n"
)


def _path(jid, name="job.json"):
    return os.path.join(JOBS, jid, name)


def load(jid):
    try:
        with open(_path(jid)) as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def save(job):
    tmp = _path(job["id"], "job.json.tmp")
    with open(tmp, "w") as f:
        json.dump(job, f, indent=1)
    os.replace(tmp, _path(job["id"]))


def all_jobs():
    out = []
    if os.path.isdir(JOBS):
        for jid in sorted(os.listdir(JOBS)):
            j = load(jid) if not jid.startswith(".") else None
            if j:
                out.append(j)
    return out


def alive(pid):
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def find_claude():
    return shutil.which("claude") or os.path.expanduser("~/.local/bin/claude")


def spawn(jid):
    subprocess.Popen([sys.executable, os.path.abspath(__file__), "_run", jid], cwd=HERE, start_new_session=True,
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def cmd_start(label, prompt, parallel=False, session=None):
    jid = uuid.uuid4().hex[:6]
    os.makedirs(os.path.join(JOBS, jid), exist_ok=True)
    job = {"id": jid, "label": label, "prompt": prompt, "status": "queued", "pct": 2, "activity": "waiting its turn",
           "created": time.time(), "started": None, "finished": None, "result": "", "session": session,
           "parallel": parallel, "announced": False, "runner_pid": None}
    save(job)
    spawn(jid)
    print(jid)


def _run(jid):
    job = load(jid)
    if not job:
        return
    job["runner_pid"] = os.getpid()
    save(job)
    lockf = None
    if not job.get("parallel"):
        lockf = open(LOCK, "a")
        fcntl.flock(lockf, fcntl.LOCK_EX)   # one job at a time, first come first served
        job = load(jid) or job
        if job["status"] == "cancelled":
            return
    job.update(status="running", started=time.time(), activity="starting", pct=max(job.get("pct", 0), 5))
    save(job)
    cmd = [find_claude(), "-p", "--output-format", "stream-json", "--verbose", "--model", MODEL]
    if job.get("session"):
        cmd += ["--resume", job["session"]]
    text = job["prompt"] if job.get("session") else BRIEF + job["prompt"]
    steps = 0
    result, err = "", ""
    try:
        proc = subprocess.Popen(cmd, cwd=HERE, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, bufsize=1, start_new_session=True)
        job["claude_pid"] = proc.pid
        save(job)
        # A cancel (SIGTERM to this wrapper) must take the real worker down with it, not orphan it.
        signal.signal(signal.SIGTERM, lambda *_: proc.terminate())
        proc.stdin.write(text)
        proc.stdin.close()
        with open(_path(jid, "log.txt"), "a") as log:
            for line in proc.stdout:
                log.write(line if len(line) <= LOG_LINE_CAP else line[:LOG_LINE_CAP] + " ...[truncated]\n")
                log.flush()
                try:
                    ev = json.loads(line)
                except ValueError:
                    continue
                if ev.get("session_id") and job.get("session") != ev["session_id"]:
                    job["session"] = ev["session_id"]
                if ev.get("type") == "assistant":
                    for b in (ev.get("message") or {}).get("content") or []:
                        if b.get("type") == "tool_use":
                            steps += 1
                            inp = b.get("input") or {}
                            hint = inp.get("description") or inp.get("file_path") or inp.get("command") or ""
                            job["activity"] = f"{b.get('name')}: {str(hint)[:70]}"
                            job["pct"] = min(92, 5 + int(87 * (1 - 0.93 ** steps)))
                            fresh = load(jid)
                            if fresh and fresh["status"] == "cancelled":
                                proc.terminate()
                                return
                            save(job)
                if ev.get("type") == "result":
                    result = ev.get("result") or ""
                    if ev.get("is_error"):
                        err = result or "error"
        proc.wait()
    except Exception as e:  # noqa: BLE001
        err = str(e)
    fresh = load(jid) or job
    if fresh["status"] == "cancelled":
        return
    job.update(status="failed" if err or not result else "done", finished=time.time(), pct=100,
               result=(result or err or "It stopped without a result.").strip(), activity="finished", announced=False)
    save(job)
    if lockf:
        lockf.close()


def cmd_list():
    for j in all_jobs():
        print(f"{j['id']}  {j['status']:9} {j['pct']:3}%  {j['label']}  [{j.get('activity', '')}]")
    if not all_jobs():
        print("no jobs")


def cmd_cancel(jid):
    j = load(jid)
    if not j:
        print("no such job")
        return
    j["status"] = "cancelled"
    j["finished"] = time.time()
    j["announced"] = True
    save(j)
    # the claude process first (it does the actual work), then the wrapper
    for key in ("claude_pid", "runner_pid"):
        pid = j.get(key)
        if pid and alive(pid):
            try:
                os.kill(pid, signal.SIGTERM)
            except OSError:
                pass
    deadline = time.time() + 5
    while j.get("claude_pid") and alive(j["claude_pid"]) and time.time() < deadline:
        time.sleep(0.2)
    if j.get("claude_pid") and alive(j["claude_pid"]):
        try:
            os.kill(j["claude_pid"], signal.SIGKILL)
        except OSError:
            pass
    print("cancelled")


def reconcile():
    """Mark jobs whose runner died (reboot, crash) as failed instead of leaving them 'running' forever,
    and drop the bulky logs of jobs that finished more than a week ago (job.json stays)."""
    for j in all_jobs():
        if j["status"] in ("queued", "running") and j.get("runner_pid") and not alive(j["runner_pid"]):
            j.update(status="failed", finished=time.time(), pct=100, announced=False,
                     result="The worker process died before finishing (the Mac may have restarted). Ask me to rerun it.")
            save(j)
        elif j.get("finished") and time.time() - j["finished"] > KEEP_LOGS_DAYS * 86400:
            try:
                os.remove(_path(j["id"], "log.txt"))
            except OSError:
                pass


def main():
    a = sys.argv[1:]
    if not a:
        print(__doc__)
        return
    os.makedirs(JOBS, exist_ok=True)
    c = a[0]
    if c == "start" and len(a) >= 3:
        cmd_start(a[1], a[2], parallel="--parallel" in a[3:])
    elif c == "_run":
        _run(a[1])
    elif c == "list":
        reconcile()
        cmd_list()
    elif c == "status":
        reconcile()
        print(json.dumps(load(a[1]), indent=1))
    elif c == "followup" and len(a) >= 3:
        j = load(a[1])
        if not j or not j.get("session"):
            print("that job has no saved session to continue")
            return
        cmd_start(j["label"] + " (follow-up)", a[2], session=j["session"])
    elif c == "cancel":
        cmd_cancel(a[1])
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
